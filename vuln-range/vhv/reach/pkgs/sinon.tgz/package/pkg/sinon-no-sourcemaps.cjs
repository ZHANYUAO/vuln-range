/* Sinon.JS 22.1.0, 2026-07-20, @license BSD-3 */(function(g,f){if(typeof exports=="object"&&typeof module<"u"){module.exports=f(require)}else if("function"==typeof define && define.amd){define("sinon",["timers","timers/promises","fs"],function(_d_0,_d_1,_d_2){var d={"timers": _d_0,"timers/promises": _d_1,"fs": _d_2},r=function(m){if(m in d) return d[m];if(typeof require=="function") return require(m);throw new Error("Cannot find module '"+m+"'")};return f(r)})}else {var gN={"timers":"timers","timers/promises":"timers/promises","fs":"fs"},gReq=function(r){var mod = r in gN ? g[gN[r]] : g[r]; return mod };g["sinon"]=f(gReq)}}(typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : this,function(require){var exports={};var __exports=exports;var module={exports};
"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};

// node_modules/@sinonjs/commons/lib/global.js
var require_global = __commonJS({
  "node_modules/@sinonjs/commons/lib/global.js"(exports2, module2) {
    "use strict";
    var globalObject;
    if (typeof global !== "undefined") {
      globalObject = global;
    } else if (typeof window !== "undefined") {
      globalObject = window;
    } else {
      globalObject = self;
    }
    module2.exports = globalObject;
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/throws-on-proto.js
var require_throws_on_proto = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/throws-on-proto.js"(exports2, module2) {
    "use strict";
    var throwsOnProto;
    try {
      const object = {};
      object.__proto__;
      throwsOnProto = false;
    } catch (_) {
      throwsOnProto = true;
    }
    module2.exports = throwsOnProto;
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/copy-prototype-methods.js
var require_copy_prototype_methods = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/copy-prototype-methods.js"(exports2, module2) {
    "use strict";
    var call = Function.call;
    var throwsOnProto = require_throws_on_proto();
    var disallowedProperties = [
      // ignore size because it throws from Map
      "size",
      "caller",
      "callee",
      "arguments"
    ];
    if (throwsOnProto) {
      disallowedProperties.push("__proto__");
    }
    module2.exports = function copyPrototypeMethods(prototype) {
      return Object.getOwnPropertyNames(prototype).reduce(
        function(result, name) {
          if (disallowedProperties.includes(name)) {
            return result;
          }
          if (typeof prototype[name] !== "function") {
            return result;
          }
          result[name] = call.bind(prototype[name]);
          return result;
        },
        /* @__PURE__ */ Object.create(null)
      );
    };
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/array.js
var require_array = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/array.js"(exports2, module2) {
    "use strict";
    var copyPrototype = require_copy_prototype_methods();
    module2.exports = copyPrototype(Array.prototype);
  }
});

// node_modules/@sinonjs/commons/lib/called-in-order.js
var require_called_in_order = __commonJS({
  "node_modules/@sinonjs/commons/lib/called-in-order.js"(exports2, module2) {
    "use strict";
    var every = require_array().every;
    function hasCallsLeft(callMap, spy) {
      if (callMap[spy.id] === void 0) {
        callMap[spy.id] = 0;
      }
      return callMap[spy.id] < spy.callCount;
    }
    function checkAdjacentCalls(callMap, spy, index, spies) {
      var calledBeforeNext = true;
      if (index !== spies.length - 1) {
        calledBeforeNext = spy.calledBefore(spies[index + 1]);
      }
      if (hasCallsLeft(callMap, spy) && calledBeforeNext) {
        callMap[spy.id] += 1;
        return true;
      }
      return false;
    }
    function calledInOrder(spies) {
      var callMap = {};
      var _spies = arguments.length > 1 ? arguments : spies;
      return every(_spies, checkAdjacentCalls.bind(null, callMap));
    }
    module2.exports = calledInOrder;
  }
});

// node_modules/@sinonjs/commons/lib/class-name.js
var require_class_name = __commonJS({
  "node_modules/@sinonjs/commons/lib/class-name.js"(exports2, module2) {
    "use strict";
    function className(value) {
      const name = value.constructor && value.constructor.name;
      return name || null;
    }
    module2.exports = className;
  }
});

// node_modules/@sinonjs/commons/lib/deprecated.js
var require_deprecated = __commonJS({
  "node_modules/@sinonjs/commons/lib/deprecated.js"(exports2) {
    "use strict";
    exports2.wrap = function(func, msg) {
      var wrapped = function() {
        exports2.printWarning(msg);
        return func.apply(this, arguments);
      };
      if (func.prototype) {
        wrapped.prototype = func.prototype;
      }
      return wrapped;
    };
    exports2.defaultMsg = function(packageName, funcName) {
      return `${packageName}.${funcName} is deprecated and will be removed from the public API in a future version of ${packageName}.`;
    };
    exports2.printWarning = function(msg) {
      if (typeof process === "object" && process.emitWarning) {
        process.emitWarning(msg);
      } else if (console.info) {
        console.info(msg);
      } else {
        console.log(msg);
      }
    };
  }
});

// node_modules/@sinonjs/commons/lib/every.js
var require_every = __commonJS({
  "node_modules/@sinonjs/commons/lib/every.js"(exports2, module2) {
    "use strict";
    module2.exports = function every(obj, fn) {
      var pass = true;
      try {
        obj.forEach(function() {
          if (!fn.apply(this, arguments)) {
            throw new Error();
          }
        });
      } catch (e) {
        pass = false;
      }
      return pass;
    };
  }
});

// node_modules/@sinonjs/commons/lib/function-name.js
var require_function_name = __commonJS({
  "node_modules/@sinonjs/commons/lib/function-name.js"(exports2, module2) {
    "use strict";
    module2.exports = function functionName(func) {
      if (!func) {
        return "";
      }
      try {
        return func.displayName || func.name || // Use function decomposition as a last resort to get function
        // name. Does not rely on function decomposition to work - if it
        // doesn't debugging will be slightly less informative
        // (i.e. toString will say 'spy' rather than 'myFunc').
        (String(func).match(/function ([^\s(]+)/) || [])[1];
      } catch (e) {
        return "";
      }
    };
  }
});

// node_modules/@sinonjs/commons/lib/order-by-first-call.js
var require_order_by_first_call = __commonJS({
  "node_modules/@sinonjs/commons/lib/order-by-first-call.js"(exports2, module2) {
    "use strict";
    var sort = require_array().sort;
    var slice = require_array().slice;
    function comparator(a, b) {
      var aCall = a.getCall(0);
      var bCall = b.getCall(0);
      var aId = aCall && aCall.callId || -1;
      var bId = bCall && bCall.callId || -1;
      return aId < bId ? -1 : 1;
    }
    function orderByFirstCall(spies) {
      return sort(slice(spies), comparator);
    }
    module2.exports = orderByFirstCall;
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/function.js
var require_function = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/function.js"(exports2, module2) {
    "use strict";
    var copyPrototype = require_copy_prototype_methods();
    module2.exports = copyPrototype(Function.prototype);
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/map.js
var require_map = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/map.js"(exports2, module2) {
    "use strict";
    var copyPrototype = require_copy_prototype_methods();
    module2.exports = copyPrototype(Map.prototype);
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/object.js
var require_object = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/object.js"(exports2, module2) {
    "use strict";
    var copyPrototype = require_copy_prototype_methods();
    module2.exports = copyPrototype(Object.prototype);
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/set.js
var require_set = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/set.js"(exports2, module2) {
    "use strict";
    var copyPrototype = require_copy_prototype_methods();
    module2.exports = copyPrototype(Set.prototype);
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/string.js
var require_string = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/string.js"(exports2, module2) {
    "use strict";
    var copyPrototype = require_copy_prototype_methods();
    module2.exports = copyPrototype(String.prototype);
  }
});

// node_modules/@sinonjs/commons/lib/prototypes/index.js
var require_prototypes = __commonJS({
  "node_modules/@sinonjs/commons/lib/prototypes/index.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      array: require_array(),
      function: require_function(),
      map: require_map(),
      object: require_object(),
      set: require_set(),
      string: require_string()
    };
  }
});

// node_modules/type-detect/type-detect.js
var require_type_detect = __commonJS({
  "node_modules/type-detect/type-detect.js"(exports2, module2) {
    (function(global2, factory) {
      typeof exports2 === "object" && typeof module2 !== "undefined" ? module2.exports = factory() : typeof define === "function" && define.amd ? define(factory) : global2.typeDetect = factory();
    })(exports2, (function() {
      "use strict";
      var promiseExists = typeof Promise === "function";
      var globalObject = typeof self === "object" ? self : global;
      var symbolExists = typeof Symbol !== "undefined";
      var mapExists = typeof Map !== "undefined";
      var setExists = typeof Set !== "undefined";
      var weakMapExists = typeof WeakMap !== "undefined";
      var weakSetExists = typeof WeakSet !== "undefined";
      var dataViewExists = typeof DataView !== "undefined";
      var symbolIteratorExists = symbolExists && typeof Symbol.iterator !== "undefined";
      var symbolToStringTagExists = symbolExists && typeof Symbol.toStringTag !== "undefined";
      var setEntriesExists = setExists && typeof Set.prototype.entries === "function";
      var mapEntriesExists = mapExists && typeof Map.prototype.entries === "function";
      var setIteratorPrototype = setEntriesExists && Object.getPrototypeOf((/* @__PURE__ */ new Set()).entries());
      var mapIteratorPrototype = mapEntriesExists && Object.getPrototypeOf((/* @__PURE__ */ new Map()).entries());
      var arrayIteratorExists = symbolIteratorExists && typeof Array.prototype[Symbol.iterator] === "function";
      var arrayIteratorPrototype = arrayIteratorExists && Object.getPrototypeOf([][Symbol.iterator]());
      var stringIteratorExists = symbolIteratorExists && typeof String.prototype[Symbol.iterator] === "function";
      var stringIteratorPrototype = stringIteratorExists && Object.getPrototypeOf(""[Symbol.iterator]());
      var toStringLeftSliceLength = 8;
      var toStringRightSliceLength = -1;
      function typeDetect(obj) {
        var typeofObj = typeof obj;
        if (typeofObj !== "object") {
          return typeofObj;
        }
        if (obj === null) {
          return "null";
        }
        if (obj === globalObject) {
          return "global";
        }
        if (Array.isArray(obj) && (symbolToStringTagExists === false || !(Symbol.toStringTag in obj))) {
          return "Array";
        }
        if (typeof window === "object" && window !== null) {
          if (typeof window.location === "object" && obj === window.location) {
            return "Location";
          }
          if (typeof window.document === "object" && obj === window.document) {
            return "Document";
          }
          if (typeof window.navigator === "object") {
            if (typeof window.navigator.mimeTypes === "object" && obj === window.navigator.mimeTypes) {
              return "MimeTypeArray";
            }
            if (typeof window.navigator.plugins === "object" && obj === window.navigator.plugins) {
              return "PluginArray";
            }
          }
          if ((typeof window.HTMLElement === "function" || typeof window.HTMLElement === "object") && obj instanceof window.HTMLElement) {
            if (obj.tagName === "BLOCKQUOTE") {
              return "HTMLQuoteElement";
            }
            if (obj.tagName === "TD") {
              return "HTMLTableDataCellElement";
            }
            if (obj.tagName === "TH") {
              return "HTMLTableHeaderCellElement";
            }
          }
        }
        var stringTag = symbolToStringTagExists && obj[Symbol.toStringTag];
        if (typeof stringTag === "string") {
          return stringTag;
        }
        var objPrototype = Object.getPrototypeOf(obj);
        if (objPrototype === RegExp.prototype) {
          return "RegExp";
        }
        if (objPrototype === Date.prototype) {
          return "Date";
        }
        if (promiseExists && objPrototype === Promise.prototype) {
          return "Promise";
        }
        if (setExists && objPrototype === Set.prototype) {
          return "Set";
        }
        if (mapExists && objPrototype === Map.prototype) {
          return "Map";
        }
        if (weakSetExists && objPrototype === WeakSet.prototype) {
          return "WeakSet";
        }
        if (weakMapExists && objPrototype === WeakMap.prototype) {
          return "WeakMap";
        }
        if (dataViewExists && objPrototype === DataView.prototype) {
          return "DataView";
        }
        if (mapExists && objPrototype === mapIteratorPrototype) {
          return "Map Iterator";
        }
        if (setExists && objPrototype === setIteratorPrototype) {
          return "Set Iterator";
        }
        if (arrayIteratorExists && objPrototype === arrayIteratorPrototype) {
          return "Array Iterator";
        }
        if (stringIteratorExists && objPrototype === stringIteratorPrototype) {
          return "String Iterator";
        }
        if (objPrototype === null) {
          return "Object";
        }
        return Object.prototype.toString.call(obj).slice(toStringLeftSliceLength, toStringRightSliceLength);
      }
      return typeDetect;
    }));
  }
});

// node_modules/@sinonjs/commons/lib/type-of.js
var require_type_of = __commonJS({
  "node_modules/@sinonjs/commons/lib/type-of.js"(exports2, module2) {
    "use strict";
    var type = require_type_detect();
    module2.exports = function typeOf(value) {
      return type(value).toLowerCase();
    };
  }
});

// node_modules/@sinonjs/commons/lib/value-to-string.js
var require_value_to_string = __commonJS({
  "node_modules/@sinonjs/commons/lib/value-to-string.js"(exports2, module2) {
    "use strict";
    function valueToString(value) {
      if (value && value.toString) {
        return value.toString();
      }
      return String(value);
    }
    module2.exports = valueToString;
  }
});

// node_modules/@sinonjs/commons/lib/index.js
var require_lib = __commonJS({
  "node_modules/@sinonjs/commons/lib/index.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      global: require_global(),
      calledInOrder: require_called_in_order(),
      className: require_class_name(),
      deprecated: require_deprecated(),
      every: require_every(),
      functionName: require_function_name(),
      orderByFirstCall: require_order_by_first_call(),
      prototypes: require_prototypes(),
      typeOf: require_type_of(),
      valueToString: require_value_to_string()
    };
  }
});

// lib/sinon/util/core/extend.js
var require_extend = __commonJS({
  "lib/sinon/util/core/extend.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes: commonsPrototypes } = commons__default.default;
    var { array: arrayProto, object: objectProto } = commonsPrototypes;
    var { hasOwnProperty } = objectProto;
    var join = arrayProto.join;
    var push = arrayProto.push;
    var hasDontEnumBug = (function() {
      const obj = {
        constructor: function() {
          return "0";
        },
        toString: function() {
          return "1";
        },
        valueOf: function() {
          return "2";
        },
        toLocaleString: function() {
          return "3";
        },
        prototype: function() {
          return "4";
        },
        isPrototypeOf: function() {
          return "5";
        },
        propertyIsEnumerable: function() {
          return "6";
        },
        hasOwnProperty: function() {
          return "7";
        },
        length: function() {
          return "8";
        },
        unique: function() {
          return "9";
        }
      };
      const result = [];
      for (const prop in obj) {
        if (hasOwnProperty(obj, prop)) {
          push(result, obj[prop]());
        }
      }
      return join(result, "") !== "0123456789";
    })();
    function extendCommon(target, sources, doCopy) {
      let source, i, prop;
      for (i = 0; i < sources.length; i++) {
        source = sources[i];
        for (prop in source) {
          if (hasOwnProperty(source, prop)) {
            doCopy(target, source, prop);
          }
        }
        if (hasDontEnumBug && hasOwnProperty(source, "toString") && source.toString !== target.toString) {
          target.toString = source.toString;
        }
      }
      return target;
    }
    function extend(target, ...sources) {
      return extendCommon(
        target,
        sources,
        function copyValue(dest, source, prop) {
          const destOwnPropertyDescriptor = Object.getOwnPropertyDescriptor(
            dest,
            prop
          );
          const sourceOwnPropertyDescriptor = Object.getOwnPropertyDescriptor(
            source,
            prop
          );
          if (prop === "name" && (!destOwnPropertyDescriptor || !destOwnPropertyDescriptor.writable)) {
            return;
          }
          const descriptors = {
            configurable: sourceOwnPropertyDescriptor.configurable,
            enumerable: sourceOwnPropertyDescriptor.enumerable
          };
          if (hasOwnProperty(sourceOwnPropertyDescriptor, "writable")) {
            descriptors.writable = sourceOwnPropertyDescriptor.writable;
            descriptors.value = sourceOwnPropertyDescriptor.value;
          } else {
            if (sourceOwnPropertyDescriptor.get) {
              descriptors.get = sourceOwnPropertyDescriptor.get.bind(dest);
            }
            if (sourceOwnPropertyDescriptor.set) {
              descriptors.set = sourceOwnPropertyDescriptor.set.bind(dest);
            }
          }
          Object.defineProperty(dest, prop, descriptors);
        }
      );
    }
    extend.nonEnum = function extendNonEnum(target, ...sources) {
      return extendCommon(
        target,
        sources,
        function copyProperty(dest, source, prop) {
          Object.defineProperty(dest, prop, {
            value: source[prop],
            enumerable: false,
            configurable: true,
            writable: true
          });
        }
      );
    };
    module2.exports = extend;
  }
});

// lib/sinon/util/core/get-next-tick.js
var require_get_next_tick = __commonJS({
  "lib/sinon/util/core/get-next-tick.js"(exports2, module2) {
    "use strict";
    function nextTick(callback) {
      setTimeout(callback, 0);
    }
    function getNextTick(process2, setImmediate) {
      if (typeof process2 === "object" && typeof process2.nextTick === "function") {
        return process2.nextTick;
      }
      if (typeof setImmediate === "function") {
        return setImmediate;
      }
      return nextTick;
    }
    module2.exports = getNextTick;
  }
});

// lib/sinon/util/core/next-tick.js
var require_next_tick = __commonJS({
  "lib/sinon/util/core/next-tick.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var getNextTick = require_get_next_tick();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { global: globalObject } = commons__default.default;
    var nextTick = getNextTick(globalObject.process, globalObject.setImmediate);
    module2.exports = nextTick;
  }
});

// lib/sinon/util/core/export-async-behaviors.js
var require_export_async_behaviors = __commonJS({
  "lib/sinon/util/core/export-async-behaviors.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { reduce } = prototypes.array;
    function exportAsyncBehaviors(behaviorMethods) {
      return reduce(
        Object.keys(behaviorMethods),
        function(acc, method) {
          if (method.match(/^(callsArg|yields)/) && !method.match(/Async/)) {
            acc[`${method}Async`] = function() {
              const result = behaviorMethods[method].apply(
                this,
                arguments
              );
              this.callbackAsync = true;
              return result;
            };
          }
          return acc;
        },
        {}
      );
    }
    module2.exports = exportAsyncBehaviors;
  }
});

// lib/sinon/behavior.js
var require_behavior = __commonJS({
  "lib/sinon/behavior.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var extend = require_extend();
    var nextTick = require_next_tick();
    var exportAsyncBehaviors = require_export_async_behaviors();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes: commonsPrototypes, functionName, valueToString } = commons__default.default;
    var { array: arrayProto } = commonsPrototypes;
    var concat = arrayProto.concat;
    var join = arrayProto.join;
    var reverse = arrayProto.reverse;
    var slice = arrayProto.slice;
    var useLeftMostCallback = -1;
    var useRightMostCallback = -2;
    function getCallback(behavior2, args) {
      const callArgAt = behavior2.callArgAt;
      if (callArgAt >= 0) {
        return args[callArgAt];
      }
      let argumentList;
      if (callArgAt === useLeftMostCallback) {
        argumentList = args;
      }
      if (callArgAt === useRightMostCallback) {
        argumentList = reverse(slice(args));
      }
      const callArgProp = behavior2.callArgProp;
      for (let i = 0, l = argumentList.length; i < l; ++i) {
        if (!callArgProp && typeof argumentList[i] === "function") {
          return argumentList[i];
        }
        if (callArgProp && argumentList[i] && typeof argumentList[i][callArgProp] === "function") {
          return argumentList[i][callArgProp];
        }
      }
      return null;
    }
    function getCallbackError(behavior2, func, args) {
      if (behavior2.callArgAt < 0) {
        let msg;
        if (behavior2.callArgProp) {
          msg = `${functionName(
            behavior2.stub
          )} expected to yield to '${valueToString(
            behavior2.callArgProp
          )}', but no object with such a property was passed.`;
        } else {
          msg = `${functionName(
            behavior2.stub
          )} expected to yield, but no callback was passed.`;
        }
        if (args.length > 0) {
          msg += ` Received [${join(args, ", ")}]`;
        }
        return msg;
      }
      return `argument at index ${behavior2.callArgAt} is not a function: ${func}`;
    }
    function ensureArgs(name, behavior2, args) {
      const property = name.replace(/sArg/, "ArgAt");
      const index = behavior2[property];
      if (index >= args.length) {
        throw new TypeError(
          `${name} failed: ${index + 1} arguments required but only ${args.length} present`
        );
      }
    }
    function callCallback(behavior2, args) {
      if (typeof behavior2.callArgAt === "number") {
        ensureArgs("callsArg", behavior2, args);
        const func = getCallback(behavior2, args);
        if (typeof func !== "function") {
          throw new TypeError(getCallbackError(behavior2, func, args));
        }
        if (behavior2.callbackAsync) {
          nextTick(function() {
            func.apply(
              behavior2.callbackContext,
              behavior2.callbackArguments
            );
          });
        } else {
          return func.apply(
            behavior2.callbackContext,
            behavior2.callbackArguments
          );
        }
      }
      return void 0;
    }
    var proto = {
      create: function create(stub) {
        const behavior2 = extend({}, proto);
        delete behavior2.create;
        delete behavior2.addBehavior;
        delete behavior2.createBehavior;
        behavior2.stub = stub;
        if (stub.defaultBehavior && stub.defaultBehavior.promiseLibrary) {
          behavior2.promiseLibrary = stub.defaultBehavior.promiseLibrary;
        }
        return behavior2;
      },
      isPresent: function isPresent() {
        return typeof this.callArgAt === "number" || this.exception || this.exceptionCreator || typeof this.returnArgAt === "number" || this.returnThis || typeof this.resolveArgAt === "number" || this.resolveThis || typeof this.throwArgAt === "number" || this.fakeFn || this.returnValueDefined;
      },
      /*eslint complexity: ["error", 20]*/
      invoke: function invoke(context, args) {
        const returnValue = callCallback(this, args);
        if (this.exception) {
          throw this.exception;
        } else if (this.exceptionCreator) {
          this.exception = this.exceptionCreator();
          this.exceptionCreator = void 0;
          throw this.exception;
        } else if (typeof this.returnArgAt === "number") {
          ensureArgs("returnsArg", this, args);
          return args[this.returnArgAt];
        } else if (this.returnThis) {
          return context;
        } else if (typeof this.throwArgAt === "number") {
          ensureArgs("throwsArg", this, args);
          throw args[this.throwArgAt];
        } else if (this.fakeFn) {
          return this.fakeFn.apply(context, args);
        } else if (typeof this.resolveArgAt === "number") {
          ensureArgs("resolvesArg", this, args);
          return (this.promiseLibrary || Promise).resolve(
            args[this.resolveArgAt]
          );
        } else if (this.resolveThis) {
          return (this.promiseLibrary || Promise).resolve(context);
        } else if (this.resolve) {
          return (this.promiseLibrary || Promise).resolve(this.returnValue);
        } else if (this.reject) {
          return (this.promiseLibrary || Promise).reject(this.returnValue);
        } else if (this.callsThrough) {
          const wrappedMethod = this.effectiveWrappedMethod();
          return wrappedMethod.apply(context, args);
        } else if (this.callsThroughWithNew) {
          const WrappedClass = this.effectiveWrappedMethod();
          const argsArray = slice(args);
          const F = WrappedClass.bind.apply(
            WrappedClass,
            concat([null], argsArray)
          );
          return new F();
        } else if (typeof this.returnValue !== "undefined") {
          return this.returnValue;
        } else if (typeof this.callArgAt === "number") {
          return returnValue;
        }
        return this.returnValue;
      },
      effectiveWrappedMethod: function effectiveWrappedMethod() {
        for (let stubb = this.stub; stubb; stubb = stubb.parent) {
          if (stubb.wrappedMethod) {
            return stubb.wrappedMethod;
          }
        }
        throw new Error("Unable to find wrapped method");
      },
      onCall: function onCall(index) {
        return this.stub.onCall(index);
      },
      onFirstCall: function onFirstCall() {
        return this.stub.onFirstCall();
      },
      onSecondCall: function onSecondCall() {
        return this.stub.onSecondCall();
      },
      onThirdCall: function onThirdCall() {
        return this.stub.onThirdCall();
      },
      withArgs: function withArgs() {
        throw new Error(
          'Defining a stub by invoking "stub.onCall(...).withArgs(...)" is not supported. Use "stub.withArgs(...).onCall(...)" to define sequential behavior for calls with certain arguments.'
        );
      }
    };
    function createBehavior(behaviorMethod) {
      return function() {
        this.defaultBehavior = this.defaultBehavior || proto.create(this);
        this.defaultBehavior[behaviorMethod].apply(
          this.defaultBehavior,
          arguments
        );
        return this;
      };
    }
    function addBehavior(stub, name, fn) {
      proto[name] = function() {
        fn.apply(this, concat([this], slice(arguments)));
        return this.stub || this;
      };
      stub[name] = createBehavior(name);
    }
    proto.addBehavior = addBehavior;
    proto.createBehavior = createBehavior;
    var asyncBehaviors = exportAsyncBehaviors(proto);
    var behavior = extend.nonEnum({}, proto, asyncBehaviors);
    module2.exports = behavior;
  }
});

// node_modules/@sinonjs/samsam/lib/is-nan.js
var require_is_nan = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-nan.js"(exports2, module2) {
    "use strict";
    function isNaN2(value) {
      return typeof value === "number" && value !== value;
    }
    module2.exports = isNaN2;
  }
});

// node_modules/@sinonjs/samsam/lib/is-neg-zero.js
var require_is_neg_zero = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-neg-zero.js"(exports2, module2) {
    "use strict";
    function isNegZero(value) {
      return value === 0 && 1 / value === -Infinity;
    }
    module2.exports = isNegZero;
  }
});

// node_modules/@sinonjs/samsam/lib/identical.js
var require_identical = __commonJS({
  "node_modules/@sinonjs/samsam/lib/identical.js"(exports2, module2) {
    "use strict";
    var isNaN2 = require_is_nan();
    var isNegZero = require_is_neg_zero();
    function identical(obj1, obj2) {
      if (obj1 === obj2 || isNaN2(obj1) && isNaN2(obj2)) {
        return obj1 !== 0 || isNegZero(obj1) === isNegZero(obj2);
      }
      return false;
    }
    module2.exports = identical;
  }
});

// node_modules/@sinonjs/samsam/lib/get-class.js
var require_get_class = __commonJS({
  "node_modules/@sinonjs/samsam/lib/get-class.js"(exports2, module2) {
    "use strict";
    var toString = require_lib().prototypes.object.toString;
    function getClass(value) {
      return toString(value).split(/[ \]]/)[1];
    }
    module2.exports = getClass;
  }
});

// node_modules/@sinonjs/samsam/lib/is-arguments.js
var require_is_arguments = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-arguments.js"(exports2, module2) {
    "use strict";
    var getClass = require_get_class();
    function isArguments(object) {
      return getClass(object) === "Arguments";
    }
    module2.exports = isArguments;
  }
});

// node_modules/@sinonjs/samsam/lib/is-element.js
var require_is_element = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-element.js"(exports2, module2) {
    "use strict";
    var div = typeof document !== "undefined" && document.createElement("div");
    function isElement(object) {
      if (!object || object.nodeType !== 1 || !div) {
        return false;
      }
      try {
        object.appendChild(div);
        object.removeChild(div);
      } catch (e) {
        return false;
      }
      return true;
    }
    module2.exports = isElement;
  }
});

// node_modules/@sinonjs/samsam/lib/is-set.js
var require_is_set = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-set.js"(exports2, module2) {
    "use strict";
    function isSet(val) {
      return typeof Set !== "undefined" && val instanceof Set || false;
    }
    module2.exports = isSet;
  }
});

// node_modules/@sinonjs/samsam/lib/is-map.js
var require_is_map = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-map.js"(exports2, module2) {
    "use strict";
    function isMap(value) {
      return typeof Map !== "undefined" && value instanceof Map;
    }
    module2.exports = isMap;
  }
});

// node_modules/@sinonjs/samsam/node_modules/type-detect/type-detect.js
var require_type_detect2 = __commonJS({
  "node_modules/@sinonjs/samsam/node_modules/type-detect/type-detect.js"(exports2, module2) {
    (function(global2, factory) {
      typeof exports2 === "object" && typeof module2 !== "undefined" ? module2.exports = factory() : typeof define === "function" && define.amd ? define(factory) : (global2 = typeof globalThis !== "undefined" ? globalThis : global2 || self, global2.typeDetect = factory());
    })(exports2, (function() {
      "use strict";
      var promiseExists = typeof Promise === "function";
      var globalObject = (function(Obj) {
        if (typeof globalThis === "object") {
          return globalThis;
        }
        Object.defineProperty(Obj, "typeDetectGlobalObject", {
          get: function get() {
            return this;
          },
          configurable: true
        });
        var global2 = typeDetectGlobalObject;
        delete Obj.typeDetectGlobalObject;
        return global2;
      })(Object.prototype);
      var symbolExists = typeof Symbol !== "undefined";
      var mapExists = typeof Map !== "undefined";
      var setExists = typeof Set !== "undefined";
      var weakMapExists = typeof WeakMap !== "undefined";
      var weakSetExists = typeof WeakSet !== "undefined";
      var dataViewExists = typeof DataView !== "undefined";
      var symbolIteratorExists = symbolExists && typeof Symbol.iterator !== "undefined";
      var symbolToStringTagExists = symbolExists && typeof Symbol.toStringTag !== "undefined";
      var setEntriesExists = setExists && typeof Set.prototype.entries === "function";
      var mapEntriesExists = mapExists && typeof Map.prototype.entries === "function";
      var setIteratorPrototype = setEntriesExists && Object.getPrototypeOf((/* @__PURE__ */ new Set()).entries());
      var mapIteratorPrototype = mapEntriesExists && Object.getPrototypeOf((/* @__PURE__ */ new Map()).entries());
      var arrayIteratorExists = symbolIteratorExists && typeof Array.prototype[Symbol.iterator] === "function";
      var arrayIteratorPrototype = arrayIteratorExists && Object.getPrototypeOf([][Symbol.iterator]());
      var stringIteratorExists = symbolIteratorExists && typeof String.prototype[Symbol.iterator] === "function";
      var stringIteratorPrototype = stringIteratorExists && Object.getPrototypeOf(""[Symbol.iterator]());
      var toStringLeftSliceLength = 8;
      var toStringRightSliceLength = -1;
      function typeDetect(obj) {
        var typeofObj = typeof obj;
        if (typeofObj !== "object") {
          return typeofObj;
        }
        if (obj === null) {
          return "null";
        }
        if (obj === globalObject) {
          return "global";
        }
        if (Array.isArray(obj) && (symbolToStringTagExists === false || !(Symbol.toStringTag in obj))) {
          return "Array";
        }
        if (typeof window === "object" && window !== null) {
          if (typeof window.location === "object" && obj === window.location) {
            return "Location";
          }
          if (typeof window.document === "object" && obj === window.document) {
            return "Document";
          }
          if (typeof window.navigator === "object") {
            if (typeof window.navigator.mimeTypes === "object" && obj === window.navigator.mimeTypes) {
              return "MimeTypeArray";
            }
            if (typeof window.navigator.plugins === "object" && obj === window.navigator.plugins) {
              return "PluginArray";
            }
          }
          if ((typeof window.HTMLElement === "function" || typeof window.HTMLElement === "object") && obj instanceof window.HTMLElement) {
            if (obj.tagName === "BLOCKQUOTE") {
              return "HTMLQuoteElement";
            }
            if (obj.tagName === "TD") {
              return "HTMLTableDataCellElement";
            }
            if (obj.tagName === "TH") {
              return "HTMLTableHeaderCellElement";
            }
          }
        }
        var stringTag = symbolToStringTagExists && obj[Symbol.toStringTag];
        if (typeof stringTag === "string") {
          return stringTag;
        }
        var objPrototype = Object.getPrototypeOf(obj);
        if (objPrototype === RegExp.prototype) {
          return "RegExp";
        }
        if (objPrototype === Date.prototype) {
          return "Date";
        }
        if (promiseExists && objPrototype === Promise.prototype) {
          return "Promise";
        }
        if (setExists && objPrototype === Set.prototype) {
          return "Set";
        }
        if (mapExists && objPrototype === Map.prototype) {
          return "Map";
        }
        if (weakSetExists && objPrototype === WeakSet.prototype) {
          return "WeakSet";
        }
        if (weakMapExists && objPrototype === WeakMap.prototype) {
          return "WeakMap";
        }
        if (dataViewExists && objPrototype === DataView.prototype) {
          return "DataView";
        }
        if (mapExists && objPrototype === mapIteratorPrototype) {
          return "Map Iterator";
        }
        if (setExists && objPrototype === setIteratorPrototype) {
          return "Set Iterator";
        }
        if (arrayIteratorExists && objPrototype === arrayIteratorPrototype) {
          return "Array Iterator";
        }
        if (stringIteratorExists && objPrototype === stringIteratorPrototype) {
          return "String Iterator";
        }
        if (objPrototype === null) {
          return "Object";
        }
        return Object.prototype.toString.call(obj).slice(toStringLeftSliceLength, toStringRightSliceLength);
      }
      return typeDetect;
    }));
  }
});

// node_modules/@sinonjs/samsam/lib/array-types.js
var require_array_types = __commonJS({
  "node_modules/@sinonjs/samsam/lib/array-types.js"(exports2, module2) {
    "use strict";
    var ARRAY_TYPES = [
      Array,
      Int8Array,
      Uint8Array,
      Uint8ClampedArray,
      Int16Array,
      Uint16Array,
      Int32Array,
      Uint32Array,
      Float32Array,
      Float64Array
    ];
    module2.exports = ARRAY_TYPES;
  }
});

// node_modules/@sinonjs/samsam/lib/is-array-type.js
var require_is_array_type = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-array-type.js"(exports2, module2) {
    "use strict";
    var functionName = require_lib().functionName;
    var indexOf = require_lib().prototypes.array.indexOf;
    var map = require_lib().prototypes.array.map;
    var ARRAY_TYPES = require_array_types();
    var type = require_type_detect2();
    function isArrayType(object) {
      return indexOf(map(ARRAY_TYPES, functionName), type(object)) !== -1;
    }
    module2.exports = isArrayType;
  }
});

// node_modules/@sinonjs/samsam/lib/is-date.js
var require_is_date = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-date.js"(exports2, module2) {
    "use strict";
    function isDate(value) {
      return value instanceof Date;
    }
    module2.exports = isDate;
  }
});

// node_modules/@sinonjs/samsam/lib/is-iterable.js
var require_is_iterable = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-iterable.js"(exports2, module2) {
    "use strict";
    function isIterable(val) {
      if (typeof val !== "object") {
        return false;
      }
      return typeof val[Symbol.iterator] === "function";
    }
    module2.exports = isIterable;
  }
});

// node_modules/@sinonjs/samsam/lib/is-object.js
var require_is_object = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-object.js"(exports2, module2) {
    "use strict";
    function isObject(value) {
      return typeof value === "object" && value !== null && // none of these are collection objects, so we can return false
      !(value instanceof Boolean) && !(value instanceof Date) && !(value instanceof Error) && !(value instanceof Number) && !(value instanceof RegExp) && !(value instanceof String);
    }
    module2.exports = isObject;
  }
});

// node_modules/@sinonjs/samsam/lib/is-subset.js
var require_is_subset = __commonJS({
  "node_modules/@sinonjs/samsam/lib/is-subset.js"(exports2, module2) {
    "use strict";
    var forEach = require_lib().prototypes.set.forEach;
    function isSubset(s1, s2, compare) {
      var allContained = true;
      forEach(s1, function(v1) {
        var includes = false;
        forEach(s2, function(v2) {
          if (compare(v2, v1)) {
            includes = true;
          }
        });
        allContained = allContained && includes;
      });
      return allContained;
    }
    module2.exports = isSubset;
  }
});

// node_modules/@sinonjs/samsam/lib/deep-equal.js
var require_deep_equal = __commonJS({
  "node_modules/@sinonjs/samsam/lib/deep-equal.js"(exports2, module2) {
    "use strict";
    var valueToString = require_lib().valueToString;
    var className = require_lib().className;
    var typeOf = require_lib().typeOf;
    var arrayProto = require_lib().prototypes.array;
    var mapForEach = require_lib().prototypes.map.forEach;
    var getClass = require_get_class();
    var identical = require_identical();
    var isArguments = require_is_arguments();
    var isArrayType = require_is_array_type();
    var isDate = require_is_date();
    var isElement = require_is_element();
    var isIterable = require_is_iterable();
    var isMap = require_is_map();
    var isNaN2 = require_is_nan();
    var isObject = require_is_object();
    var isSet = require_is_set();
    var isSubset = require_is_subset();
    var concat = arrayProto.concat;
    var every = arrayProto.every;
    var push = arrayProto.push;
    var getTime = Date.prototype.getTime;
    var indexOf = arrayProto.indexOf;
    var objectKeys = Object.keys;
    var getOwnPropertySymbols = Object.getOwnPropertySymbols;
    function allEnumerableKeysInProtoChain(object) {
      const enumerableKeys = [];
      for (const key in object) {
        enumerableKeys.push(key);
      }
      return enumerableKeys;
    }
    function shouldComparePrototypeEnumerableKeys(object) {
      return !isArrayType(object) && !isArguments(object);
    }
    function getEnumerableStringKeys(object) {
      return shouldComparePrototypeEnumerableKeys(object) ? allEnumerableKeysInProtoChain(object) : objectKeys(object);
    }
    function hasAllEnumerableStringKeys(actualKeys, expectedKeys) {
      return every(expectedKeys, function(key) {
        return indexOf(actualKeys, key) !== -1;
      });
    }
    function deepEqualCyclic(actual, expectation, match) {
      var actualObjects = [];
      var expectationObjects = [];
      var actualPaths = [];
      var expectationPaths = [];
      var compared = {};
      return (function deepEqual(actualObj, expectationObj, actualPath, expectationPath) {
        if (match && match.isMatcher(expectationObj)) {
          if (match.isMatcher(actualObj)) {
            return actualObj === expectationObj;
          }
          return expectationObj.test(actualObj);
        }
        var actualType = typeof actualObj;
        var expectationType = typeof expectationObj;
        if (actualObj === expectationObj || isNaN2(actualObj) || isNaN2(expectationObj) || actualObj === null || expectationObj === null || actualObj === void 0 || expectationObj === void 0 || actualType !== "object" || expectationType !== "object") {
          return identical(actualObj, expectationObj);
        }
        if (isElement(actualObj) || isElement(expectationObj)) {
          return false;
        }
        var isActualDate = isDate(actualObj);
        var isExpectationDate = isDate(expectationObj);
        if (isActualDate || isExpectationDate) {
          if (!isActualDate || !isExpectationDate || getTime.call(actualObj) !== getTime.call(expectationObj)) {
            return false;
          }
        }
        if (actualObj instanceof RegExp && expectationObj instanceof RegExp) {
          if (valueToString(actualObj) !== valueToString(expectationObj)) {
            return false;
          }
        }
        if (actualObj instanceof Promise && expectationObj instanceof Promise) {
          return actualObj === expectationObj;
        }
        if (actualObj instanceof Error && expectationObj instanceof Error) {
          return actualObj === expectationObj;
        }
        var actualClass = getClass(actualObj);
        var expectationClass = getClass(expectationObj);
        var actualKeys = getEnumerableStringKeys(actualObj);
        var expectationKeys = getEnumerableStringKeys(expectationObj);
        var actualName = className(actualObj);
        var expectationName = className(expectationObj);
        var expectationSymbols = typeOf(getOwnPropertySymbols) === "function" ? getOwnPropertySymbols(expectationObj) : (
          /* c8 ignore next: cannot collect coverage for engine that doesn't support Symbol */
          []
        );
        var expectationKeysAndSymbols = concat(
          expectationKeys,
          expectationSymbols
        );
        if (isArguments(actualObj) || isArguments(expectationObj)) {
          if (actualObj.length !== expectationObj.length) {
            return false;
          }
        } else {
          if (actualType !== expectationType || actualClass !== expectationClass || actualKeys.length !== expectationKeys.length || !hasAllEnumerableStringKeys(actualKeys, expectationKeys) || !hasAllEnumerableStringKeys(expectationKeys, actualKeys) || actualName && expectationName && actualName !== expectationName) {
            return false;
          }
        }
        if (isSet(actualObj) || isSet(expectationObj)) {
          if (!isSet(actualObj) || !isSet(expectationObj) || actualObj.size !== expectationObj.size) {
            return false;
          }
          return isSubset(actualObj, expectationObj, deepEqual);
        }
        if (isMap(actualObj) || isMap(expectationObj)) {
          if (!isMap(actualObj) || !isMap(expectationObj) || actualObj.size !== expectationObj.size) {
            return false;
          }
          var mapsDeeplyEqual = true;
          mapForEach(actualObj, function(value, key) {
            mapsDeeplyEqual = mapsDeeplyEqual && deepEqualCyclic(value, expectationObj.get(key));
          });
          return mapsDeeplyEqual;
        }
        if (typeof actualObj.jquery === "string" && typeof actualObj.is === "function") {
          return actualObj.is(expectationObj);
        }
        var isActualNonArrayIterable = isIterable(actualObj) && !isArrayType(actualObj) && !isArguments(actualObj);
        var isExpectationNonArrayIterable = isIterable(expectationObj) && !isArrayType(expectationObj) && !isArguments(expectationObj);
        if (isActualNonArrayIterable || isExpectationNonArrayIterable) {
          var actualArray = Array.from(actualObj);
          var expectationArray = Array.from(expectationObj);
          if (actualArray.length !== expectationArray.length) {
            return false;
          }
          var arrayDeeplyEquals = true;
          every(actualArray, function(key) {
            arrayDeeplyEquals = arrayDeeplyEquals && deepEqualCyclic(actualArray[key], expectationArray[key]);
          });
          return arrayDeeplyEquals;
        }
        return every(expectationKeysAndSymbols, function(key) {
          var actualValue = actualObj[key];
          var expectationValue = expectationObj[key];
          var actualObject = isObject(actualValue);
          var expectationObject = isObject(expectationValue);
          var actualIndex = actualObject ? indexOf(actualObjects, actualValue) : -1;
          var expectationIndex = expectationObject ? indexOf(expectationObjects, expectationValue) : -1;
          var newActualPath = actualIndex !== -1 ? actualPaths[actualIndex] : `${actualPath}[${JSON.stringify(key)}]`;
          var newExpectationPath = expectationIndex !== -1 ? expectationPaths[expectationIndex] : `${expectationPath}[${JSON.stringify(key)}]`;
          var combinedPath = newActualPath + newExpectationPath;
          if (compared[combinedPath]) {
            return true;
          }
          if (actualIndex === -1 && actualObject) {
            push(actualObjects, actualValue);
            push(actualPaths, newActualPath);
          }
          if (expectationIndex === -1 && expectationObject) {
            push(expectationObjects, expectationValue);
            push(expectationPaths, newExpectationPath);
          }
          if (actualObject && expectationObject) {
            compared[combinedPath] = true;
          }
          return deepEqual(
            actualValue,
            expectationValue,
            newActualPath,
            newExpectationPath
          );
        });
      })(actual, expectation, "$1", "$2");
    }
    deepEqualCyclic.use = function(match) {
      return function deepEqual(a, b) {
        return deepEqualCyclic(a, b, match);
      };
    };
    module2.exports = deepEqualCyclic;
  }
});

// node_modules/@sinonjs/samsam/lib/iterable-to-string.js
var require_iterable_to_string = __commonJS({
  "node_modules/@sinonjs/samsam/lib/iterable-to-string.js"(exports2, module2) {
    "use strict";
    var slice = require_lib().prototypes.string.slice;
    var typeOf = require_lib().typeOf;
    var valueToString = require_lib().valueToString;
    function iterableToString(obj) {
      if (typeOf(obj) === "map") {
        return mapToString(obj);
      }
      return genericIterableToString(obj);
    }
    function mapToString(map) {
      var representation = "";
      map.forEach(function(value, key) {
        representation += `[${stringify(key)},${stringify(value)}],`;
      });
      representation = slice(representation, 0, -1);
      return representation;
    }
    function genericIterableToString(iterable) {
      var representation = "";
      iterable.forEach(function(value) {
        representation += `${stringify(value)},`;
      });
      representation = slice(representation, 0, -1);
      return representation;
    }
    function stringify(item) {
      return typeof item === "string" ? `'${item}'` : valueToString(item);
    }
    module2.exports = iterableToString;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/matcher-prototype.js
var require_matcher_prototype = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/matcher-prototype.js"(exports2, module2) {
    "use strict";
    var matcherPrototype = {
      toString: function() {
        return this.message;
      }
    };
    matcherPrototype.or = function(valueOrMatcher) {
      var createMatcher = require_create_matcher();
      var isMatcher = createMatcher.isMatcher;
      if (!arguments.length) {
        throw new TypeError("Matcher expected");
      }
      var m2 = isMatcher(valueOrMatcher) ? valueOrMatcher : createMatcher(valueOrMatcher);
      var m1 = this;
      var or = Object.create(matcherPrototype);
      or.test = function(actual) {
        return m1.test(actual) || m2.test(actual);
      };
      or.message = `${m1.message}.or(${m2.message})`;
      return or;
    };
    matcherPrototype.and = function(valueOrMatcher) {
      var createMatcher = require_create_matcher();
      var isMatcher = createMatcher.isMatcher;
      if (!arguments.length) {
        throw new TypeError("Matcher expected");
      }
      var m2 = isMatcher(valueOrMatcher) ? valueOrMatcher : createMatcher(valueOrMatcher);
      var m1 = this;
      var and = Object.create(matcherPrototype);
      and.test = function(actual) {
        return m1.test(actual) && m2.test(actual);
      };
      and.message = `${m1.message}.and(${m2.message})`;
      return and;
    };
    module2.exports = matcherPrototype;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/is-matcher.js
var require_is_matcher = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/is-matcher.js"(exports2, module2) {
    "use strict";
    var isPrototypeOf = require_lib().prototypes.object.isPrototypeOf;
    var matcherPrototype = require_matcher_prototype();
    function isMatcher(object) {
      return isPrototypeOf(matcherPrototype, object);
    }
    module2.exports = isMatcher;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/assert-matcher.js
var require_assert_matcher = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/assert-matcher.js"(exports2, module2) {
    "use strict";
    var isMatcher = require_is_matcher();
    function assertMatcher(value) {
      if (!isMatcher(value)) {
        throw new TypeError("Matcher expected");
      }
    }
    module2.exports = assertMatcher;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/assert-method-exists.js
var require_assert_method_exists = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/assert-method-exists.js"(exports2, module2) {
    "use strict";
    function assertMethodExists(value, method, name, methodPath) {
      if (value[method] === null || value[method] === void 0) {
        throw new TypeError(`Expected ${name} to have method ${methodPath}`);
      }
    }
    module2.exports = assertMethodExists;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/assert-type.js
var require_assert_type = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/assert-type.js"(exports2, module2) {
    "use strict";
    var typeOf = require_lib().typeOf;
    function assertType(value, type, name) {
      var actual = typeOf(value);
      if (actual !== type) {
        throw new TypeError(
          `Expected type of ${name} to be ${type}, but was ${actual}`
        );
      }
    }
    module2.exports = assertType;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/is-iterable.js
var require_is_iterable2 = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/is-iterable.js"(exports2, module2) {
    "use strict";
    var typeOf = require_lib().typeOf;
    function isIterable(value) {
      return Boolean(value) && typeOf(value.forEach) === "function";
    }
    module2.exports = isIterable;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/match-object.js
var require_match_object = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/match-object.js"(exports2, module2) {
    "use strict";
    var every = require_lib().prototypes.array.every;
    var concat = require_lib().prototypes.array.concat;
    var typeOf = require_lib().typeOf;
    var deepEqualFactory = require_deep_equal().use;
    var identical = require_identical();
    var isMatcher = require_is_matcher();
    var keys = Object.keys;
    var getOwnPropertySymbols = Object.getOwnPropertySymbols;
    function matchObject(actual, expectation, matcher) {
      var deepEqual = deepEqualFactory(matcher);
      if (actual === null || actual === void 0) {
        return false;
      }
      var expectedKeys = keys(expectation);
      if (typeOf(getOwnPropertySymbols) === "function") {
        expectedKeys = concat(expectedKeys, getOwnPropertySymbols(expectation));
      }
      return every(expectedKeys, function(key) {
        var exp = expectation[key];
        var act = actual[key];
        if (isMatcher(exp)) {
          if (!exp.test(act)) {
            return false;
          }
        } else if (typeOf(exp) === "object") {
          if (identical(exp, act)) {
            return true;
          }
          if (!matchObject(act, exp, matcher)) {
            return false;
          }
        } else if (!deepEqual(act, exp)) {
          return false;
        }
        return true;
      });
    }
    module2.exports = matchObject;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher/type-map.js
var require_type_map = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher/type-map.js"(exports2, module2) {
    "use strict";
    var functionName = require_lib().functionName;
    var join = require_lib().prototypes.array.join;
    var map = require_lib().prototypes.array.map;
    var stringIndexOf = require_lib().prototypes.string.indexOf;
    var valueToString = require_lib().valueToString;
    var matchObject = require_match_object();
    var createTypeMap = function(match) {
      return {
        function: function(m, expectation, message) {
          m.test = expectation;
          m.message = message || `match(${functionName(expectation)})`;
        },
        number: function(m, expectation) {
          m.test = function(actual) {
            return expectation == actual;
          };
        },
        object: function(m, expectation) {
          var array = [];
          if (typeof expectation.test === "function") {
            m.test = function(actual) {
              return expectation.test(actual) === true;
            };
            m.message = `match(${functionName(expectation.test)})`;
            return m;
          }
          array = map(Object.keys(expectation), function(key) {
            return `${key}: ${valueToString(expectation[key])}`;
          });
          m.test = function(actual) {
            return matchObject(actual, expectation, match);
          };
          m.message = `match(${join(array, ", ")})`;
          return m;
        },
        regexp: function(m, expectation) {
          m.test = function(actual) {
            return typeof actual === "string" && expectation.test(actual);
          };
        },
        string: function(m, expectation) {
          m.test = function(actual) {
            return typeof actual === "string" && stringIndexOf(actual, expectation) !== -1;
          };
          m.message = `match("${expectation}")`;
        }
      };
    };
    module2.exports = createTypeMap;
  }
});

// node_modules/@sinonjs/samsam/lib/create-matcher.js
var require_create_matcher = __commonJS({
  "node_modules/@sinonjs/samsam/lib/create-matcher.js"(exports2, module2) {
    "use strict";
    var arrayProto = require_lib().prototypes.array;
    var deepEqual = require_deep_equal().use(createMatcher);
    var every = require_lib().every;
    var functionName = require_lib().functionName;
    var iterableToString = require_iterable_to_string();
    var objectProto = require_lib().prototypes.object;
    var typeOf = require_lib().typeOf;
    var valueToString = require_lib().valueToString;
    var assertMatcher = require_assert_matcher();
    var assertMethodExists = require_assert_method_exists();
    var assertType = require_assert_type();
    var isIterable = require_is_iterable2();
    var isMatcher = require_is_matcher();
    var matcherPrototype = require_matcher_prototype();
    var arrayIndexOf = arrayProto.indexOf;
    var some = arrayProto.some;
    var hasOwnProperty = objectProto.hasOwnProperty;
    var objectToString = objectProto.toString;
    var TYPE_MAP = require_type_map()(createMatcher);
    function createMatcher(expectation, message) {
      var m = Object.create(matcherPrototype);
      var type = typeOf(expectation);
      if (message !== void 0 && typeof message !== "string") {
        throw new TypeError("Message should be a string");
      }
      if (arguments.length > 2) {
        throw new TypeError(
          `Expected 1 or 2 arguments, received ${arguments.length}`
        );
      }
      if (type in TYPE_MAP) {
        TYPE_MAP[type](m, expectation, message);
      } else {
        m.test = function(actual) {
          return deepEqual(actual, expectation);
        };
      }
      if (!m.message) {
        m.message = `match(${valueToString(expectation)})`;
      }
      Object.defineProperty(m, "message", {
        configurable: false,
        writable: false,
        value: m.message
      });
      return m;
    }
    createMatcher.isMatcher = isMatcher;
    createMatcher.any = createMatcher(function() {
      return true;
    }, "any");
    createMatcher.defined = createMatcher(function(actual) {
      return actual !== null && actual !== void 0;
    }, "defined");
    createMatcher.truthy = createMatcher(function(actual) {
      return Boolean(actual);
    }, "truthy");
    createMatcher.falsy = createMatcher(function(actual) {
      return !actual;
    }, "falsy");
    createMatcher.same = function(expectation) {
      return createMatcher(
        function(actual) {
          return expectation === actual;
        },
        `same(${valueToString(expectation)})`
      );
    };
    createMatcher.in = function(arrayOfExpectations) {
      if (typeOf(arrayOfExpectations) !== "array") {
        throw new TypeError("array expected");
      }
      return createMatcher(
        function(actual) {
          return some(arrayOfExpectations, function(expectation) {
            return expectation === actual;
          });
        },
        `in(${valueToString(arrayOfExpectations)})`
      );
    };
    createMatcher.typeOf = function(type) {
      assertType(type, "string", "type");
      return createMatcher(function(actual) {
        return typeOf(actual) === type;
      }, `typeOf("${type}")`);
    };
    createMatcher.instanceOf = function(type) {
      if (typeof Symbol === "undefined" || typeof Symbol.hasInstance === "undefined") {
        assertType(type, "function", "type");
      } else {
        assertMethodExists(
          type,
          Symbol.hasInstance,
          "type",
          "[Symbol.hasInstance]"
        );
      }
      return createMatcher(
        function(actual) {
          return actual instanceof type;
        },
        `instanceOf(${functionName(type) || objectToString(type)})`
      );
    };
    function createPropertyMatcher(propertyTest, messagePrefix) {
      return function(property, value) {
        assertType(property, "string", "property");
        var onlyProperty = arguments.length === 1;
        var message = `${messagePrefix}("${property}"`;
        if (!onlyProperty) {
          message += `, ${valueToString(value)}`;
        }
        message += ")";
        return createMatcher(function(actual) {
          if (actual === void 0 || actual === null || !propertyTest(actual, property)) {
            return false;
          }
          return onlyProperty || deepEqual(actual[property], value);
        }, message);
      };
    }
    createMatcher.has = createPropertyMatcher(function(actual, property) {
      if (typeof actual === "object") {
        return property in actual;
      }
      return actual[property] !== void 0;
    }, "has");
    createMatcher.hasOwn = createPropertyMatcher(function(actual, property) {
      return hasOwnProperty(actual, property);
    }, "hasOwn");
    createMatcher.hasNested = function(property, value) {
      assertType(property, "string", "property");
      var onlyProperty = arguments.length === 1;
      var message = `hasNested("${property}"`;
      if (!onlyProperty) {
        message += `, ${valueToString(value)}`;
      }
      message += ")";
      return createMatcher(function(actual) {
        const parts = property.split(/(?:\.|\[|\])+?/).filter(Boolean);
        let current = actual;
        for (const part of parts) {
          current = current?.[part];
          if (current === void 0) {
            return false;
          }
        }
        return onlyProperty || deepEqual(current, value);
      }, message);
    };
    var jsonParseResultTypes = {
      null: true,
      boolean: true,
      number: true,
      string: true,
      object: true,
      array: true
    };
    createMatcher.json = function(value) {
      if (!jsonParseResultTypes[typeOf(value)]) {
        throw new TypeError("Value cannot be the result of JSON.parse");
      }
      var message = `json(${JSON.stringify(value, null, "  ")})`;
      return createMatcher(function(actual) {
        var parsed;
        try {
          parsed = JSON.parse(actual);
        } catch (e) {
          return false;
        }
        return deepEqual(parsed, value);
      }, message);
    };
    createMatcher.every = function(predicate) {
      assertMatcher(predicate);
      return createMatcher(function(actual) {
        if (typeOf(actual) === "object") {
          return every(Object.keys(actual), function(key) {
            return predicate.test(actual[key]);
          });
        }
        return isIterable(actual) && every(actual, function(element) {
          return predicate.test(element);
        });
      }, `every(${predicate.message})`);
    };
    createMatcher.some = function(predicate) {
      assertMatcher(predicate);
      return createMatcher(function(actual) {
        if (typeOf(actual) === "object") {
          return !every(Object.keys(actual), function(key) {
            return !predicate.test(actual[key]);
          });
        }
        return isIterable(actual) && !every(actual, function(element) {
          return !predicate.test(element);
        });
      }, `some(${predicate.message})`);
    };
    createMatcher.array = createMatcher.typeOf("array");
    createMatcher.array.deepEquals = function(expectation) {
      return createMatcher(
        function(actual) {
          var sameLength = actual.length === expectation.length;
          return typeOf(actual) === "array" && sameLength && every(actual, function(element, index) {
            var expected = expectation[index];
            return typeOf(expected) === "array" && typeOf(element) === "array" ? createMatcher.array.deepEquals(expected).test(element) : deepEqual(expected, element);
          });
        },
        `deepEquals([${iterableToString(expectation)}])`
      );
    };
    createMatcher.array.startsWith = function(expectation) {
      return createMatcher(
        function(actual) {
          return typeOf(actual) === "array" && every(expectation, function(expectedElement, index) {
            return actual[index] === expectedElement;
          });
        },
        `startsWith([${iterableToString(expectation)}])`
      );
    };
    createMatcher.array.endsWith = function(expectation) {
      return createMatcher(
        function(actual) {
          var offset = actual.length - expectation.length;
          return typeOf(actual) === "array" && every(expectation, function(expectedElement, index) {
            return actual[offset + index] === expectedElement;
          });
        },
        `endsWith([${iterableToString(expectation)}])`
      );
    };
    createMatcher.array.contains = function(expectation) {
      return createMatcher(
        function(actual) {
          return typeOf(actual) === "array" && every(expectation, function(expectedElement) {
            return arrayIndexOf(actual, expectedElement) !== -1;
          });
        },
        `contains([${iterableToString(expectation)}])`
      );
    };
    createMatcher.map = createMatcher.typeOf("map");
    createMatcher.map.deepEquals = function mapDeepEquals(expectation) {
      return createMatcher(
        function(actual) {
          var sameLength = actual.size === expectation.size;
          return typeOf(actual) === "map" && sameLength && every(actual, function(element, key) {
            return expectation.has(key) && expectation.get(key) === element;
          });
        },
        `deepEquals(Map[${iterableToString(expectation)}])`
      );
    };
    createMatcher.map.contains = function mapContains(expectation) {
      return createMatcher(
        function(actual) {
          return typeOf(actual) === "map" && every(expectation, function(element, key) {
            return actual.has(key) && actual.get(key) === element;
          });
        },
        `contains(Map[${iterableToString(expectation)}])`
      );
    };
    createMatcher.set = createMatcher.typeOf("set");
    createMatcher.set.deepEquals = function setDeepEquals(expectation) {
      return createMatcher(
        function(actual) {
          var sameLength = actual.size === expectation.size;
          return typeOf(actual) === "set" && sameLength && every(actual, function(element) {
            return expectation.has(element);
          });
        },
        `deepEquals(Set[${iterableToString(expectation)}])`
      );
    };
    createMatcher.set.contains = function setContains(expectation) {
      return createMatcher(
        function(actual) {
          return typeOf(actual) === "set" && every(expectation, function(element) {
            return actual.has(element);
          });
        },
        `contains(Set[${iterableToString(expectation)}])`
      );
    };
    createMatcher.bool = createMatcher.typeOf("boolean");
    createMatcher.number = createMatcher.typeOf("number");
    createMatcher.string = createMatcher.typeOf("string");
    createMatcher.object = createMatcher.typeOf("object");
    createMatcher.func = createMatcher.typeOf("function");
    createMatcher.regexp = createMatcher.typeOf("regexp");
    createMatcher.date = createMatcher.typeOf("date");
    createMatcher.symbol = createMatcher.typeOf("symbol");
    module2.exports = createMatcher;
  }
});

// node_modules/@sinonjs/samsam/lib/match.js
var require_match = __commonJS({
  "node_modules/@sinonjs/samsam/lib/match.js"(exports2, module2) {
    "use strict";
    var valueToString = require_lib().valueToString;
    var indexOf = require_lib().prototypes.string.indexOf;
    var forEach = require_lib().prototypes.array.forEach;
    var type = require_type_detect2();
    var engineCanCompareMaps = typeof Array.from === "function";
    var deepEqual = require_deep_equal().use(match);
    var isArrayType = require_is_array_type();
    var isSubset = require_is_subset();
    var createMatcher = require_create_matcher();
    function arrayContains(array, subset, compare) {
      if (subset.length === 0) {
        return true;
      }
      var i, l, j, k;
      for (i = 0, l = array.length; i < l; ++i) {
        if (compare(array[i], subset[0])) {
          for (j = 0, k = subset.length; j < k; ++j) {
            if (i + j >= l) {
              return false;
            }
            if (!compare(array[i + j], subset[j])) {
              return false;
            }
          }
          return true;
        }
      }
      return false;
    }
    function match(object, matcherOrValue) {
      if (matcherOrValue && typeof matcherOrValue.test === "function") {
        return matcherOrValue.test(object);
      }
      switch (type(matcherOrValue)) {
        case "bigint":
        case "boolean":
        case "number":
        case "symbol":
          return matcherOrValue === object;
        case "function":
          return matcherOrValue(object) === true;
        case "string":
          var notNull = typeof object === "string" || Boolean(object);
          return notNull && indexOf(
            valueToString(object).toLowerCase(),
            matcherOrValue.toLowerCase()
          ) >= 0;
        case "null":
          return object === null;
        case "undefined":
          return typeof object === "undefined";
        case "Date":
          if (type(object) === "Date") {
            return object.getTime() === matcherOrValue.getTime();
          }
          break;
        case "Array":
        case "Int8Array":
        case "Uint8Array":
        case "Uint8ClampedArray":
        case "Int16Array":
        case "Uint16Array":
        case "Int32Array":
        case "Uint32Array":
        case "Float32Array":
        case "Float64Array":
          return isArrayType(matcherOrValue) && arrayContains(object, matcherOrValue, match);
        case "Map":
          if (!engineCanCompareMaps) {
            throw new Error(
              "The JavaScript engine does not support Array.from and cannot reliably do value comparison of Map instances"
            );
          }
          return type(object) === "Map" && arrayContains(
            Array.from(object),
            Array.from(matcherOrValue),
            match
          );
        default:
          break;
      }
      switch (type(object)) {
        case "null":
          return false;
        case "Set":
          return isSubset(matcherOrValue, object, match);
        default:
          break;
      }
      if (matcherOrValue && typeof matcherOrValue === "object") {
        if (matcherOrValue === object) {
          return true;
        }
        if (typeof object !== "object") {
          return false;
        }
        var prop;
        for (prop in matcherOrValue) {
          var value = object[prop];
          if (typeof value === "undefined" && typeof object.getAttribute === "function") {
            value = object.getAttribute(prop);
          }
          if (matcherOrValue[prop] === null || typeof matcherOrValue[prop] === "undefined") {
            if (value !== matcherOrValue[prop]) {
              return false;
            }
          } else if (typeof value === "undefined" || !deepEqual(value, matcherOrValue[prop])) {
            return false;
          }
        }
        return true;
      }
      throw new Error("Matcher was an unknown or unsupported type");
    }
    forEach(Object.keys(createMatcher), function(key) {
      match[key] = createMatcher[key];
    });
    module2.exports = match;
  }
});

// node_modules/@sinonjs/samsam/lib/samsam.js
var require_samsam = __commonJS({
  "node_modules/@sinonjs/samsam/lib/samsam.js"(exports2, module2) {
    "use strict";
    var identical = require_identical();
    var isArguments = require_is_arguments();
    var isElement = require_is_element();
    var isNegZero = require_is_neg_zero();
    var isSet = require_is_set();
    var isMap = require_is_map();
    var match = require_match();
    var deepEqualCyclic = require_deep_equal().use(match);
    var createMatcher = require_create_matcher();
    module2.exports = {
      createMatcher,
      deepEqual: deepEqualCyclic,
      identical,
      isArguments,
      isElement,
      isMap,
      isNegZero,
      isSet,
      match
    };
  }
});

// lib/sinon/util/core/walk.js
var require_walk = __commonJS({
  "lib/sinon/util/core/walk.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var forEach = prototypes.array.forEach;
    function walkInternal(obj, iterator, context, originalObj, seen) {
      let prop;
      const proto = Object.getPrototypeOf(obj);
      if (typeof Object.getOwnPropertyNames !== "function") {
        for (prop in obj) {
          iterator.call(context, obj[prop], prop, obj);
        }
        return;
      }
      forEach(Object.getOwnPropertyNames(obj), function(k) {
        if (k !== "__proto__" && seen[k] !== true) {
          seen[k] = true;
          const target = typeof Object.getOwnPropertyDescriptor(obj, k).get === "function" ? originalObj : obj;
          iterator.call(context, k, target);
        }
      });
      if (proto) {
        walkInternal(proto, iterator, context, originalObj, seen);
      }
    }
    var walk = function(obj, iterator, context) {
      return walkInternal(obj, iterator, context, obj, /* @__PURE__ */ Object.create(null));
    };
    module2.exports = walk;
  }
});

// lib/sinon/util/core/get-property-descriptor.js
var require_get_property_descriptor = __commonJS({
  "lib/sinon/util/core/get-property-descriptor.js"(exports2, module2) {
    "use strict";
    function getPropertyDescriptor(object, property) {
      let proto = object;
      let descriptor;
      const isOwn = Boolean(
        object && Object.getOwnPropertyDescriptor(object, property)
      );
      while (proto && !(descriptor = Object.getOwnPropertyDescriptor(proto, property))) {
        proto = Object.getPrototypeOf(proto);
      }
      if (descriptor) {
        descriptor.isOwn = isOwn;
      }
      return descriptor;
    }
    module2.exports = getPropertyDescriptor;
  }
});

// lib/sinon/collect-own-methods.js
var require_collect_own_methods = __commonJS({
  "lib/sinon/collect-own-methods.js"(exports2, module2) {
    "use strict";
    var walk = require_walk();
    var getPropertyDescriptor = require_get_property_descriptor();
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { hasOwnProperty } = prototypes.object;
    var { push } = prototypes.array;
    function collectMethod(methods, object, prop, propOwner) {
      const descriptor = getPropertyDescriptor(propOwner, prop);
      const value = descriptor.value;
      if (typeof value === "function" && hasOwnProperty(object, prop) && value && value.restore && value.restore.sinon) {
        push(methods, value);
      }
    }
    function collectOwnMethods(object) {
      const methods = [];
      walk(object, collectMethod.bind(null, methods, object));
      return methods;
    }
    module2.exports = collectOwnMethods;
  }
});

// lib/sinon/util/core/times-in-words.js
var require_times_in_words = __commonJS({
  "lib/sinon/util/core/times-in-words.js"(exports2, module2) {
    "use strict";
    var array = [null, "once", "twice", "thrice"];
    function timesInWords(count) {
      return array[count] || `${count || 0} times`;
    }
    module2.exports = timesInWords;
  }
});

// node_modules/has-symbols/shams.js
var require_shams = __commonJS({
  "node_modules/has-symbols/shams.js"(exports2, module2) {
    "use strict";
    module2.exports = function hasSymbols() {
      if (typeof Symbol !== "function" || typeof Object.getOwnPropertySymbols !== "function") {
        return false;
      }
      if (typeof Symbol.iterator === "symbol") {
        return true;
      }
      var obj = {};
      var sym = /* @__PURE__ */ Symbol("test");
      var symObj = Object(sym);
      if (typeof sym === "string") {
        return false;
      }
      if (Object.prototype.toString.call(sym) !== "[object Symbol]") {
        return false;
      }
      if (Object.prototype.toString.call(symObj) !== "[object Symbol]") {
        return false;
      }
      var symVal = 42;
      obj[sym] = symVal;
      for (var _ in obj) {
        return false;
      }
      if (typeof Object.keys === "function" && Object.keys(obj).length !== 0) {
        return false;
      }
      if (typeof Object.getOwnPropertyNames === "function" && Object.getOwnPropertyNames(obj).length !== 0) {
        return false;
      }
      var syms = Object.getOwnPropertySymbols(obj);
      if (syms.length !== 1 || syms[0] !== sym) {
        return false;
      }
      if (!Object.prototype.propertyIsEnumerable.call(obj, sym)) {
        return false;
      }
      if (typeof Object.getOwnPropertyDescriptor === "function") {
        var descriptor = (
          /** @type {PropertyDescriptor} */
          Object.getOwnPropertyDescriptor(obj, sym)
        );
        if (descriptor.value !== symVal || descriptor.enumerable !== true) {
          return false;
        }
      }
      return true;
    };
  }
});

// node_modules/has-tostringtag/shams.js
var require_shams2 = __commonJS({
  "node_modules/has-tostringtag/shams.js"(exports2, module2) {
    "use strict";
    var hasSymbols = require_shams();
    module2.exports = function hasToStringTagShams() {
      return hasSymbols() && !!Symbol.toStringTag;
    };
  }
});

// node_modules/es-object-atoms/index.js
var require_es_object_atoms = __commonJS({
  "node_modules/es-object-atoms/index.js"(exports2, module2) {
    "use strict";
    module2.exports = Object;
  }
});

// node_modules/es-errors/index.js
var require_es_errors = __commonJS({
  "node_modules/es-errors/index.js"(exports2, module2) {
    "use strict";
    module2.exports = Error;
  }
});

// node_modules/es-errors/eval.js
var require_eval = __commonJS({
  "node_modules/es-errors/eval.js"(exports2, module2) {
    "use strict";
    module2.exports = EvalError;
  }
});

// node_modules/es-errors/range.js
var require_range = __commonJS({
  "node_modules/es-errors/range.js"(exports2, module2) {
    "use strict";
    module2.exports = RangeError;
  }
});

// node_modules/es-errors/ref.js
var require_ref = __commonJS({
  "node_modules/es-errors/ref.js"(exports2, module2) {
    "use strict";
    module2.exports = ReferenceError;
  }
});

// node_modules/es-errors/syntax.js
var require_syntax = __commonJS({
  "node_modules/es-errors/syntax.js"(exports2, module2) {
    "use strict";
    module2.exports = SyntaxError;
  }
});

// node_modules/es-errors/type.js
var require_type = __commonJS({
  "node_modules/es-errors/type.js"(exports2, module2) {
    "use strict";
    module2.exports = TypeError;
  }
});

// node_modules/es-errors/uri.js
var require_uri = __commonJS({
  "node_modules/es-errors/uri.js"(exports2, module2) {
    "use strict";
    module2.exports = URIError;
  }
});

// node_modules/math-intrinsics/abs.js
var require_abs = __commonJS({
  "node_modules/math-intrinsics/abs.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.abs;
  }
});

// node_modules/math-intrinsics/floor.js
var require_floor = __commonJS({
  "node_modules/math-intrinsics/floor.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.floor;
  }
});

// node_modules/math-intrinsics/max.js
var require_max = __commonJS({
  "node_modules/math-intrinsics/max.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.max;
  }
});

// node_modules/math-intrinsics/min.js
var require_min = __commonJS({
  "node_modules/math-intrinsics/min.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.min;
  }
});

// node_modules/math-intrinsics/pow.js
var require_pow = __commonJS({
  "node_modules/math-intrinsics/pow.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.pow;
  }
});

// node_modules/math-intrinsics/round.js
var require_round = __commonJS({
  "node_modules/math-intrinsics/round.js"(exports2, module2) {
    "use strict";
    module2.exports = Math.round;
  }
});

// node_modules/math-intrinsics/isNaN.js
var require_isNaN = __commonJS({
  "node_modules/math-intrinsics/isNaN.js"(exports2, module2) {
    "use strict";
    module2.exports = Number.isNaN || function isNaN2(a) {
      return a !== a;
    };
  }
});

// node_modules/math-intrinsics/sign.js
var require_sign = __commonJS({
  "node_modules/math-intrinsics/sign.js"(exports2, module2) {
    "use strict";
    var $isNaN = require_isNaN();
    module2.exports = function sign(number) {
      if ($isNaN(number) || number === 0) {
        return number;
      }
      return number < 0 ? -1 : 1;
    };
  }
});

// node_modules/gopd/gOPD.js
var require_gOPD = __commonJS({
  "node_modules/gopd/gOPD.js"(exports2, module2) {
    "use strict";
    module2.exports = Object.getOwnPropertyDescriptor;
  }
});

// node_modules/gopd/index.js
var require_gopd = __commonJS({
  "node_modules/gopd/index.js"(exports2, module2) {
    "use strict";
    var $gOPD = require_gOPD();
    if ($gOPD) {
      try {
        $gOPD([], "length");
      } catch (e) {
        $gOPD = null;
      }
    }
    module2.exports = $gOPD;
  }
});

// node_modules/es-define-property/index.js
var require_es_define_property = __commonJS({
  "node_modules/es-define-property/index.js"(exports2, module2) {
    "use strict";
    var $defineProperty = Object.defineProperty || false;
    if ($defineProperty) {
      try {
        $defineProperty({}, "a", { value: 1 });
      } catch (e) {
        $defineProperty = false;
      }
    }
    module2.exports = $defineProperty;
  }
});

// node_modules/has-symbols/index.js
var require_has_symbols = __commonJS({
  "node_modules/has-symbols/index.js"(exports2, module2) {
    "use strict";
    var origSymbol = typeof Symbol !== "undefined" && Symbol;
    var hasSymbolSham = require_shams();
    module2.exports = function hasNativeSymbols() {
      if (typeof origSymbol !== "function") {
        return false;
      }
      if (typeof Symbol !== "function") {
        return false;
      }
      if (typeof origSymbol("foo") !== "symbol") {
        return false;
      }
      if (typeof /* @__PURE__ */ Symbol("bar") !== "symbol") {
        return false;
      }
      return hasSymbolSham();
    };
  }
});

// node_modules/get-proto/Reflect.getPrototypeOf.js
var require_Reflect_getPrototypeOf = __commonJS({
  "node_modules/get-proto/Reflect.getPrototypeOf.js"(exports2, module2) {
    "use strict";
    module2.exports = typeof Reflect !== "undefined" && Reflect.getPrototypeOf || null;
  }
});

// node_modules/get-proto/Object.getPrototypeOf.js
var require_Object_getPrototypeOf = __commonJS({
  "node_modules/get-proto/Object.getPrototypeOf.js"(exports2, module2) {
    "use strict";
    var $Object = require_es_object_atoms();
    module2.exports = $Object.getPrototypeOf || null;
  }
});

// node_modules/function-bind/implementation.js
var require_implementation = __commonJS({
  "node_modules/function-bind/implementation.js"(exports2, module2) {
    "use strict";
    var ERROR_MESSAGE = "Function.prototype.bind called on incompatible ";
    var toStr = Object.prototype.toString;
    var max = Math.max;
    var funcType = "[object Function]";
    var concatty = function concatty2(a, b) {
      var arr = [];
      for (var i = 0; i < a.length; i += 1) {
        arr[i] = a[i];
      }
      for (var j = 0; j < b.length; j += 1) {
        arr[j + a.length] = b[j];
      }
      return arr;
    };
    var slicy = function slicy2(arrLike, offset) {
      var arr = [];
      for (var i = offset || 0, j = 0; i < arrLike.length; i += 1, j += 1) {
        arr[j] = arrLike[i];
      }
      return arr;
    };
    var joiny = function(arr, joiner) {
      var str = "";
      for (var i = 0; i < arr.length; i += 1) {
        str += arr[i];
        if (i + 1 < arr.length) {
          str += joiner;
        }
      }
      return str;
    };
    module2.exports = function bind(that) {
      var target = this;
      if (typeof target !== "function" || toStr.apply(target) !== funcType) {
        throw new TypeError(ERROR_MESSAGE + target);
      }
      var args = slicy(arguments, 1);
      var bound;
      var binder = function() {
        if (this instanceof bound) {
          var result = target.apply(
            this,
            concatty(args, arguments)
          );
          if (Object(result) === result) {
            return result;
          }
          return this;
        }
        return target.apply(
          that,
          concatty(args, arguments)
        );
      };
      var boundLength = max(0, target.length - args.length);
      var boundArgs = [];
      for (var i = 0; i < boundLength; i++) {
        boundArgs[i] = "$" + i;
      }
      bound = Function("binder", "return function (" + joiny(boundArgs, ",") + "){ return binder.apply(this,arguments); }")(binder);
      if (target.prototype) {
        var Empty = function Empty2() {
        };
        Empty.prototype = target.prototype;
        bound.prototype = new Empty();
        Empty.prototype = null;
      }
      return bound;
    };
  }
});

// node_modules/function-bind/index.js
var require_function_bind = __commonJS({
  "node_modules/function-bind/index.js"(exports2, module2) {
    "use strict";
    var implementation = require_implementation();
    module2.exports = Function.prototype.bind || implementation;
  }
});

// node_modules/call-bind-apply-helpers/functionCall.js
var require_functionCall = __commonJS({
  "node_modules/call-bind-apply-helpers/functionCall.js"(exports2, module2) {
    "use strict";
    module2.exports = Function.prototype.call;
  }
});

// node_modules/call-bind-apply-helpers/functionApply.js
var require_functionApply = __commonJS({
  "node_modules/call-bind-apply-helpers/functionApply.js"(exports2, module2) {
    "use strict";
    module2.exports = Function.prototype.apply;
  }
});

// node_modules/call-bind-apply-helpers/reflectApply.js
var require_reflectApply = __commonJS({
  "node_modules/call-bind-apply-helpers/reflectApply.js"(exports2, module2) {
    "use strict";
    module2.exports = typeof Reflect !== "undefined" && Reflect && Reflect.apply;
  }
});

// node_modules/call-bind-apply-helpers/actualApply.js
var require_actualApply = __commonJS({
  "node_modules/call-bind-apply-helpers/actualApply.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    var $apply = require_functionApply();
    var $call = require_functionCall();
    var $reflectApply = require_reflectApply();
    module2.exports = $reflectApply || bind.call($call, $apply);
  }
});

// node_modules/call-bind-apply-helpers/index.js
var require_call_bind_apply_helpers = __commonJS({
  "node_modules/call-bind-apply-helpers/index.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    var $TypeError = require_type();
    var $call = require_functionCall();
    var $actualApply = require_actualApply();
    module2.exports = function callBindBasic(args) {
      if (args.length < 1 || typeof args[0] !== "function") {
        throw new $TypeError("a function is required");
      }
      return $actualApply(bind, $call, args);
    };
  }
});

// node_modules/dunder-proto/get.js
var require_get = __commonJS({
  "node_modules/dunder-proto/get.js"(exports2, module2) {
    "use strict";
    var callBind = require_call_bind_apply_helpers();
    var gOPD = require_gopd();
    var hasProtoAccessor;
    try {
      hasProtoAccessor = /** @type {{ __proto__?: typeof Array.prototype }} */
      [].__proto__ === Array.prototype;
    } catch (e) {
      if (!e || typeof e !== "object" || !("code" in e) || e.code !== "ERR_PROTO_ACCESS") {
        throw e;
      }
    }
    var desc = !!hasProtoAccessor && gOPD && gOPD(
      Object.prototype,
      /** @type {keyof typeof Object.prototype} */
      "__proto__"
    );
    var $Object = Object;
    var $getPrototypeOf = $Object.getPrototypeOf;
    module2.exports = desc && typeof desc.get === "function" ? callBind([desc.get]) : typeof $getPrototypeOf === "function" ? (
      /** @type {import('./get')} */
      function getDunder(value) {
        return $getPrototypeOf(value == null ? value : $Object(value));
      }
    ) : false;
  }
});

// node_modules/get-proto/index.js
var require_get_proto = __commonJS({
  "node_modules/get-proto/index.js"(exports2, module2) {
    "use strict";
    var reflectGetProto = require_Reflect_getPrototypeOf();
    var originalGetProto = require_Object_getPrototypeOf();
    var getDunderProto = require_get();
    module2.exports = reflectGetProto ? function getProto(O) {
      return reflectGetProto(O);
    } : originalGetProto ? function getProto(O) {
      if (!O || typeof O !== "object" && typeof O !== "function") {
        throw new TypeError("getProto: not an object");
      }
      return originalGetProto(O);
    } : getDunderProto ? function getProto(O) {
      return getDunderProto(O);
    } : null;
  }
});

// node_modules/hasown/index.js
var require_hasown = __commonJS({
  "node_modules/hasown/index.js"(exports2, module2) {
    "use strict";
    var call = Function.prototype.call;
    var $hasOwn = Object.prototype.hasOwnProperty;
    var bind = require_function_bind();
    module2.exports = bind.call(call, $hasOwn);
  }
});

// node_modules/get-intrinsic/index.js
var require_get_intrinsic = __commonJS({
  "node_modules/get-intrinsic/index.js"(exports2, module2) {
    "use strict";
    var undefined2;
    var $Object = require_es_object_atoms();
    var $Error = require_es_errors();
    var $EvalError = require_eval();
    var $RangeError = require_range();
    var $ReferenceError = require_ref();
    var $SyntaxError = require_syntax();
    var $TypeError = require_type();
    var $URIError = require_uri();
    var abs = require_abs();
    var floor = require_floor();
    var max = require_max();
    var min = require_min();
    var pow = require_pow();
    var round = require_round();
    var sign = require_sign();
    var $Function = Function;
    var getEvalledConstructor = function(expressionSyntax) {
      try {
        return $Function('"use strict"; return (' + expressionSyntax + ").constructor;")();
      } catch (e) {
      }
    };
    var $gOPD = require_gopd();
    var $defineProperty = require_es_define_property();
    var throwTypeError = function() {
      throw new $TypeError();
    };
    var ThrowTypeError = $gOPD ? (function() {
      try {
        arguments.callee;
        return throwTypeError;
      } catch (calleeThrows) {
        try {
          return $gOPD(arguments, "callee").get;
        } catch (gOPDthrows) {
          return throwTypeError;
        }
      }
    })() : throwTypeError;
    var hasSymbols = require_has_symbols()();
    var getProto = require_get_proto();
    var $ObjectGPO = require_Object_getPrototypeOf();
    var $ReflectGPO = require_Reflect_getPrototypeOf();
    var $apply = require_functionApply();
    var $call = require_functionCall();
    var needsEval = {};
    var TypedArray = typeof Uint8Array === "undefined" || !getProto ? undefined2 : getProto(Uint8Array);
    var INTRINSICS = {
      __proto__: null,
      "%AggregateError%": typeof AggregateError === "undefined" ? undefined2 : AggregateError,
      "%Array%": Array,
      "%ArrayBuffer%": typeof ArrayBuffer === "undefined" ? undefined2 : ArrayBuffer,
      "%ArrayIteratorPrototype%": hasSymbols && getProto ? getProto([][Symbol.iterator]()) : undefined2,
      "%AsyncFromSyncIteratorPrototype%": undefined2,
      "%AsyncFunction%": needsEval,
      "%AsyncGenerator%": needsEval,
      "%AsyncGeneratorFunction%": needsEval,
      "%AsyncIteratorPrototype%": needsEval,
      "%Atomics%": typeof Atomics === "undefined" ? undefined2 : Atomics,
      "%BigInt%": typeof BigInt === "undefined" ? undefined2 : BigInt,
      "%BigInt64Array%": typeof BigInt64Array === "undefined" ? undefined2 : BigInt64Array,
      "%BigUint64Array%": typeof BigUint64Array === "undefined" ? undefined2 : BigUint64Array,
      "%Boolean%": Boolean,
      "%DataView%": typeof DataView === "undefined" ? undefined2 : DataView,
      "%Date%": Date,
      "%decodeURI%": decodeURI,
      "%decodeURIComponent%": decodeURIComponent,
      "%encodeURI%": encodeURI,
      "%encodeURIComponent%": encodeURIComponent,
      "%Error%": $Error,
      "%eval%": eval,
      // eslint-disable-line no-eval
      "%EvalError%": $EvalError,
      "%Float16Array%": typeof Float16Array === "undefined" ? undefined2 : Float16Array,
      "%Float32Array%": typeof Float32Array === "undefined" ? undefined2 : Float32Array,
      "%Float64Array%": typeof Float64Array === "undefined" ? undefined2 : Float64Array,
      "%FinalizationRegistry%": typeof FinalizationRegistry === "undefined" ? undefined2 : FinalizationRegistry,
      "%Function%": $Function,
      "%GeneratorFunction%": needsEval,
      "%Int8Array%": typeof Int8Array === "undefined" ? undefined2 : Int8Array,
      "%Int16Array%": typeof Int16Array === "undefined" ? undefined2 : Int16Array,
      "%Int32Array%": typeof Int32Array === "undefined" ? undefined2 : Int32Array,
      "%isFinite%": isFinite,
      "%isNaN%": isNaN,
      "%IteratorPrototype%": hasSymbols && getProto ? getProto(getProto([][Symbol.iterator]())) : undefined2,
      "%JSON%": typeof JSON === "object" ? JSON : undefined2,
      "%Map%": typeof Map === "undefined" ? undefined2 : Map,
      "%MapIteratorPrototype%": typeof Map === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Map())[Symbol.iterator]()),
      "%Math%": Math,
      "%Number%": Number,
      "%Object%": $Object,
      "%Object.getOwnPropertyDescriptor%": $gOPD,
      "%parseFloat%": parseFloat,
      "%parseInt%": parseInt,
      "%Promise%": typeof Promise === "undefined" ? undefined2 : Promise,
      "%Proxy%": typeof Proxy === "undefined" ? undefined2 : Proxy,
      "%RangeError%": $RangeError,
      "%ReferenceError%": $ReferenceError,
      "%Reflect%": typeof Reflect === "undefined" ? undefined2 : Reflect,
      "%RegExp%": RegExp,
      "%Set%": typeof Set === "undefined" ? undefined2 : Set,
      "%SetIteratorPrototype%": typeof Set === "undefined" || !hasSymbols || !getProto ? undefined2 : getProto((/* @__PURE__ */ new Set())[Symbol.iterator]()),
      "%SharedArrayBuffer%": typeof SharedArrayBuffer === "undefined" ? undefined2 : SharedArrayBuffer,
      "%String%": String,
      "%StringIteratorPrototype%": hasSymbols && getProto ? getProto(""[Symbol.iterator]()) : undefined2,
      "%Symbol%": hasSymbols ? Symbol : undefined2,
      "%SyntaxError%": $SyntaxError,
      "%ThrowTypeError%": ThrowTypeError,
      "%TypedArray%": TypedArray,
      "%TypeError%": $TypeError,
      "%Uint8Array%": typeof Uint8Array === "undefined" ? undefined2 : Uint8Array,
      "%Uint8ClampedArray%": typeof Uint8ClampedArray === "undefined" ? undefined2 : Uint8ClampedArray,
      "%Uint16Array%": typeof Uint16Array === "undefined" ? undefined2 : Uint16Array,
      "%Uint32Array%": typeof Uint32Array === "undefined" ? undefined2 : Uint32Array,
      "%URIError%": $URIError,
      "%WeakMap%": typeof WeakMap === "undefined" ? undefined2 : WeakMap,
      "%WeakRef%": typeof WeakRef === "undefined" ? undefined2 : WeakRef,
      "%WeakSet%": typeof WeakSet === "undefined" ? undefined2 : WeakSet,
      "%Function.prototype.call%": $call,
      "%Function.prototype.apply%": $apply,
      "%Object.defineProperty%": $defineProperty,
      "%Object.getPrototypeOf%": $ObjectGPO,
      "%Math.abs%": abs,
      "%Math.floor%": floor,
      "%Math.max%": max,
      "%Math.min%": min,
      "%Math.pow%": pow,
      "%Math.round%": round,
      "%Math.sign%": sign,
      "%Reflect.getPrototypeOf%": $ReflectGPO
    };
    if (getProto) {
      try {
        null.error;
      } catch (e) {
        errorProto = getProto(getProto(e));
        INTRINSICS["%Error.prototype%"] = errorProto;
      }
    }
    var errorProto;
    var doEval = function doEval2(name) {
      var value;
      if (name === "%AsyncFunction%") {
        value = getEvalledConstructor("async function () {}");
      } else if (name === "%GeneratorFunction%") {
        value = getEvalledConstructor("function* () {}");
      } else if (name === "%AsyncGeneratorFunction%") {
        value = getEvalledConstructor("async function* () {}");
      } else if (name === "%AsyncGenerator%") {
        var fn = doEval2("%AsyncGeneratorFunction%");
        if (fn) {
          value = fn.prototype;
        }
      } else if (name === "%AsyncIteratorPrototype%") {
        var gen = doEval2("%AsyncGenerator%");
        if (gen && getProto) {
          value = getProto(gen.prototype);
        }
      }
      INTRINSICS[name] = value;
      return value;
    };
    var LEGACY_ALIASES = {
      __proto__: null,
      "%ArrayBufferPrototype%": ["ArrayBuffer", "prototype"],
      "%ArrayPrototype%": ["Array", "prototype"],
      "%ArrayProto_entries%": ["Array", "prototype", "entries"],
      "%ArrayProto_forEach%": ["Array", "prototype", "forEach"],
      "%ArrayProto_keys%": ["Array", "prototype", "keys"],
      "%ArrayProto_values%": ["Array", "prototype", "values"],
      "%AsyncFunctionPrototype%": ["AsyncFunction", "prototype"],
      "%AsyncGenerator%": ["AsyncGeneratorFunction", "prototype"],
      "%AsyncGeneratorPrototype%": ["AsyncGeneratorFunction", "prototype", "prototype"],
      "%BooleanPrototype%": ["Boolean", "prototype"],
      "%DataViewPrototype%": ["DataView", "prototype"],
      "%DatePrototype%": ["Date", "prototype"],
      "%ErrorPrototype%": ["Error", "prototype"],
      "%EvalErrorPrototype%": ["EvalError", "prototype"],
      "%Float32ArrayPrototype%": ["Float32Array", "prototype"],
      "%Float64ArrayPrototype%": ["Float64Array", "prototype"],
      "%FunctionPrototype%": ["Function", "prototype"],
      "%Generator%": ["GeneratorFunction", "prototype"],
      "%GeneratorPrototype%": ["GeneratorFunction", "prototype", "prototype"],
      "%Int8ArrayPrototype%": ["Int8Array", "prototype"],
      "%Int16ArrayPrototype%": ["Int16Array", "prototype"],
      "%Int32ArrayPrototype%": ["Int32Array", "prototype"],
      "%JSONParse%": ["JSON", "parse"],
      "%JSONStringify%": ["JSON", "stringify"],
      "%MapPrototype%": ["Map", "prototype"],
      "%NumberPrototype%": ["Number", "prototype"],
      "%ObjectPrototype%": ["Object", "prototype"],
      "%ObjProto_toString%": ["Object", "prototype", "toString"],
      "%ObjProto_valueOf%": ["Object", "prototype", "valueOf"],
      "%PromisePrototype%": ["Promise", "prototype"],
      "%PromiseProto_then%": ["Promise", "prototype", "then"],
      "%Promise_all%": ["Promise", "all"],
      "%Promise_reject%": ["Promise", "reject"],
      "%Promise_resolve%": ["Promise", "resolve"],
      "%RangeErrorPrototype%": ["RangeError", "prototype"],
      "%ReferenceErrorPrototype%": ["ReferenceError", "prototype"],
      "%RegExpPrototype%": ["RegExp", "prototype"],
      "%SetPrototype%": ["Set", "prototype"],
      "%SharedArrayBufferPrototype%": ["SharedArrayBuffer", "prototype"],
      "%StringPrototype%": ["String", "prototype"],
      "%SymbolPrototype%": ["Symbol", "prototype"],
      "%SyntaxErrorPrototype%": ["SyntaxError", "prototype"],
      "%TypedArrayPrototype%": ["TypedArray", "prototype"],
      "%TypeErrorPrototype%": ["TypeError", "prototype"],
      "%Uint8ArrayPrototype%": ["Uint8Array", "prototype"],
      "%Uint8ClampedArrayPrototype%": ["Uint8ClampedArray", "prototype"],
      "%Uint16ArrayPrototype%": ["Uint16Array", "prototype"],
      "%Uint32ArrayPrototype%": ["Uint32Array", "prototype"],
      "%URIErrorPrototype%": ["URIError", "prototype"],
      "%WeakMapPrototype%": ["WeakMap", "prototype"],
      "%WeakSetPrototype%": ["WeakSet", "prototype"]
    };
    var bind = require_function_bind();
    var hasOwn = require_hasown();
    var $concat = bind.call($call, Array.prototype.concat);
    var $spliceApply = bind.call($apply, Array.prototype.splice);
    var $replace = bind.call($call, String.prototype.replace);
    var $strSlice = bind.call($call, String.prototype.slice);
    var $exec = bind.call($call, RegExp.prototype.exec);
    var rePropName = /[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g;
    var reEscapeChar = /\\(\\)?/g;
    var stringToPath = function stringToPath2(string) {
      var first = $strSlice(string, 0, 1);
      var last = $strSlice(string, -1);
      if (first === "%" && last !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected closing `%`");
      } else if (last === "%" && first !== "%") {
        throw new $SyntaxError("invalid intrinsic syntax, expected opening `%`");
      }
      var result = [];
      $replace(string, rePropName, function(match, number, quote, subString) {
        result[result.length] = quote ? $replace(subString, reEscapeChar, "$1") : number || match;
      });
      return result;
    };
    var getBaseIntrinsic = function getBaseIntrinsic2(name, allowMissing) {
      var intrinsicName = name;
      var alias;
      if (hasOwn(LEGACY_ALIASES, intrinsicName)) {
        alias = LEGACY_ALIASES[intrinsicName];
        intrinsicName = "%" + alias[0] + "%";
      }
      if (hasOwn(INTRINSICS, intrinsicName)) {
        var value = INTRINSICS[intrinsicName];
        if (value === needsEval) {
          value = doEval(intrinsicName);
        }
        if (typeof value === "undefined" && !allowMissing) {
          throw new $TypeError("intrinsic " + name + " exists, but is not available. Please file an issue!");
        }
        return {
          alias,
          name: intrinsicName,
          value
        };
      }
      throw new $SyntaxError("intrinsic " + name + " does not exist!");
    };
    module2.exports = function GetIntrinsic(name, allowMissing) {
      if (typeof name !== "string" || name.length === 0) {
        throw new $TypeError("intrinsic name must be a non-empty string");
      }
      if (arguments.length > 1 && typeof allowMissing !== "boolean") {
        throw new $TypeError('"allowMissing" argument must be a boolean');
      }
      if ($exec(/^%?[^%]*%?$/, name) === null) {
        throw new $SyntaxError("`%` may not be present anywhere but at the beginning and end of the intrinsic name");
      }
      var parts = stringToPath(name);
      var intrinsicBaseName = parts.length > 0 ? parts[0] : "";
      var intrinsic = getBaseIntrinsic("%" + intrinsicBaseName + "%", allowMissing);
      var intrinsicRealName = intrinsic.name;
      var value = intrinsic.value;
      var skipFurtherCaching = false;
      var alias = intrinsic.alias;
      if (alias) {
        intrinsicBaseName = alias[0];
        $spliceApply(parts, $concat([0, 1], alias));
      }
      for (var i = 1, isOwn = true; i < parts.length; i += 1) {
        var part = parts[i];
        var first = $strSlice(part, 0, 1);
        var last = $strSlice(part, -1);
        if ((first === '"' || first === "'" || first === "`" || (last === '"' || last === "'" || last === "`")) && first !== last) {
          throw new $SyntaxError("property names with quotes must have matching quotes");
        }
        if (part === "constructor" || !isOwn) {
          skipFurtherCaching = true;
        }
        intrinsicBaseName += "." + part;
        intrinsicRealName = "%" + intrinsicBaseName + "%";
        if (hasOwn(INTRINSICS, intrinsicRealName)) {
          value = INTRINSICS[intrinsicRealName];
        } else if (value != null) {
          if (!(part in value)) {
            if (!allowMissing) {
              throw new $TypeError("base intrinsic for " + name + " exists, but the property is not available.");
            }
            return void undefined2;
          }
          if ($gOPD && i + 1 >= parts.length) {
            var desc = $gOPD(value, part);
            isOwn = !!desc;
            if (isOwn && "get" in desc && !("originalValue" in desc.get)) {
              value = desc.get;
            } else {
              value = value[part];
            }
          } else {
            isOwn = hasOwn(value, part);
            value = value[part];
          }
          if (isOwn && !skipFurtherCaching) {
            INTRINSICS[intrinsicRealName] = value;
          }
        }
      }
      return value;
    };
  }
});

// node_modules/call-bound/index.js
var require_call_bound = __commonJS({
  "node_modules/call-bound/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var callBindBasic = require_call_bind_apply_helpers();
    var $indexOf = callBindBasic([GetIntrinsic("%String.prototype.indexOf%")]);
    module2.exports = function callBoundIntrinsic(name, allowMissing) {
      var intrinsic = (
        /** @type {(this: unknown, ...args: unknown[]) => unknown} */
        GetIntrinsic(name, !!allowMissing)
      );
      if (typeof intrinsic === "function" && $indexOf(name, ".prototype.") > -1) {
        return callBindBasic(
          /** @type {const} */
          [intrinsic]
        );
      }
      return intrinsic;
    };
  }
});

// node_modules/is-arguments/index.js
var require_is_arguments2 = __commonJS({
  "node_modules/is-arguments/index.js"(exports2, module2) {
    "use strict";
    var hasToStringTag = require_shams2()();
    var callBound = require_call_bound();
    var $toString = callBound("Object.prototype.toString");
    var isStandardArguments = function isArguments(value) {
      if (hasToStringTag && value && typeof value === "object" && Symbol.toStringTag in value) {
        return false;
      }
      return $toString(value) === "[object Arguments]";
    };
    var isLegacyArguments = function isArguments(value) {
      if (isStandardArguments(value)) {
        return true;
      }
      return value !== null && typeof value === "object" && "length" in value && typeof value.length === "number" && value.length >= 0 && $toString(value) !== "[object Array]" && "callee" in value && $toString(value.callee) === "[object Function]";
    };
    var supportsStandardArguments = (function() {
      return isStandardArguments(arguments);
    })();
    isStandardArguments.isLegacyArguments = isLegacyArguments;
    module2.exports = supportsStandardArguments ? isStandardArguments : isLegacyArguments;
  }
});

// node_modules/is-regex/index.js
var require_is_regex = __commonJS({
  "node_modules/is-regex/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_call_bound();
    var hasToStringTag = require_shams2()();
    var hasOwn = require_hasown();
    var gOPD = require_gopd();
    var fn;
    if (hasToStringTag) {
      $exec = callBound("RegExp.prototype.exec");
      isRegexMarker = {};
      throwRegexMarker = function() {
        throw isRegexMarker;
      };
      badStringifier = {
        toString: throwRegexMarker,
        valueOf: throwRegexMarker
      };
      if (typeof Symbol.toPrimitive === "symbol") {
        badStringifier[Symbol.toPrimitive] = throwRegexMarker;
      }
      fn = function isRegex(value) {
        if (!value || typeof value !== "object") {
          return false;
        }
        var descriptor = (
          /** @type {NonNullable<typeof gOPD>} */
          gOPD(
            /** @type {{ lastIndex?: unknown }} */
            value,
            "lastIndex"
          )
        );
        var hasLastIndexDataProperty = descriptor && hasOwn(descriptor, "value");
        if (!hasLastIndexDataProperty) {
          return false;
        }
        try {
          $exec(
            value,
            /** @type {string} */
            /** @type {unknown} */
            badStringifier
          );
        } catch (e) {
          return e === isRegexMarker;
        }
      };
    } else {
      $toString = callBound("Object.prototype.toString");
      regexClass = "[object RegExp]";
      fn = function isRegex(value) {
        if (!value || typeof value !== "object" && typeof value !== "function") {
          return false;
        }
        return $toString(value) === regexClass;
      };
    }
    var $exec;
    var isRegexMarker;
    var throwRegexMarker;
    var badStringifier;
    var $toString;
    var regexClass;
    module2.exports = fn;
  }
});

// node_modules/safe-regex-test/index.js
var require_safe_regex_test = __commonJS({
  "node_modules/safe-regex-test/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_call_bound();
    var isRegex = require_is_regex();
    var $exec = callBound("RegExp.prototype.exec");
    var $TypeError = require_type();
    module2.exports = function regexTester(regex) {
      if (!isRegex(regex)) {
        throw new $TypeError("`regex` must be a RegExp");
      }
      return function test(s) {
        return $exec(regex, s) !== null;
      };
    };
  }
});

// node_modules/generator-function/index.js
var require_generator_function = __commonJS({
  "node_modules/generator-function/index.js"(exports2, module2) {
    "use strict";
    var cached = (
      /** @type {GeneratorFunctionConstructor} */
      function* () {
      }.constructor
    );
    module2.exports = () => cached;
  }
});

// node_modules/is-generator-function/index.js
var require_is_generator_function = __commonJS({
  "node_modules/is-generator-function/index.js"(exports2, module2) {
    "use strict";
    var callBound = require_call_bound();
    var safeRegexTest = require_safe_regex_test();
    var isFnRegex = safeRegexTest(/^\s*(?:function)?\*/);
    var hasToStringTag = require_shams2()();
    var getProto = require_get_proto();
    var toStr = callBound("Object.prototype.toString");
    var fnToStr = callBound("Function.prototype.toString");
    var getGeneratorFunction = require_generator_function();
    module2.exports = function isGeneratorFunction(fn) {
      if (typeof fn !== "function") {
        return false;
      }
      if (isFnRegex(fnToStr(fn))) {
        return true;
      }
      if (!hasToStringTag) {
        var str = toStr(fn);
        return str === "[object GeneratorFunction]";
      }
      if (!getProto) {
        return false;
      }
      var GeneratorFunction = getGeneratorFunction();
      return GeneratorFunction && getProto(fn) === GeneratorFunction.prototype;
    };
  }
});

// node_modules/is-callable/index.js
var require_is_callable = __commonJS({
  "node_modules/is-callable/index.js"(exports2, module2) {
    "use strict";
    var fnToStr = Function.prototype.toString;
    var reflectApply = typeof Reflect === "object" && Reflect !== null && Reflect.apply;
    var badArrayLike;
    var isCallableMarker;
    if (typeof reflectApply === "function" && typeof Object.defineProperty === "function") {
      try {
        badArrayLike = Object.defineProperty({}, "length", {
          get: function() {
            throw isCallableMarker;
          }
        });
        isCallableMarker = {};
        reflectApply(function() {
          throw 42;
        }, null, badArrayLike);
      } catch (_) {
        if (_ !== isCallableMarker) {
          reflectApply = null;
        }
      }
    } else {
      reflectApply = null;
    }
    var constructorRegex = /^\s*class\b/;
    var isES6ClassFn = function isES6ClassFunction(value) {
      try {
        var fnStr = fnToStr.call(value);
        return constructorRegex.test(fnStr);
      } catch (e) {
        return false;
      }
    };
    var tryFunctionObject = function tryFunctionToStr(value) {
      try {
        if (isES6ClassFn(value)) {
          return false;
        }
        fnToStr.call(value);
        return true;
      } catch (e) {
        return false;
      }
    };
    var toStr = Object.prototype.toString;
    var objectClass = "[object Object]";
    var fnClass = "[object Function]";
    var genClass = "[object GeneratorFunction]";
    var ddaClass = "[object HTMLAllCollection]";
    var ddaClass2 = "[object HTML document.all class]";
    var ddaClass3 = "[object HTMLCollection]";
    var hasToStringTag = typeof Symbol === "function" && !!Symbol.toStringTag;
    var isIE68 = !(0 in [,]);
    var isDDA = function isDocumentDotAll() {
      return false;
    };
    if (typeof document === "object") {
      all = document.all;
      if (toStr.call(all) === toStr.call(document.all)) {
        isDDA = function isDocumentDotAll(value) {
          if ((isIE68 || !value) && (typeof value === "undefined" || typeof value === "object")) {
            try {
              var str = toStr.call(value);
              return (str === ddaClass || str === ddaClass2 || str === ddaClass3 || str === objectClass) && value("") == null;
            } catch (e) {
            }
          }
          return false;
        };
      }
    }
    var all;
    module2.exports = reflectApply ? function isCallable(value) {
      if (isDDA(value)) {
        return true;
      }
      if (!value) {
        return false;
      }
      if (typeof value !== "function" && typeof value !== "object") {
        return false;
      }
      try {
        reflectApply(value, null, badArrayLike);
      } catch (e) {
        if (e !== isCallableMarker) {
          return false;
        }
      }
      return !isES6ClassFn(value) && tryFunctionObject(value);
    } : function isCallable(value) {
      if (isDDA(value)) {
        return true;
      }
      if (!value) {
        return false;
      }
      if (typeof value !== "function" && typeof value !== "object") {
        return false;
      }
      if (hasToStringTag) {
        return tryFunctionObject(value);
      }
      if (isES6ClassFn(value)) {
        return false;
      }
      var strClass = toStr.call(value);
      if (strClass !== fnClass && strClass !== genClass && !/^\[object HTML/.test(strClass)) {
        return false;
      }
      return tryFunctionObject(value);
    };
  }
});

// node_modules/for-each/index.js
var require_for_each = __commonJS({
  "node_modules/for-each/index.js"(exports2, module2) {
    "use strict";
    var isCallable = require_is_callable();
    var toStr = Object.prototype.toString;
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    var forEachArray = function forEachArray2(array, iterator, receiver) {
      for (var i = 0, len = array.length; i < len; i++) {
        if (hasOwnProperty.call(array, i)) {
          if (receiver == null) {
            iterator(array[i], i, array);
          } else {
            iterator.call(receiver, array[i], i, array);
          }
        }
      }
    };
    var forEachString = function forEachString2(string, iterator, receiver) {
      for (var i = 0, len = string.length; i < len; i++) {
        if (receiver == null) {
          iterator(string.charAt(i), i, string);
        } else {
          iterator.call(receiver, string.charAt(i), i, string);
        }
      }
    };
    var forEachObject = function forEachObject2(object, iterator, receiver) {
      for (var k in object) {
        if (hasOwnProperty.call(object, k)) {
          if (receiver == null) {
            iterator(object[k], k, object);
          } else {
            iterator.call(receiver, object[k], k, object);
          }
        }
      }
    };
    function isArray(x) {
      return toStr.call(x) === "[object Array]";
    }
    module2.exports = function forEach(list, iterator, thisArg) {
      if (!isCallable(iterator)) {
        throw new TypeError("iterator must be a function");
      }
      var receiver;
      if (arguments.length >= 3) {
        receiver = thisArg;
      }
      if (isArray(list)) {
        forEachArray(list, iterator, receiver);
      } else if (typeof list === "string") {
        forEachString(list, iterator, receiver);
      } else {
        forEachObject(list, iterator, receiver);
      }
    };
  }
});

// node_modules/possible-typed-array-names/index.js
var require_possible_typed_array_names = __commonJS({
  "node_modules/possible-typed-array-names/index.js"(exports2, module2) {
    "use strict";
    module2.exports = [
      "Float16Array",
      "Float32Array",
      "Float64Array",
      "Int8Array",
      "Int16Array",
      "Int32Array",
      "Uint8Array",
      "Uint8ClampedArray",
      "Uint16Array",
      "Uint32Array",
      "BigInt64Array",
      "BigUint64Array"
    ];
  }
});

// node_modules/available-typed-arrays/index.js
var require_available_typed_arrays = __commonJS({
  "node_modules/available-typed-arrays/index.js"(exports2, module2) {
    "use strict";
    var possibleNames = require_possible_typed_array_names();
    var g = typeof globalThis === "undefined" ? global : globalThis;
    module2.exports = function availableTypedArrays() {
      var out = [];
      for (var i = 0; i < possibleNames.length; i++) {
        if (typeof g[possibleNames[i]] === "function") {
          out[out.length] = possibleNames[i];
        }
      }
      return out;
    };
  }
});

// node_modules/define-data-property/index.js
var require_define_data_property = __commonJS({
  "node_modules/define-data-property/index.js"(exports2, module2) {
    "use strict";
    var $defineProperty = require_es_define_property();
    var $SyntaxError = require_syntax();
    var $TypeError = require_type();
    var gopd = require_gopd();
    module2.exports = function defineDataProperty(obj, property, value) {
      if (!obj || typeof obj !== "object" && typeof obj !== "function") {
        throw new $TypeError("`obj` must be an object or a function`");
      }
      if (typeof property !== "string" && typeof property !== "symbol") {
        throw new $TypeError("`property` must be a string or a symbol`");
      }
      if (arguments.length > 3 && typeof arguments[3] !== "boolean" && arguments[3] !== null) {
        throw new $TypeError("`nonEnumerable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 4 && typeof arguments[4] !== "boolean" && arguments[4] !== null) {
        throw new $TypeError("`nonWritable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 5 && typeof arguments[5] !== "boolean" && arguments[5] !== null) {
        throw new $TypeError("`nonConfigurable`, if provided, must be a boolean or null");
      }
      if (arguments.length > 6 && typeof arguments[6] !== "boolean") {
        throw new $TypeError("`loose`, if provided, must be a boolean");
      }
      var nonEnumerable = arguments.length > 3 ? arguments[3] : null;
      var nonWritable = arguments.length > 4 ? arguments[4] : null;
      var nonConfigurable = arguments.length > 5 ? arguments[5] : null;
      var loose = arguments.length > 6 ? arguments[6] : false;
      var desc = !!gopd && gopd(obj, property);
      if ($defineProperty) {
        $defineProperty(obj, property, {
          configurable: nonConfigurable === null && desc ? desc.configurable : !nonConfigurable,
          enumerable: nonEnumerable === null && desc ? desc.enumerable : !nonEnumerable,
          value,
          writable: nonWritable === null && desc ? desc.writable : !nonWritable
        });
      } else if (loose || !nonEnumerable && !nonWritable && !nonConfigurable) {
        obj[property] = value;
      } else {
        throw new $SyntaxError("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.");
      }
    };
  }
});

// node_modules/has-property-descriptors/index.js
var require_has_property_descriptors = __commonJS({
  "node_modules/has-property-descriptors/index.js"(exports2, module2) {
    "use strict";
    var $defineProperty = require_es_define_property();
    var hasPropertyDescriptors = function hasPropertyDescriptors2() {
      return !!$defineProperty;
    };
    hasPropertyDescriptors.hasArrayLengthDefineBug = function hasArrayLengthDefineBug() {
      if (!$defineProperty) {
        return null;
      }
      try {
        return $defineProperty([], "length", { value: 1 }).length !== 1;
      } catch (e) {
        return true;
      }
    };
    module2.exports = hasPropertyDescriptors;
  }
});

// node_modules/set-function-length/index.js
var require_set_function_length = __commonJS({
  "node_modules/set-function-length/index.js"(exports2, module2) {
    "use strict";
    var GetIntrinsic = require_get_intrinsic();
    var define2 = require_define_data_property();
    var hasDescriptors = require_has_property_descriptors()();
    var gOPD = require_gopd();
    var $TypeError = require_type();
    var $floor = GetIntrinsic("%Math.floor%");
    module2.exports = function setFunctionLength(fn, length) {
      if (typeof fn !== "function") {
        throw new $TypeError("`fn` is not a function");
      }
      if (typeof length !== "number" || length < 0 || length > 4294967295 || $floor(length) !== length) {
        throw new $TypeError("`length` must be a positive 32-bit integer");
      }
      var loose = arguments.length > 2 && !!arguments[2];
      var functionLengthIsConfigurable = true;
      var functionLengthIsWritable = true;
      if ("length" in fn && gOPD) {
        var desc = gOPD(fn, "length");
        if (desc && !desc.configurable) {
          functionLengthIsConfigurable = false;
        }
        if (desc && !desc.writable) {
          functionLengthIsWritable = false;
        }
      }
      if (functionLengthIsConfigurable || functionLengthIsWritable || !loose) {
        if (hasDescriptors) {
          define2(
            /** @type {Parameters<define>[0]} */
            fn,
            "length",
            length,
            true,
            true
          );
        } else {
          define2(
            /** @type {Parameters<define>[0]} */
            fn,
            "length",
            length
          );
        }
      }
      return fn;
    };
  }
});

// node_modules/call-bind-apply-helpers/applyBind.js
var require_applyBind = __commonJS({
  "node_modules/call-bind-apply-helpers/applyBind.js"(exports2, module2) {
    "use strict";
    var bind = require_function_bind();
    var $apply = require_functionApply();
    var actualApply = require_actualApply();
    module2.exports = function applyBind() {
      return actualApply(bind, $apply, arguments);
    };
  }
});

// node_modules/call-bind/index.js
var require_call_bind = __commonJS({
  "node_modules/call-bind/index.js"(exports2, module2) {
    "use strict";
    var setFunctionLength = require_set_function_length();
    var $defineProperty = require_es_define_property();
    var callBindBasic = require_call_bind_apply_helpers();
    var applyBind = require_applyBind();
    module2.exports = function callBind(originalFunction) {
      var func = callBindBasic(arguments);
      var adjustedLength = 1 + originalFunction.length - (arguments.length - 1);
      return setFunctionLength(
        func,
        adjustedLength > 0 ? adjustedLength : 0,
        true
      );
    };
    if ($defineProperty) {
      $defineProperty(module2.exports, "apply", { value: applyBind });
    } else {
      module2.exports.apply = applyBind;
    }
  }
});

// node_modules/which-typed-array/index.js
var require_which_typed_array = __commonJS({
  "node_modules/which-typed-array/index.js"(exports2, module2) {
    "use strict";
    var forEach = require_for_each();
    var availableTypedArrays = require_available_typed_arrays();
    var callBind = require_call_bind();
    var callBound = require_call_bound();
    var gOPD = require_gopd();
    var getProto = require_get_proto();
    var $toString = callBound("Object.prototype.toString");
    var hasToStringTag = require_shams2()();
    var g = typeof globalThis === "undefined" ? global : globalThis;
    var typedArrays = availableTypedArrays();
    var $slice = callBound("String.prototype.slice");
    var $indexOf = callBound("Array.prototype.indexOf", true) || function indexOf(array, value) {
      for (var i = 0; i < array.length; i += 1) {
        if (array[i] === value) {
          return i;
        }
      }
      return -1;
    };
    var cache = { __proto__: null };
    if (hasToStringTag && gOPD && getProto) {
      forEach(typedArrays, function(typedArray) {
        var arr = new g[typedArray]();
        if (Symbol.toStringTag in arr && getProto) {
          var proto = getProto(arr);
          var descriptor = gOPD(proto, Symbol.toStringTag);
          if (!descriptor && proto) {
            var superProto = getProto(proto);
            descriptor = gOPD(superProto, Symbol.toStringTag);
          }
          if (descriptor && descriptor.get) {
            var bound = callBind(descriptor.get);
            cache[
              /** @type {`$${import('.').TypedArrayName}`} */
              "$" + typedArray
            ] = bound;
          }
        }
      });
    } else {
      forEach(typedArrays, function(typedArray) {
        var arr = new g[typedArray]();
        var fn = arr.slice || arr.set;
        if (fn) {
          var bound = (
            /** @type {import('./types').BoundSlice | import('./types').BoundSet} */
            // @ts-expect-error TODO FIXME
            callBind(fn)
          );
          cache[
            /** @type {`$${import('.').TypedArrayName}`} */
            "$" + typedArray
          ] = bound;
        }
      });
    }
    var tryTypedArrays = function tryAllTypedArrays(value) {
      var found = false;
      forEach(
        /** @type {Record<`\$${import('.').TypedArrayName}`, Getter>} */
        cache,
        /** @type {(getter: Getter, name: `\$${import('.').TypedArrayName}`) => void} */
        function(getter, typedArray) {
          if (!found) {
            try {
              if ("$" + getter(value) === typedArray) {
                found = /** @type {import('.').TypedArrayName} */
                $slice(typedArray, 1);
              }
            } catch (e) {
            }
          }
        }
      );
      return found;
    };
    var trySlices = function tryAllSlices(value) {
      var found = false;
      forEach(
        /** @type {Record<`\$${import('.').TypedArrayName}`, Getter>} */
        cache,
        /** @type {(getter: Getter, name: `\$${import('.').TypedArrayName}`) => void} */
        function(getter, name) {
          if (!found) {
            try {
              getter(value);
              found = /** @type {import('.').TypedArrayName} */
              $slice(name, 1);
            } catch (e) {
            }
          }
        }
      );
      return found;
    };
    module2.exports = function whichTypedArray(value) {
      if (!value || typeof value !== "object") {
        return false;
      }
      if (!hasToStringTag) {
        var tag = $slice($toString(value), 8, -1);
        if ($indexOf(typedArrays, tag) > -1) {
          return tag;
        }
        if (tag !== "Object") {
          return false;
        }
        return trySlices(value);
      }
      if (!gOPD) {
        return null;
      }
      return tryTypedArrays(value);
    };
  }
});

// node_modules/is-typed-array/index.js
var require_is_typed_array = __commonJS({
  "node_modules/is-typed-array/index.js"(exports2, module2) {
    "use strict";
    var whichTypedArray = require_which_typed_array();
    module2.exports = function isTypedArray(value) {
      return !!whichTypedArray(value);
    };
  }
});

// node_modules/util/support/types.js
var require_types = __commonJS({
  "node_modules/util/support/types.js"(exports2) {
    "use strict";
    var isArgumentsObject = require_is_arguments2();
    var isGeneratorFunction = require_is_generator_function();
    var whichTypedArray = require_which_typed_array();
    var isTypedArray = require_is_typed_array();
    function uncurryThis(f) {
      return f.call.bind(f);
    }
    var BigIntSupported = typeof BigInt !== "undefined";
    var SymbolSupported = typeof Symbol !== "undefined";
    var ObjectToString = uncurryThis(Object.prototype.toString);
    var numberValue = uncurryThis(Number.prototype.valueOf);
    var stringValue = uncurryThis(String.prototype.valueOf);
    var booleanValue = uncurryThis(Boolean.prototype.valueOf);
    if (BigIntSupported) {
      bigIntValue = uncurryThis(BigInt.prototype.valueOf);
    }
    var bigIntValue;
    if (SymbolSupported) {
      symbolValue = uncurryThis(Symbol.prototype.valueOf);
    }
    var symbolValue;
    function checkBoxedPrimitive(value, prototypeValueOf) {
      if (typeof value !== "object") {
        return false;
      }
      try {
        prototypeValueOf(value);
        return true;
      } catch (e) {
        return false;
      }
    }
    exports2.isArgumentsObject = isArgumentsObject;
    exports2.isGeneratorFunction = isGeneratorFunction;
    exports2.isTypedArray = isTypedArray;
    function isPromise(input) {
      return typeof Promise !== "undefined" && input instanceof Promise || input !== null && typeof input === "object" && typeof input.then === "function" && typeof input.catch === "function";
    }
    exports2.isPromise = isPromise;
    function isArrayBufferView(value) {
      if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
        return ArrayBuffer.isView(value);
      }
      return isTypedArray(value) || isDataView(value);
    }
    exports2.isArrayBufferView = isArrayBufferView;
    function isUint8Array(value) {
      return whichTypedArray(value) === "Uint8Array";
    }
    exports2.isUint8Array = isUint8Array;
    function isUint8ClampedArray(value) {
      return whichTypedArray(value) === "Uint8ClampedArray";
    }
    exports2.isUint8ClampedArray = isUint8ClampedArray;
    function isUint16Array(value) {
      return whichTypedArray(value) === "Uint16Array";
    }
    exports2.isUint16Array = isUint16Array;
    function isUint32Array(value) {
      return whichTypedArray(value) === "Uint32Array";
    }
    exports2.isUint32Array = isUint32Array;
    function isInt8Array(value) {
      return whichTypedArray(value) === "Int8Array";
    }
    exports2.isInt8Array = isInt8Array;
    function isInt16Array(value) {
      return whichTypedArray(value) === "Int16Array";
    }
    exports2.isInt16Array = isInt16Array;
    function isInt32Array(value) {
      return whichTypedArray(value) === "Int32Array";
    }
    exports2.isInt32Array = isInt32Array;
    function isFloat32Array(value) {
      return whichTypedArray(value) === "Float32Array";
    }
    exports2.isFloat32Array = isFloat32Array;
    function isFloat64Array(value) {
      return whichTypedArray(value) === "Float64Array";
    }
    exports2.isFloat64Array = isFloat64Array;
    function isBigInt64Array(value) {
      return whichTypedArray(value) === "BigInt64Array";
    }
    exports2.isBigInt64Array = isBigInt64Array;
    function isBigUint64Array(value) {
      return whichTypedArray(value) === "BigUint64Array";
    }
    exports2.isBigUint64Array = isBigUint64Array;
    function isMapToString(value) {
      return ObjectToString(value) === "[object Map]";
    }
    isMapToString.working = typeof Map !== "undefined" && isMapToString(/* @__PURE__ */ new Map());
    function isMap(value) {
      if (typeof Map === "undefined") {
        return false;
      }
      return isMapToString.working ? isMapToString(value) : value instanceof Map;
    }
    exports2.isMap = isMap;
    function isSetToString(value) {
      return ObjectToString(value) === "[object Set]";
    }
    isSetToString.working = typeof Set !== "undefined" && isSetToString(/* @__PURE__ */ new Set());
    function isSet(value) {
      if (typeof Set === "undefined") {
        return false;
      }
      return isSetToString.working ? isSetToString(value) : value instanceof Set;
    }
    exports2.isSet = isSet;
    function isWeakMapToString(value) {
      return ObjectToString(value) === "[object WeakMap]";
    }
    isWeakMapToString.working = typeof WeakMap !== "undefined" && isWeakMapToString(/* @__PURE__ */ new WeakMap());
    function isWeakMap(value) {
      if (typeof WeakMap === "undefined") {
        return false;
      }
      return isWeakMapToString.working ? isWeakMapToString(value) : value instanceof WeakMap;
    }
    exports2.isWeakMap = isWeakMap;
    function isWeakSetToString(value) {
      return ObjectToString(value) === "[object WeakSet]";
    }
    isWeakSetToString.working = typeof WeakSet !== "undefined" && isWeakSetToString(/* @__PURE__ */ new WeakSet());
    function isWeakSet(value) {
      return isWeakSetToString(value);
    }
    exports2.isWeakSet = isWeakSet;
    function isArrayBufferToString(value) {
      return ObjectToString(value) === "[object ArrayBuffer]";
    }
    isArrayBufferToString.working = typeof ArrayBuffer !== "undefined" && isArrayBufferToString(new ArrayBuffer());
    function isArrayBuffer(value) {
      if (typeof ArrayBuffer === "undefined") {
        return false;
      }
      return isArrayBufferToString.working ? isArrayBufferToString(value) : value instanceof ArrayBuffer;
    }
    exports2.isArrayBuffer = isArrayBuffer;
    function isDataViewToString(value) {
      return ObjectToString(value) === "[object DataView]";
    }
    isDataViewToString.working = typeof ArrayBuffer !== "undefined" && typeof DataView !== "undefined" && isDataViewToString(new DataView(new ArrayBuffer(1), 0, 1));
    function isDataView(value) {
      if (typeof DataView === "undefined") {
        return false;
      }
      return isDataViewToString.working ? isDataViewToString(value) : value instanceof DataView;
    }
    exports2.isDataView = isDataView;
    var SharedArrayBufferCopy = typeof SharedArrayBuffer !== "undefined" ? SharedArrayBuffer : void 0;
    function isSharedArrayBufferToString(value) {
      return ObjectToString(value) === "[object SharedArrayBuffer]";
    }
    function isSharedArrayBuffer(value) {
      if (typeof SharedArrayBufferCopy === "undefined") {
        return false;
      }
      if (typeof isSharedArrayBufferToString.working === "undefined") {
        isSharedArrayBufferToString.working = isSharedArrayBufferToString(new SharedArrayBufferCopy());
      }
      return isSharedArrayBufferToString.working ? isSharedArrayBufferToString(value) : value instanceof SharedArrayBufferCopy;
    }
    exports2.isSharedArrayBuffer = isSharedArrayBuffer;
    function isAsyncFunction(value) {
      return ObjectToString(value) === "[object AsyncFunction]";
    }
    exports2.isAsyncFunction = isAsyncFunction;
    function isMapIterator(value) {
      return ObjectToString(value) === "[object Map Iterator]";
    }
    exports2.isMapIterator = isMapIterator;
    function isSetIterator(value) {
      return ObjectToString(value) === "[object Set Iterator]";
    }
    exports2.isSetIterator = isSetIterator;
    function isGeneratorObject(value) {
      return ObjectToString(value) === "[object Generator]";
    }
    exports2.isGeneratorObject = isGeneratorObject;
    function isWebAssemblyCompiledModule(value) {
      return ObjectToString(value) === "[object WebAssembly.Module]";
    }
    exports2.isWebAssemblyCompiledModule = isWebAssemblyCompiledModule;
    function isNumberObject(value) {
      return checkBoxedPrimitive(value, numberValue);
    }
    exports2.isNumberObject = isNumberObject;
    function isStringObject(value) {
      return checkBoxedPrimitive(value, stringValue);
    }
    exports2.isStringObject = isStringObject;
    function isBooleanObject(value) {
      return checkBoxedPrimitive(value, booleanValue);
    }
    exports2.isBooleanObject = isBooleanObject;
    function isBigIntObject(value) {
      return BigIntSupported && checkBoxedPrimitive(value, bigIntValue);
    }
    exports2.isBigIntObject = isBigIntObject;
    function isSymbolObject(value) {
      return SymbolSupported && checkBoxedPrimitive(value, symbolValue);
    }
    exports2.isSymbolObject = isSymbolObject;
    function isBoxedPrimitive(value) {
      return isNumberObject(value) || isStringObject(value) || isBooleanObject(value) || isBigIntObject(value) || isSymbolObject(value);
    }
    exports2.isBoxedPrimitive = isBoxedPrimitive;
    function isAnyArrayBuffer(value) {
      return typeof Uint8Array !== "undefined" && (isArrayBuffer(value) || isSharedArrayBuffer(value));
    }
    exports2.isAnyArrayBuffer = isAnyArrayBuffer;
    ["isProxy", "isExternal", "isModuleNamespaceObject"].forEach(function(method) {
      Object.defineProperty(exports2, method, {
        enumerable: false,
        value: function() {
          throw new Error(method + " is not supported in userland");
        }
      });
    });
  }
});

// node_modules/util/support/isBufferBrowser.js
var require_isBufferBrowser = __commonJS({
  "node_modules/util/support/isBufferBrowser.js"(exports2, module2) {
    module2.exports = function isBuffer(arg) {
      return arg && typeof arg === "object" && typeof arg.copy === "function" && typeof arg.fill === "function" && typeof arg.readUInt8 === "function";
    };
  }
});

// node_modules/inherits/inherits_browser.js
var require_inherits_browser = __commonJS({
  "node_modules/inherits/inherits_browser.js"(exports2, module2) {
    if (typeof Object.create === "function") {
      module2.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
          ctor.super_ = superCtor;
          ctor.prototype = Object.create(superCtor.prototype, {
            constructor: {
              value: ctor,
              enumerable: false,
              writable: true,
              configurable: true
            }
          });
        }
      };
    } else {
      module2.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
          ctor.super_ = superCtor;
          var TempCtor = function() {
          };
          TempCtor.prototype = superCtor.prototype;
          ctor.prototype = new TempCtor();
          ctor.prototype.constructor = ctor;
        }
      };
    }
  }
});

// node_modules/util/util.js
var require_util = __commonJS({
  "node_modules/util/util.js"(exports2) {
    var getOwnPropertyDescriptors = Object.getOwnPropertyDescriptors || function getOwnPropertyDescriptors2(obj) {
      var keys = Object.keys(obj);
      var descriptors = {};
      for (var i = 0; i < keys.length; i++) {
        descriptors[keys[i]] = Object.getOwnPropertyDescriptor(obj, keys[i]);
      }
      return descriptors;
    };
    var formatRegExp = /%[sdj%]/g;
    exports2.format = function(f) {
      if (!isString(f)) {
        var objects = [];
        for (var i = 0; i < arguments.length; i++) {
          objects.push(inspect(arguments[i]));
        }
        return objects.join(" ");
      }
      var i = 1;
      var args = arguments;
      var len = args.length;
      var str = String(f).replace(formatRegExp, function(x2) {
        if (x2 === "%%") return "%";
        if (i >= len) return x2;
        switch (x2) {
          case "%s":
            return String(args[i++]);
          case "%d":
            return Number(args[i++]);
          case "%j":
            try {
              return JSON.stringify(args[i++]);
            } catch (_) {
              return "[Circular]";
            }
          default:
            return x2;
        }
      });
      for (var x = args[i]; i < len; x = args[++i]) {
        if (isNull(x) || !isObject(x)) {
          str += " " + x;
        } else {
          str += " " + inspect(x);
        }
      }
      return str;
    };
    exports2.deprecate = function(fn, msg) {
      if (typeof process !== "undefined" && process.noDeprecation === true) {
        return fn;
      }
      if (typeof process === "undefined") {
        return function() {
          return exports2.deprecate(fn, msg).apply(this, arguments);
        };
      }
      var warned = false;
      function deprecated() {
        if (!warned) {
          if (process.throwDeprecation) {
            throw new Error(msg);
          } else if (process.traceDeprecation) {
            console.trace(msg);
          } else {
            console.error(msg);
          }
          warned = true;
        }
        return fn.apply(this, arguments);
      }
      return deprecated;
    };
    var debugs = {};
    var debugEnvRegex = /^$/;
    if ("") {
      debugEnv = "";
      debugEnv = debugEnv.replace(/[|\\{}()[\]^$+?.]/g, "\\$&").replace(/\*/g, ".*").replace(/,/g, "$|^").toUpperCase();
      debugEnvRegex = new RegExp("^" + debugEnv + "$", "i");
    }
    var debugEnv;
    exports2.debuglog = function(set) {
      set = set.toUpperCase();
      if (!debugs[set]) {
        if (debugEnvRegex.test(set)) {
          var pid = process.pid;
          debugs[set] = function() {
            var msg = exports2.format.apply(exports2, arguments);
            console.error("%s %d: %s", set, pid, msg);
          };
        } else {
          debugs[set] = function() {
          };
        }
      }
      return debugs[set];
    };
    function inspect(obj, opts) {
      var ctx = {
        seen: [],
        stylize: stylizeNoColor
      };
      if (arguments.length >= 3) ctx.depth = arguments[2];
      if (arguments.length >= 4) ctx.colors = arguments[3];
      if (isBoolean(opts)) {
        ctx.showHidden = opts;
      } else if (opts) {
        exports2._extend(ctx, opts);
      }
      if (isUndefined(ctx.showHidden)) ctx.showHidden = false;
      if (isUndefined(ctx.depth)) ctx.depth = 2;
      if (isUndefined(ctx.colors)) ctx.colors = false;
      if (isUndefined(ctx.customInspect)) ctx.customInspect = true;
      if (ctx.colors) ctx.stylize = stylizeWithColor;
      return formatValue(ctx, obj, ctx.depth);
    }
    exports2.inspect = inspect;
    inspect.colors = {
      "bold": [1, 22],
      "italic": [3, 23],
      "underline": [4, 24],
      "inverse": [7, 27],
      "white": [37, 39],
      "grey": [90, 39],
      "black": [30, 39],
      "blue": [34, 39],
      "cyan": [36, 39],
      "green": [32, 39],
      "magenta": [35, 39],
      "red": [31, 39],
      "yellow": [33, 39]
    };
    inspect.styles = {
      "special": "cyan",
      "number": "yellow",
      "boolean": "yellow",
      "undefined": "grey",
      "null": "bold",
      "string": "green",
      "date": "magenta",
      // "name": intentionally not styling
      "regexp": "red"
    };
    function stylizeWithColor(str, styleType) {
      var style = inspect.styles[styleType];
      if (style) {
        return "\x1B[" + inspect.colors[style][0] + "m" + str + "\x1B[" + inspect.colors[style][1] + "m";
      } else {
        return str;
      }
    }
    function stylizeNoColor(str, styleType) {
      return str;
    }
    function arrayToHash(array) {
      var hash = {};
      array.forEach(function(val, idx) {
        hash[val] = true;
      });
      return hash;
    }
    function formatValue(ctx, value, recurseTimes) {
      if (ctx.customInspect && value && isFunction(value.inspect) && // Filter out the util module, it's inspect function is special
      value.inspect !== exports2.inspect && // Also filter out any prototype objects using the circular check.
      !(value.constructor && value.constructor.prototype === value)) {
        var ret = value.inspect(recurseTimes, ctx);
        if (!isString(ret)) {
          ret = formatValue(ctx, ret, recurseTimes);
        }
        return ret;
      }
      var primitive = formatPrimitive(ctx, value);
      if (primitive) {
        return primitive;
      }
      var keys = Object.keys(value);
      var visibleKeys = arrayToHash(keys);
      if (ctx.showHidden) {
        keys = Object.getOwnPropertyNames(value);
      }
      if (isError(value) && (keys.indexOf("message") >= 0 || keys.indexOf("description") >= 0)) {
        return formatError(value);
      }
      if (keys.length === 0) {
        if (isFunction(value)) {
          var name = value.name ? ": " + value.name : "";
          return ctx.stylize("[Function" + name + "]", "special");
        }
        if (isRegExp(value)) {
          return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
        }
        if (isDate(value)) {
          return ctx.stylize(Date.prototype.toString.call(value), "date");
        }
        if (isError(value)) {
          return formatError(value);
        }
      }
      var base = "", array = false, braces = ["{", "}"];
      if (isArray(value)) {
        array = true;
        braces = ["[", "]"];
      }
      if (isFunction(value)) {
        var n = value.name ? ": " + value.name : "";
        base = " [Function" + n + "]";
      }
      if (isRegExp(value)) {
        base = " " + RegExp.prototype.toString.call(value);
      }
      if (isDate(value)) {
        base = " " + Date.prototype.toUTCString.call(value);
      }
      if (isError(value)) {
        base = " " + formatError(value);
      }
      if (keys.length === 0 && (!array || value.length == 0)) {
        return braces[0] + base + braces[1];
      }
      if (recurseTimes < 0) {
        if (isRegExp(value)) {
          return ctx.stylize(RegExp.prototype.toString.call(value), "regexp");
        } else {
          return ctx.stylize("[Object]", "special");
        }
      }
      ctx.seen.push(value);
      var output;
      if (array) {
        output = formatArray(ctx, value, recurseTimes, visibleKeys, keys);
      } else {
        output = keys.map(function(key) {
          return formatProperty(ctx, value, recurseTimes, visibleKeys, key, array);
        });
      }
      ctx.seen.pop();
      return reduceToSingleString(output, base, braces);
    }
    function formatPrimitive(ctx, value) {
      if (isUndefined(value))
        return ctx.stylize("undefined", "undefined");
      if (isString(value)) {
        var simple = "'" + JSON.stringify(value).replace(/^"|"$/g, "").replace(/'/g, "\\'").replace(/\\"/g, '"') + "'";
        return ctx.stylize(simple, "string");
      }
      if (isNumber(value))
        return ctx.stylize("" + value, "number");
      if (isBoolean(value))
        return ctx.stylize("" + value, "boolean");
      if (isNull(value))
        return ctx.stylize("null", "null");
    }
    function formatError(value) {
      return "[" + Error.prototype.toString.call(value) + "]";
    }
    function formatArray(ctx, value, recurseTimes, visibleKeys, keys) {
      var output = [];
      for (var i = 0, l = value.length; i < l; ++i) {
        if (hasOwnProperty(value, String(i))) {
          output.push(formatProperty(
            ctx,
            value,
            recurseTimes,
            visibleKeys,
            String(i),
            true
          ));
        } else {
          output.push("");
        }
      }
      keys.forEach(function(key) {
        if (!key.match(/^\d+$/)) {
          output.push(formatProperty(
            ctx,
            value,
            recurseTimes,
            visibleKeys,
            key,
            true
          ));
        }
      });
      return output;
    }
    function formatProperty(ctx, value, recurseTimes, visibleKeys, key, array) {
      var name, str, desc;
      desc = Object.getOwnPropertyDescriptor(value, key) || { value: value[key] };
      if (desc.get) {
        if (desc.set) {
          str = ctx.stylize("[Getter/Setter]", "special");
        } else {
          str = ctx.stylize("[Getter]", "special");
        }
      } else {
        if (desc.set) {
          str = ctx.stylize("[Setter]", "special");
        }
      }
      if (!hasOwnProperty(visibleKeys, key)) {
        name = "[" + key + "]";
      }
      if (!str) {
        if (ctx.seen.indexOf(desc.value) < 0) {
          if (isNull(recurseTimes)) {
            str = formatValue(ctx, desc.value, null);
          } else {
            str = formatValue(ctx, desc.value, recurseTimes - 1);
          }
          if (str.indexOf("\n") > -1) {
            if (array) {
              str = str.split("\n").map(function(line) {
                return "  " + line;
              }).join("\n").slice(2);
            } else {
              str = "\n" + str.split("\n").map(function(line) {
                return "   " + line;
              }).join("\n");
            }
          }
        } else {
          str = ctx.stylize("[Circular]", "special");
        }
      }
      if (isUndefined(name)) {
        if (array && key.match(/^\d+$/)) {
          return str;
        }
        name = JSON.stringify("" + key);
        if (name.match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)) {
          name = name.slice(1, -1);
          name = ctx.stylize(name, "name");
        } else {
          name = name.replace(/'/g, "\\'").replace(/\\"/g, '"').replace(/(^"|"$)/g, "'");
          name = ctx.stylize(name, "string");
        }
      }
      return name + ": " + str;
    }
    function reduceToSingleString(output, base, braces) {
      var numLinesEst = 0;
      var length = output.reduce(function(prev, cur) {
        numLinesEst++;
        if (cur.indexOf("\n") >= 0) numLinesEst++;
        return prev + cur.replace(/\u001b\[\d\d?m/g, "").length + 1;
      }, 0);
      if (length > 60) {
        return braces[0] + (base === "" ? "" : base + "\n ") + " " + output.join(",\n  ") + " " + braces[1];
      }
      return braces[0] + base + " " + output.join(", ") + " " + braces[1];
    }
    exports2.types = require_types();
    function isArray(ar) {
      return Array.isArray(ar);
    }
    exports2.isArray = isArray;
    function isBoolean(arg) {
      return typeof arg === "boolean";
    }
    exports2.isBoolean = isBoolean;
    function isNull(arg) {
      return arg === null;
    }
    exports2.isNull = isNull;
    function isNullOrUndefined(arg) {
      return arg == null;
    }
    exports2.isNullOrUndefined = isNullOrUndefined;
    function isNumber(arg) {
      return typeof arg === "number";
    }
    exports2.isNumber = isNumber;
    function isString(arg) {
      return typeof arg === "string";
    }
    exports2.isString = isString;
    function isSymbol(arg) {
      return typeof arg === "symbol";
    }
    exports2.isSymbol = isSymbol;
    function isUndefined(arg) {
      return arg === void 0;
    }
    exports2.isUndefined = isUndefined;
    function isRegExp(re) {
      return isObject(re) && objectToString(re) === "[object RegExp]";
    }
    exports2.isRegExp = isRegExp;
    exports2.types.isRegExp = isRegExp;
    function isObject(arg) {
      return typeof arg === "object" && arg !== null;
    }
    exports2.isObject = isObject;
    function isDate(d) {
      return isObject(d) && objectToString(d) === "[object Date]";
    }
    exports2.isDate = isDate;
    exports2.types.isDate = isDate;
    function isError(e) {
      return isObject(e) && (objectToString(e) === "[object Error]" || e instanceof Error);
    }
    exports2.isError = isError;
    exports2.types.isNativeError = isError;
    function isFunction(arg) {
      return typeof arg === "function";
    }
    exports2.isFunction = isFunction;
    function isPrimitive(arg) {
      return arg === null || typeof arg === "boolean" || typeof arg === "number" || typeof arg === "string" || typeof arg === "symbol" || // ES6 symbol
      typeof arg === "undefined";
    }
    exports2.isPrimitive = isPrimitive;
    exports2.isBuffer = require_isBufferBrowser();
    function objectToString(o) {
      return Object.prototype.toString.call(o);
    }
    function pad(n) {
      return n < 10 ? "0" + n.toString(10) : n.toString(10);
    }
    var months = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec"
    ];
    function timestamp() {
      var d = /* @__PURE__ */ new Date();
      var time = [
        pad(d.getHours()),
        pad(d.getMinutes()),
        pad(d.getSeconds())
      ].join(":");
      return [d.getDate(), months[d.getMonth()], time].join(" ");
    }
    exports2.log = function() {
      console.log("%s - %s", timestamp(), exports2.format.apply(exports2, arguments));
    };
    exports2.inherits = require_inherits_browser();
    exports2._extend = function(origin, add) {
      if (!add || !isObject(add)) return origin;
      var keys = Object.keys(add);
      var i = keys.length;
      while (i--) {
        origin[keys[i]] = add[keys[i]];
      }
      return origin;
    };
    function hasOwnProperty(obj, prop) {
      return Object.prototype.hasOwnProperty.call(obj, prop);
    }
    var kCustomPromisifiedSymbol = typeof Symbol !== "undefined" ? /* @__PURE__ */ Symbol("util.promisify.custom") : void 0;
    exports2.promisify = function promisify(original) {
      if (typeof original !== "function")
        throw new TypeError('The "original" argument must be of type Function');
      if (kCustomPromisifiedSymbol && original[kCustomPromisifiedSymbol]) {
        var fn = original[kCustomPromisifiedSymbol];
        if (typeof fn !== "function") {
          throw new TypeError('The "util.promisify.custom" argument must be of type Function');
        }
        Object.defineProperty(fn, kCustomPromisifiedSymbol, {
          value: fn,
          enumerable: false,
          writable: false,
          configurable: true
        });
        return fn;
      }
      function fn() {
        var promiseResolve, promiseReject;
        var promise = new Promise(function(resolve, reject) {
          promiseResolve = resolve;
          promiseReject = reject;
        });
        var args = [];
        for (var i = 0; i < arguments.length; i++) {
          args.push(arguments[i]);
        }
        args.push(function(err, value) {
          if (err) {
            promiseReject(err);
          } else {
            promiseResolve(value);
          }
        });
        try {
          original.apply(this, args);
        } catch (err) {
          promiseReject(err);
        }
        return promise;
      }
      Object.setPrototypeOf(fn, Object.getPrototypeOf(original));
      if (kCustomPromisifiedSymbol) Object.defineProperty(fn, kCustomPromisifiedSymbol, {
        value: fn,
        enumerable: false,
        writable: false,
        configurable: true
      });
      return Object.defineProperties(
        fn,
        getOwnPropertyDescriptors(original)
      );
    };
    exports2.promisify.custom = kCustomPromisifiedSymbol;
    function callbackifyOnRejected(reason, cb) {
      if (!reason) {
        var newReason = new Error("Promise was rejected with a falsy value");
        newReason.reason = reason;
        reason = newReason;
      }
      return cb(reason);
    }
    function callbackify(original) {
      if (typeof original !== "function") {
        throw new TypeError('The "original" argument must be of type Function');
      }
      function callbackified() {
        var args = [];
        for (var i = 0; i < arguments.length; i++) {
          args.push(arguments[i]);
        }
        var maybeCb = args.pop();
        if (typeof maybeCb !== "function") {
          throw new TypeError("The last argument must be of type Function");
        }
        var self2 = this;
        var cb = function() {
          return maybeCb.apply(self2, arguments);
        };
        original.apply(this, args).then(
          function(ret) {
            process.nextTick(cb.bind(null, null, ret));
          },
          function(rej) {
            process.nextTick(callbackifyOnRejected.bind(null, rej, cb));
          }
        );
      }
      Object.setPrototypeOf(callbackified, Object.getPrototypeOf(original));
      Object.defineProperties(
        callbackified,
        getOwnPropertyDescriptors(original)
      );
      return callbackified;
    }
    exports2.callbackify = callbackify;
  }
});

// lib/sinon/assert.js
var require_assert = __commonJS({
  "lib/sinon/assert.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var samsam = require_samsam();
    var timesInWords = require_times_in_words();
    var util = require_util();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var {
      prototypes,
      calledInOrder,
      orderByFirstCall,
      global: globalObject
    } = commons__default.default;
    var { createMatcher } = samsam__default.default;
    var { slice: arraySlice, concat, forEach, join, splice } = prototypes.array;
    var { slice: stringSlice } = prototypes.string;
    function applyDefaults(obj, defaults) {
      for (const key of Object.keys(defaults)) {
        const val = obj[key];
        if (val === null || typeof val === "undefined") {
          obj[key] = defaults[key];
        }
      }
    }
    function createAssertObject(opts) {
      const cleanedAssertOptions = opts || {};
      applyDefaults(cleanedAssertOptions, {
        shouldLimitAssertionLogs: false,
        assertionLogLimit: 1e4
      });
      const assert2 = {
        fail: function fail(message) {
          let msg = message;
          if (cleanedAssertOptions.shouldLimitAssertionLogs) {
            msg = message.substring(
              0,
              cleanedAssertOptions.assertionLogLimit
            );
          }
          const error = new Error(msg);
          error.name = "AssertError";
          throw error;
        },
        pass: function pass() {
          return;
        },
        callOrder: function assertCallOrder() {
          verifyIsStub.apply(null, arguments);
          let expected = "";
          let actual = "";
          if (!calledInOrder(arguments)) {
            try {
              expected = join(arguments, ", ");
              const calls = arraySlice(arguments);
              let i = calls.length;
              while (i) {
                if (!calls[--i].called) {
                  splice(calls, i, 1);
                }
              }
              actual = join(orderByFirstCall(calls), ", ");
            } catch (e) {
            }
            failAssertion(
              this,
              `expected ${expected} to be called in order but were called as ${actual}`
            );
          } else {
            assert2.pass("callOrder");
          }
        },
        callCount: function assertCallCount(method, count) {
          verifyIsStub(method);
          let msg;
          if (typeof count !== "number") {
            msg = `expected ${util.inspect(count)} to be a number but was of type ${typeof count}`;
            failAssertion(this, msg);
          } else if (method.callCount !== count) {
            msg = `expected %n to be called ${timesInWords(count)} but was called %c%C`;
            failAssertion(this, method.printf(msg));
          } else {
            assert2.pass("callCount");
          }
        },
        expose: function expose(target, options) {
          if (!target) {
            throw new TypeError("target is null or undefined");
          }
          const o = options || {};
          const prefix = typeof o.prefix === "undefined" && "assert" || o.prefix;
          const includeFail = typeof o.includeFail === "undefined" || Boolean(o.includeFail);
          const instance = this;
          forEach(Object.keys(instance), function(method) {
            if (method !== "expose" && (includeFail || !/^(fail)/.test(method))) {
              target[exposedName(prefix, method)] = instance[method];
            }
          });
          return target;
        },
        match: function match(actual, expectation) {
          const matcher = createMatcher(expectation);
          if (matcher.test(actual)) {
            assert2.pass("match");
          } else {
            const formatted = [
              "expected value to match",
              `    expected = ${util.inspect(expectation)}`,
              `    actual = ${util.inspect(actual)}`
            ];
            failAssertion(this, join(formatted, "\n"));
          }
        }
      };
      function verifyIsStub() {
        const args = arraySlice(arguments);
        forEach(args, function(method) {
          if (!method) {
            assert2.fail("fake is not a spy");
          }
          if (method.proxy && method.proxy.isSinonProxy) {
            verifyIsStub(method.proxy);
          } else {
            if (typeof method !== "function") {
              assert2.fail(`${method} is not a function`);
            }
            if (typeof method.getCall !== "function") {
              assert2.fail(`${method} is not stubbed`);
            }
          }
        });
      }
      function verifyIsValidAssertion(assertionMethod, assertionArgs) {
        switch (assertionMethod) {
          case "notCalled":
          case "called":
          case "calledOnce":
          case "calledTwice":
          case "calledThrice":
            if (assertionArgs.length !== 0) {
              assert2.fail(
                `${assertionMethod} takes 1 argument but was called with ${assertionArgs.length + 1} arguments`
              );
            }
            break;
        }
      }
      function failAssertion(object, msg) {
        const obj = object || globalObject;
        const failMethod = obj.fail || assert2.fail;
        failMethod.call(obj, msg);
      }
      function mirrorPropAsAssertion(name, method, message) {
        let msg = message;
        let meth = method;
        if (arguments.length === 2) {
          msg = method;
          meth = name;
        }
        assert2[name] = function(fake) {
          verifyIsStub(fake);
          const args = arraySlice(arguments, 1);
          let failed = false;
          verifyIsValidAssertion(name, args);
          if (typeof meth === "function") {
            failed = !meth(fake);
          } else {
            failed = typeof fake[meth] === "function" ? !fake[meth].apply(fake, args) : !fake[meth];
          }
          if (failed) {
            failAssertion(
              this,
              (fake.printf || fake.proxy.printf).apply(
                fake,
                concat([msg], args)
              )
            );
          } else {
            assert2.pass(name);
          }
        };
      }
      function exposedName(prefix, prop) {
        return !prefix || /^fail/.test(prop) ? prop : prefix + stringSlice(prop, 0, 1).toUpperCase() + stringSlice(prop, 1);
      }
      mirrorPropAsAssertion(
        "called",
        "expected %n to have been called at least once but was never called"
      );
      mirrorPropAsAssertion(
        "notCalled",
        function(spy) {
          return !spy.called;
        },
        "expected %n to not have been called but was called %c%C"
      );
      mirrorPropAsAssertion(
        "calledOnce",
        "expected %n to be called once but was called %c%C"
      );
      mirrorPropAsAssertion(
        "calledTwice",
        "expected %n to be called twice but was called %c%C"
      );
      mirrorPropAsAssertion(
        "calledThrice",
        "expected %n to be called thrice but was called %c%C"
      );
      mirrorPropAsAssertion(
        "calledOn",
        "expected %n to be called with %1 as this but was called with %t"
      );
      mirrorPropAsAssertion(
        "alwaysCalledOn",
        "expected %n to always be called with %1 as this but was called with %t"
      );
      mirrorPropAsAssertion("calledWithNew", "expected %n to be called with new");
      mirrorPropAsAssertion(
        "alwaysCalledWithNew",
        "expected %n to always be called with new"
      );
      mirrorPropAsAssertion(
        "calledWith",
        "expected %n to be called with arguments %D"
      );
      mirrorPropAsAssertion(
        "calledWithMatch",
        "expected %n to be called with match %D"
      );
      mirrorPropAsAssertion(
        "alwaysCalledWith",
        "expected %n to always be called with arguments %D"
      );
      mirrorPropAsAssertion(
        "alwaysCalledWithMatch",
        "expected %n to always be called with match %D"
      );
      mirrorPropAsAssertion(
        "calledWithExactly",
        "expected %n to be called with exact arguments %D"
      );
      mirrorPropAsAssertion(
        "calledOnceWith",
        "expected %n to be called once and with arguments %D"
      );
      mirrorPropAsAssertion(
        "calledOnceWithExactly",
        "expected %n to be called once and with exact arguments %D"
      );
      mirrorPropAsAssertion(
        "calledOnceWithMatch",
        "expected %n to be called once and with match %D"
      );
      mirrorPropAsAssertion(
        "alwaysCalledWithExactly",
        "expected %n to always be called with exact arguments %D"
      );
      mirrorPropAsAssertion(
        "neverCalledWith",
        "expected %n to never be called with arguments %*%C"
      );
      mirrorPropAsAssertion(
        "neverCalledWithMatch",
        "expected %n to never be called with match %*%C"
      );
      mirrorPropAsAssertion("threw", "%n did not throw exception%C");
      mirrorPropAsAssertion("alwaysThrew", "%n did not always throw exception%C");
      return assert2;
    }
    var assert = createAssertObject();
    assert.createAssertObject = createAssertObject;
    module2.exports = assert;
  }
});

// node_modules/@sinonjs/fake-timers/src/fake-timers-src.js
var require_fake_timers_src = __commonJS({
  "node_modules/@sinonjs/fake-timers/src/fake-timers-src.js"(exports2, module2) {
    "use strict";
    var globalObject = require_lib().global;
    var timersModule;
    var timersPromisesModule;
    if (typeof require === "function" && typeof module2 === "object") {
      try {
        timersModule = require("timers");
      } catch {
      }
      try {
        timersPromisesModule = require("timers/promises");
      } catch {
      }
    }
    function withGlobal(_global) {
      const maxTimeout = Math.pow(2, 31) - 1;
      const idCounterStart = 1e12;
      const NOOP = function() {
        return void 0;
      };
      const NOOP_ARRAY = function() {
        return [];
      };
      const isPresent = {};
      let timeoutResult, addTimerReturnsObject = false;
      if (_global.setTimeout) {
        isPresent.setTimeout = true;
        timeoutResult = _global.setTimeout(NOOP, 0);
        addTimerReturnsObject = typeof timeoutResult === "object";
      }
      isPresent.clearTimeout = Boolean(_global.clearTimeout);
      isPresent.setInterval = Boolean(_global.setInterval);
      isPresent.clearInterval = Boolean(_global.clearInterval);
      isPresent.hrtime = _global.process && typeof _global.process.hrtime === "function";
      isPresent.hrtimeBigint = isPresent.hrtime && typeof _global.process.hrtime.bigint === "function";
      isPresent.nextTick = _global.process && typeof _global.process.nextTick === "function";
      const utilPromisify = _global.process && require_util().promisify;
      isPresent.performance = _global.performance && typeof _global.performance.now === "function";
      const hasPerformancePrototype = _global.Performance && (typeof _global.Performance).match(/^(function|object)$/);
      const hasPerformanceConstructorPrototype = _global.performance && _global.performance.constructor && _global.performance.constructor.prototype;
      isPresent.queueMicrotask = Object.prototype.hasOwnProperty.call(
        _global,
        "queueMicrotask"
      );
      isPresent.requestAnimationFrame = _global.requestAnimationFrame && typeof _global.requestAnimationFrame === "function";
      isPresent.cancelAnimationFrame = _global.cancelAnimationFrame && typeof _global.cancelAnimationFrame === "function";
      isPresent.requestIdleCallback = _global.requestIdleCallback && typeof _global.requestIdleCallback === "function";
      isPresent.cancelIdleCallback = _global.cancelIdleCallback && typeof _global.cancelIdleCallback === "function";
      isPresent.setImmediate = _global.setImmediate && typeof _global.setImmediate === "function";
      isPresent.clearImmediate = _global.clearImmediate && typeof _global.clearImmediate === "function";
      isPresent.Intl = _global.Intl && typeof _global.Intl === "object";
      isPresent.Temporal = _global.Temporal !== null && typeof _global.Temporal === "object" && typeof _global.Temporal.Now !== "undefined" && typeof _global.Temporal.Instant !== "undefined";
      if (_global.clearTimeout) {
        _global.clearTimeout(timeoutResult);
      }
      const NativeDate = _global.Date;
      const NativeIntl = isPresent.Intl ? Object.defineProperties(
        /* @__PURE__ */ Object.create(null),
        Object.getOwnPropertyDescriptors(_global.Intl)
      ) : void 0;
      const NativeTemporal = isPresent.Temporal ? _global.Temporal : void 0;
      let uniqueTimerId = idCounterStart;
      let uniqueTimerOrder = 0;
      if (NativeDate === void 0) {
        throw new Error(
          "The global scope doesn't have a `Date` object (see https://github.com/sinonjs/sinon/issues/1852#issuecomment-419622780)"
        );
      }
      isPresent.Date = true;
      class FakePerformanceEntry {
        constructor(name, entryType, startTime, duration) {
          this.name = name;
          this.entryType = entryType;
          this.startTime = startTime;
          this.duration = duration;
        }
        toJSON() {
          return JSON.stringify({ ...this });
        }
      }
      function isNumberFinite(num) {
        if (Number.isFinite) {
          return Number.isFinite(num);
        }
        return isFinite(num);
      }
      function checkIsNearInfiniteLimit(clock, i) {
        if (clock.loopLimit && i === clock.loopLimit - 1) {
          clock.isNearInfiniteLimit = true;
        }
      }
      function resetIsNearInfiniteLimit(clock) {
        if (clock) {
          clock.isNearInfiniteLimit = false;
        }
      }
      function parseTime(str) {
        if (!str) {
          return 0;
        }
        const strings = str.split(":");
        const l = strings.length;
        let i = l;
        let ms = 0;
        let parsed;
        if (l > 3 || !/^(\d\d:){0,2}\d\d?$/.test(str)) {
          throw new Error(
            "tick only understands numbers, 'm:s' and 'h:m:s'. Each part must be two digits"
          );
        }
        while (i--) {
          parsed = parseInt(strings[i], 10);
          if (parsed >= 60) {
            throw new Error(`Invalid time ${str}`);
          }
          ms += parsed * Math.pow(60, l - i - 1);
        }
        return ms * 1e3;
      }
      function nanoRemainder(msFloat) {
        const modulo = 1e6;
        const remainder = msFloat * 1e6 % modulo;
        const positiveRemainder = remainder < 0 ? remainder + modulo : remainder;
        return Math.floor(positiveRemainder);
      }
      function getEpoch(epoch) {
        if (!epoch) {
          return 0;
        }
        if (typeof epoch === "number") {
          return epoch;
        }
        if (typeof /** @type {Date} */
        epoch.getTime === "function") {
          return (
            /** @type {Date} */
            epoch.getTime()
          );
        }
        if (typeof /** @type {TemporalTimelike} */
        epoch.epochMilliseconds === "number") {
          return (
            /** @type {TemporalTimelike} */
            epoch.epochMilliseconds
          );
        }
        throw new TypeError("now should be milliseconds since UNIX epoch");
      }
      function inRange(from, to, timer) {
        return timer && timer.callAt >= from && timer.callAt <= to;
      }
      function getInfiniteLoopError(clock, job) {
        const infiniteLoopError = new Error(
          `Aborting after running ${clock.loopLimit} timers, assuming an infinite loop!`
        );
        if (!job.error) {
          return infiniteLoopError;
        }
        const computedTargetPattern = /target\.*[<|(|[].*?[>|\]|)]\s*/;
        let clockMethodPattern = new RegExp(
          String(Object.keys(clock).join("|"))
        );
        if (addTimerReturnsObject) {
          clockMethodPattern = new RegExp(
            `\\s+at (Object\\.)?(?:${Object.keys(clock).join("|")})\\s+`
          );
        }
        let matchedLineIndex = -1;
        job.error.stack.split("\n").some(function(line, i) {
          const matchedComputedTarget = line.match(computedTargetPattern);
          if (matchedComputedTarget) {
            matchedLineIndex = i;
            return true;
          }
          const matchedClockMethod = line.match(clockMethodPattern);
          if (matchedClockMethod) {
            matchedLineIndex = i;
            return false;
          }
          return matchedLineIndex >= 0;
        });
        const stack = `${infiniteLoopError}
${job.type || "Microtask"} - ${job.func.name || "anonymous"}
${job.error.stack.split("\n").slice(matchedLineIndex + 1).join("\n")}`;
        try {
          Object.defineProperty(infiniteLoopError, "stack", {
            value: stack
          });
        } catch {
        }
        return infiniteLoopError;
      }
      function createDate() {
        class ClockDate extends NativeDate {
          /** @type {Clock} */
          static clock;
          constructor(...args) {
            if (args.length === 0) {
              super(ClockDate.clock.now);
            } else {
              super(...args);
            }
            Object.defineProperty(this, "constructor", {
              value: NativeDate,
              enumerable: false
            });
          }
          static [Symbol.hasInstance](instance) {
            return instance instanceof NativeDate;
          }
        }
        ClockDate.isFake = true;
        if (NativeDate.now) {
          ClockDate.now = function now() {
            return ClockDate.clock.now;
          };
        }
        const NativeDateWithToSource = (
          /** @type {typeof Date & { toSource?: () => string }} */
          NativeDate
        );
        if (NativeDateWithToSource.toSource) {
          ClockDate.toSource = function toSource() {
            return NativeDateWithToSource.toSource();
          };
        }
        ClockDate.toString = function toString() {
          return NativeDateWithToSource.toString();
        };
        const ClockDateProxy = new Proxy(ClockDate, {
          // handler for [[Call]] invocations (i.e. not using `new`)
          apply() {
            if (this instanceof ClockDate) {
              throw new TypeError(
                "A Proxy should only capture `new` calls with the `construct` handler. This is not supposed to be possible, so check the logic."
              );
            }
            return new NativeDate(ClockDate.clock.now).toString();
          }
        });
        return (
          /** @type {typeof Date & { clock: Clock }} */
          /** @type {unknown} */
          ClockDateProxy
        );
      }
      function createIntl(clock) {
        const IntlWithClock = { clock };
        Object.getOwnPropertyNames(NativeIntl).forEach(
          (property) => IntlWithClock[property] = NativeIntl[property]
        );
        IntlWithClock.DateTimeFormat = function(...args) {
          const realFormatter = new NativeIntl.DateTimeFormat(...args);
          const formatter = {};
          ["formatRange", "formatRangeToParts", "resolvedOptions"].forEach(
            (method) => {
              formatter[method] = realFormatter[method].bind(realFormatter);
            }
          );
          ["format", "formatToParts"].forEach((method) => {
            formatter[method] = function(date) {
              return realFormatter[method](
                date || IntlWithClock.clock.now
              );
            };
          });
          return formatter;
        };
        IntlWithClock.DateTimeFormat.prototype = Object.create(
          NativeIntl.DateTimeFormat.prototype
        );
        IntlWithClock.DateTimeFormat.supportedLocalesOf = NativeIntl.DateTimeFormat.supportedLocalesOf;
        return IntlWithClock;
      }
      function createTemporal(clock, getNanos) {
        const fakeNow = {
          instant() {
            return NativeTemporal.Instant.fromEpochNanoseconds(
              BigInt(clock.now) * 1000000n + BigInt(getNanos())
            );
          },
          timeZoneId() {
            return NativeTemporal.Now.timeZoneId();
          },
          zonedDateTimeISO(timeZone) {
            const tz = timeZone ?? NativeTemporal.Now.timeZoneId();
            return fakeNow.instant().toZonedDateTimeISO(tz);
          },
          plainDateTimeISO(timeZone) {
            return fakeNow.zonedDateTimeISO(timeZone).toPlainDateTime();
          },
          plainDateISO(timeZone) {
            return fakeNow.zonedDateTimeISO(timeZone).toPlainDate();
          },
          plainTimeISO(timeZone) {
            return fakeNow.zonedDateTimeISO(timeZone).toPlainTime();
          }
        };
        const TemporalWithClock = Object.create(
          Object.getPrototypeOf(NativeTemporal)
        );
        [
          ...Object.getOwnPropertyNames(NativeTemporal),
          ...Object.getOwnPropertySymbols(NativeTemporal)
        ].forEach((prop) => {
          Object.defineProperty(
            TemporalWithClock,
            prop,
            Object.getOwnPropertyDescriptor(NativeTemporal, prop)
          );
        });
        Object.defineProperty(TemporalWithClock, "Now", {
          value: fakeNow,
          writable: true,
          enumerable: false,
          configurable: true
        });
        return TemporalWithClock;
      }
      function enqueueJob(clock, job) {
        if (!clock.jobs) {
          clock.jobs = [];
        }
        clock.jobs.push(job);
      }
      function runJobs(clock) {
        if (!clock.jobs) {
          return;
        }
        const wasNearLimit = clock.isNearInfiniteLimit;
        for (let i = 0; i < clock.jobs.length; i++) {
          const job = clock.jobs[i];
          job.func.apply(null, job.args);
          checkIsNearInfiniteLimit(clock, i);
          if (clock.loopLimit && i > clock.loopLimit) {
            throw getInfiniteLoopError(clock, job);
          }
        }
        if (!wasNearLimit) {
          resetIsNearInfiniteLimit(clock);
        }
        clock.jobs = [];
      }
      class TimerHeap {
        constructor() {
          this.timers = [];
        }
        /**
         * Look at the next timer without removing it.
         * This is the timer the clock would run first if time advanced now.
         * @returns {Timer}
         */
        peek() {
          return this.timers[0];
        }
        /**
         * Add a timer to the waiting room, then move it upward until it is in
         * the right place relative to the timers it should run before and after.
         * @param {Timer} timer
         */
        push(timer) {
          this.timers.push(timer);
          this.bubbleUp(this.timers.length - 1);
        }
        /**
         * Remove and return the next timer to run.
         *
         * We pull the front timer out, move the last timer into the empty spot,
         * and then shift that replacement down until the ordering is correct
         * again. That avoids rebuilding the whole list from scratch.
         * @returns {Timer|undefined}
         */
        pop() {
          if (this.timers.length === 0) {
            return void 0;
          }
          const first = this.timers[0];
          const last = this.timers.pop();
          if (this.timers.length > 0) {
            this.timers[0] = last;
            last.heapIndex = 0;
            this.bubbleDown(0);
          }
          delete first.heapIndex;
          return first;
        }
        /**
         * Remove a specific timer from the waiting room.
         *
         * The heap stores timers in a shape that lets us jump directly to the
         * timer's current position, replace it with the last timer, and then
         * move that replacement up or down until the ordering is correct again.
         * @param {Timer} timer
         * @returns {boolean}
         */
        remove(timer) {
          const index = timer.heapIndex;
          if (index === void 0 || this.timers[index] !== timer) {
            return false;
          }
          const last = this.timers.pop();
          if (timer !== last) {
            this.timers[index] = last;
            last.heapIndex = index;
            if (compareTimers(last, timer) < 0) {
              this.bubbleUp(index);
            } else {
              this.bubbleDown(index);
            }
          }
          delete timer.heapIndex;
          return true;
        }
        /**
         * Move a timer toward the front until it is no longer "earlier" than
         * the timer above it.
         *
         * Conceptually, this is what happens when something newly scheduled
         * turns out to belong ahead of its parent in the waiting room. We keep
         * swapping it upward until it is no longer out of place.
         * @param {number} index
         */
        bubbleUp(index) {
          const timer = this.timers[index];
          let currentIndex = index;
          while (currentIndex > 0) {
            const parentIndex = Math.floor((currentIndex - 1) / 2);
            const parent = this.timers[parentIndex];
            if (compareTimers(timer, parent) < 0) {
              this.timers[currentIndex] = parent;
              parent.heapIndex = currentIndex;
              currentIndex = parentIndex;
            } else {
              break;
            }
          }
          this.timers[currentIndex] = timer;
          timer.heapIndex = currentIndex;
        }
        /**
         * Move a timer away from the front until the timer below it is no
         * longer supposed to run after it.
         *
         * This is the opposite of `bubbleUp`: when a timer at the front is
         * removed or moved, the replacement may be too far ahead, so we
         * repeatedly swap it downward with the best child until the waiting
         * room is ordered again.
         * @param {number} index
         */
        bubbleDown(index) {
          const timer = this.timers[index];
          let currentIndex = index;
          const halfLength = Math.floor(this.timers.length / 2);
          while (currentIndex < halfLength) {
            const leftIndex = currentIndex * 2 + 1;
            const rightIndex = leftIndex + 1;
            let bestChildIndex = leftIndex;
            let bestChild = this.timers[leftIndex];
            if (rightIndex < this.timers.length && compareTimers(this.timers[rightIndex], bestChild) < 0) {
              bestChildIndex = rightIndex;
              bestChild = this.timers[rightIndex];
            }
            if (compareTimers(bestChild, timer) < 0) {
              this.timers[currentIndex] = bestChild;
              bestChild.heapIndex = currentIndex;
              currentIndex = bestChildIndex;
            } else {
              break;
            }
          }
          this.timers[currentIndex] = timer;
          timer.heapIndex = currentIndex;
        }
      }
      function ensureTimerState(clock) {
        if (!clock.timers) {
          clock.timers = /* @__PURE__ */ new Map();
          clock.timerHeap = new TimerHeap();
        }
      }
      function hasTimer(clock, id) {
        return clock.timers ? clock.timers.has(id) : false;
      }
      function getTimer(clock, id) {
        return clock.timers ? clock.timers.get(id) : void 0;
      }
      function setTimer(clock, timer) {
        ensureTimerState(clock);
        clock.timers.set(timer.id, timer);
      }
      function deleteTimer(clock, id) {
        return clock.timers ? clock.timers.delete(id) : false;
      }
      function forEachActiveTimer(clock, callback) {
        if (!clock.timers) {
          return;
        }
        for (const timer of clock.timers.values()) {
          callback(timer);
        }
      }
      function rebuildTimerHeap(clock) {
        clock.timerHeap = new TimerHeap();
        forEachActiveTimer(clock, (timer) => {
          clock.timerHeap.push(timer);
        });
      }
      function addTimer(clock, timer) {
        if (timer.func === void 0) {
          throw new Error("Callback must be provided to timer calls");
        }
        if (typeof timer.func !== "function") {
          throw new TypeError(
            `[ERR_INVALID_CALLBACK]: Callback must be a function. Received ${timer.func} of type ${typeof timer.func}`
          );
        }
        if (clock.isNearInfiniteLimit) {
          timer.error = new Error();
        }
        timer.type = timer.immediate ? "Immediate" : "Timeout";
        if (Object.prototype.hasOwnProperty.call(timer, "delay")) {
          if (typeof timer.delay !== "number") {
            timer.delay = parseInt(timer.delay, 10);
          }
          if (!isNumberFinite(timer.delay)) {
            timer.delay = 0;
          }
          timer.delay = timer.delay > maxTimeout ? 1 : timer.delay;
          timer.delay = Math.max(0, timer.delay);
        }
        if (Object.prototype.hasOwnProperty.call(timer, "interval")) {
          timer.type = "Interval";
          timer.interval = timer.interval > maxTimeout ? 1 : timer.interval;
        }
        if (Object.prototype.hasOwnProperty.call(timer, "animation")) {
          timer.type = "AnimationFrame";
          timer.animation = true;
        }
        if (Object.prototype.hasOwnProperty.call(timer, "requestIdleCallback")) {
          if (!timer.delay) {
            timer.type = "IdleCallback";
          }
          timer.requestIdleCallback = true;
        }
        ensureTimerState(clock);
        while (hasTimer(clock, uniqueTimerId)) {
          uniqueTimerId++;
          if (uniqueTimerId >= Number.MAX_SAFE_INTEGER) {
            uniqueTimerId = idCounterStart;
          }
        }
        timer.id = uniqueTimerId++;
        if (uniqueTimerId >= Number.MAX_SAFE_INTEGER) {
          uniqueTimerId = idCounterStart;
        }
        timer.order = uniqueTimerOrder++;
        timer.createdAt = clock.now;
        timer.callAt = clock.now + (parseInt(String(timer.delay)) || (clock.duringTick ? 1 : 0));
        setTimer(clock, timer);
        clock.timerHeap.push(timer);
        if (addTimerReturnsObject) {
          const res = {
            refed: true,
            ref: function() {
              this.refed = true;
              return this;
            },
            unref: function() {
              this.refed = false;
              return this;
            },
            hasRef: function() {
              return this.refed;
            },
            refresh: function() {
              timer.callAt = clock.now + (parseInt(String(timer.delay)) || (clock.duringTick ? 1 : 0));
              clock.timerHeap.remove(timer);
              timer.order = uniqueTimerOrder++;
              setTimer(clock, timer);
              clock.timerHeap.push(timer);
              return this;
            },
            [Symbol.toPrimitive]: function() {
              return timer.id;
            }
          };
          return res;
        }
        return timer.id;
      }
      function compareTimers(a, b) {
        if (a.type === "IdleCallback" && b.type !== "IdleCallback") {
          return 1;
        }
        if (a.type !== "IdleCallback" && b.type === "IdleCallback") {
          return -1;
        }
        if (a.callAt < b.callAt) {
          return -1;
        }
        if (a.callAt > b.callAt) {
          return 1;
        }
        if (a.immediate && !b.immediate) {
          return -1;
        }
        if (!a.immediate && b.immediate) {
          return 1;
        }
        if (a.order < b.order) {
          return -1;
        }
        if (a.order > b.order) {
          return 1;
        }
        if (a.createdAt < b.createdAt) {
          return -1;
        }
        if (a.createdAt > b.createdAt) {
          return 1;
        }
        if (a.id < b.id) {
          return -1;
        }
        if (a.id > b.id) {
          return 1;
        }
        return 0;
      }
      function firstTimerInRange(clock, from, to) {
        if (!clock.timerHeap) {
          return null;
        }
        const timers2 = clock.timerHeap.timers;
        if (timers2.length === 1 && timers2[0].requestIdleCallback) {
          return timers2[0];
        }
        const first = clock.timerHeap.peek();
        if (first && inRange(from, to, first)) {
          return first;
        }
        let timer = null;
        for (let i = 0; i < timers2.length; i++) {
          if (inRange(from, to, timers2[i]) && (!timer || compareTimers(timer, timers2[i]) === 1)) {
            timer = timers2[i];
          }
        }
        return timer;
      }
      function firstTimer(clock) {
        if (!clock.timerHeap) {
          return null;
        }
        return clock.timerHeap.peek() || null;
      }
      function lastTimer(clock) {
        if (!clock.timerHeap) {
          return null;
        }
        const timers2 = clock.timerHeap.timers;
        let timer = null;
        for (let i = 0; i < timers2.length; i++) {
          if (!timer || compareTimers(timer, timers2[i]) === -1) {
            timer = timers2[i];
          }
        }
        return timer;
      }
      function callTimer(clock, timer) {
        if (typeof timer.interval === "number") {
          clock.timerHeap.remove(timer);
          timer.callAt += timer.interval;
          timer.order = uniqueTimerOrder++;
          if (clock.isNearInfiniteLimit) {
            timer.error = new Error();
          }
          clock.timerHeap.push(timer);
        } else {
          deleteTimer(clock, timer.id);
          clock.timerHeap.remove(timer);
        }
        if (typeof timer.func === "function") {
          timer.func.apply(null, timer.args);
        }
      }
      function getClearHandler(ttype) {
        if (ttype === "IdleCallback" || ttype === "AnimationFrame") {
          return `cancel${ttype}`;
        }
        return `clear${ttype}`;
      }
      function getScheduleHandler(ttype) {
        if (ttype === "IdleCallback" || ttype === "AnimationFrame") {
          return `request${ttype}`;
        }
        return `set${ttype}`;
      }
      function createWarnOnce() {
        let calls = 0;
        return function(msg) {
          !calls++ && console.warn(msg);
        };
      }
      const warnOnce = createWarnOnce();
      function clearTimer(clock, timerId, ttype) {
        if (!timerId) {
          return;
        }
        const id = Number(timerId);
        if (Number.isNaN(id) || id < idCounterStart) {
          const handlerName = getClearHandler(ttype);
          if (clock.shouldClearNativeTimers === true) {
            const nativeHandler = clock[`_${handlerName}`];
            return typeof nativeHandler === "function" ? nativeHandler(timerId) : void 0;
          }
          const stackTrace = new Error().stack.split("\n").slice(1).join("\n");
          warnOnce(
            `FakeTimers: ${handlerName} was invoked to clear a native timer instead of one created by this library.
To automatically clean-up native timers, use \`shouldClearNativeTimers\`.
${stackTrace}`
          );
        }
        if (hasTimer(clock, id)) {
          const timer = getTimer(clock, id);
          if (timer.type === ttype || timer.type === "Timeout" && ttype === "Interval" || timer.type === "Interval" && ttype === "Timeout") {
            deleteTimer(clock, id);
            clock.timerHeap.remove(timer);
          } else {
            const clear = getClearHandler(ttype);
            const schedule = getScheduleHandler(timer.type);
            throw new Error(
              `Cannot clear timer: timer created with ${schedule}() but cleared with ${clear}()`
            );
          }
        }
      }
      function hijackMethod(target, method, clock) {
        clock[method].hasOwnProperty = Object.prototype.hasOwnProperty.call(
          target,
          method
        );
        clock[`_${method}`] = target[method];
        if (method === "Date") {
          target[method] = clock[method];
        } else if (method === "Intl") {
          target[method] = clock[method];
        } else if (method === "Temporal") {
          target[method] = clock[method];
        } else if (method === "performance") {
          const originalPerfDescriptor = Object.getOwnPropertyDescriptor(
            target,
            method
          );
          if (originalPerfDescriptor && originalPerfDescriptor.get && !originalPerfDescriptor.set) {
            Object.defineProperty(
              clock,
              `_${method}`,
              originalPerfDescriptor
            );
            const perfDescriptor = Object.getOwnPropertyDescriptor(
              clock,
              method
            );
            Object.defineProperty(target, method, perfDescriptor);
          } else {
            target[method] = clock[method];
          }
        } else {
          target[method] = function() {
            return clock[method].apply(clock, arguments);
          };
          Object.defineProperties(
            target[method],
            Object.getOwnPropertyDescriptors(clock[method])
          );
        }
        target[method].clock = clock;
      }
      function doIntervalTick(clock, advanceTimeDelta) {
        clock.tick(advanceTimeDelta);
      }
      const timers = {
        setTimeout: _global.setTimeout,
        clearTimeout: _global.clearTimeout,
        setInterval: _global.setInterval,
        clearInterval: _global.clearInterval,
        Date: _global.Date
      };
      if (isPresent.setImmediate) {
        timers.setImmediate = _global.setImmediate;
      }
      if (isPresent.clearImmediate) {
        timers.clearImmediate = _global.clearImmediate;
      }
      if (isPresent.hrtime) {
        timers.hrtime = _global.process.hrtime;
      }
      if (isPresent.nextTick) {
        timers.nextTick = _global.process.nextTick;
      }
      if (isPresent.performance) {
        timers.performance = _global.performance;
      }
      if (isPresent.requestAnimationFrame) {
        timers.requestAnimationFrame = _global.requestAnimationFrame;
      }
      if (isPresent.queueMicrotask) {
        timers.queueMicrotask = _global.queueMicrotask;
      }
      if (isPresent.cancelAnimationFrame) {
        timers.cancelAnimationFrame = _global.cancelAnimationFrame;
      }
      if (isPresent.requestIdleCallback) {
        timers.requestIdleCallback = _global.requestIdleCallback;
      }
      if (isPresent.cancelIdleCallback) {
        timers.cancelIdleCallback = _global.cancelIdleCallback;
      }
      if (isPresent.Intl) {
        timers.Intl = NativeIntl;
      }
      if (isPresent.Temporal) {
        timers.Temporal = NativeTemporal;
      }
      const originalSetTimeout = _global.setImmediate || _global.setTimeout;
      const originalClearInterval = _global.clearInterval;
      const originalSetInterval = _global.setInterval;
      function createClock(start, loopLimit) {
        start = Math.floor(getEpoch(start));
        const startTimestamp = start;
        loopLimit = loopLimit || 1e3;
        let nanos = 0;
        let uninstalled = false;
        const adjustedSystemTime = [0, 0];
        const clock = (
          /** @type {Clock} */
          {
            now: start,
            Date: createDate(),
            loopLimit,
            isNearInfiniteLimit: false,
            tickMode: { mode: "manual", counter: 0, delta: void 0 }
          }
        );
        clock.Date.clock = clock;
        function getTimeToNextFrame() {
          return 16 - (clock.now - startTimestamp) % 16;
        }
        function hrtime(prev) {
          const millisSinceStart = clock.now - adjustedSystemTime[0] - startTimestamp;
          const secsSinceStart = Math.floor(millisSinceStart / 1e3);
          const remainderInNanos = (millisSinceStart - secsSinceStart * 1e3) * 1e6 + nanos - adjustedSystemTime[1];
          if (Array.isArray(prev)) {
            if (prev[1] > 1e9) {
              throw new TypeError(
                "Number of nanoseconds can't exceed a billion"
              );
            }
            const oldSecs = prev[0];
            let nanoDiff = remainderInNanos - prev[1];
            let secDiff = secsSinceStart - oldSecs;
            if (nanoDiff < 0) {
              nanoDiff += 1e9;
              secDiff -= 1;
            }
            return [secDiff, nanoDiff];
          }
          return [secsSinceStart, remainderInNanos];
        }
        function fakePerformanceNow() {
          const hrt = hrtime();
          const millis = hrt[0] * 1e3 + hrt[1] / 1e6;
          return millis;
        }
        if (isPresent.hrtimeBigint) {
          hrtime.bigint = function() {
            const parts = hrtime();
            return BigInt(parts[0]) * BigInt(1e9) + BigInt(parts[1]);
          };
        }
        if (isPresent.Intl) {
          clock.Intl = createIntl(clock);
          clock.Intl.clock = clock;
        }
        if (isPresent.Temporal) {
          clock.Temporal = createTemporal(clock, () => nanos);
        }
        clock.setTickMode = function(tickModeConfig) {
          const { mode: newMode, delta: newDelta } = (
            /** @type {SetTickModeConfig} */
            tickModeConfig
          );
          const { mode: oldMode, delta: oldDelta } = clock.tickMode;
          if (newMode === oldMode && newDelta === oldDelta) {
            return;
          }
          if (oldMode === "interval") {
            originalClearInterval(clock.attachedInterval);
          }
          clock.tickMode = {
            counter: clock.tickMode.counter + 1,
            mode: newMode,
            delta: newDelta
          };
          if (newMode === "nextAsync") {
            advanceUntilModeChanges();
          } else if (newMode === "interval") {
            createIntervalTick(clock, newDelta || 20);
          }
        };
        async function advanceUntilModeChanges() {
          async function newMacrotask() {
            const channel = new MessageChannel();
            await new Promise((resolve) => {
              channel.port1.onmessage = () => {
                resolve(void 0);
                channel.port1.close();
              };
              channel.port2.postMessage(void 0);
            });
            channel.port1.close();
            channel.port2.close();
            await new Promise((resolve) => {
              originalSetTimeout(resolve);
            });
          }
          const { counter } = clock.tickMode;
          while (clock.tickMode.counter === counter) {
            await newMacrotask();
            if (clock.tickMode.counter !== counter) {
              return;
            }
            clock.next();
          }
        }
        function pauseAutoTickUntilFinished(promise) {
          if (clock.tickMode.mode !== "nextAsync") {
            return promise;
          }
          clock.setTickMode({ mode: "manual" });
          return promise.finally(() => {
            if (!uninstalled) {
              clock.setTickMode({ mode: "nextAsync" });
            }
          });
        }
        function getTimeToNextIdlePeriod() {
          let timeToNextIdlePeriod = 0;
          if (clock.countTimers() > 0) {
            timeToNextIdlePeriod = 50;
          }
          return timeToNextIdlePeriod;
        }
        clock.requestIdleCallback = function requestIdleCallback(func, { timeout } = (
          /** @type {{ timeout?: number }} */
          {}
        )) {
          const idleDeadline = {
            didTimeout: true,
            timeRemaining: getTimeToNextIdlePeriod
          };
          const result = addTimer(clock, {
            func,
            args: [idleDeadline],
            delay: timeout,
            requestIdleCallback: true
          });
          return Number(result);
        };
        clock.cancelIdleCallback = function cancelIdleCallback(timerId) {
          return clearTimer(clock, timerId, "IdleCallback");
        };
        clock.setTimeout = function setTimeout2(func, timeout) {
          return addTimer(clock, {
            func,
            args: Array.prototype.slice.call(arguments, 2),
            delay: timeout
          });
        };
        if (typeof _global.Promise !== "undefined" && utilPromisify) {
          clock.setTimeout[utilPromisify.custom] = function promisifiedSetTimeout(timeout, arg) {
            return new _global.Promise(function setTimeoutExecutor(resolve) {
              addTimer(clock, {
                func: resolve,
                args: [arg],
                delay: timeout
              });
            });
          };
        }
        clock.clearTimeout = function clearTimeout2(timerId) {
          return clearTimer(clock, timerId, "Timeout");
        };
        clock.nextTick = function nextTick(func) {
          return enqueueJob(clock, {
            func,
            args: Array.prototype.slice.call(arguments, 1),
            error: clock.isNearInfiniteLimit ? new Error() : null
          });
        };
        clock.queueMicrotask = function queueMicrotask(func) {
          return clock.nextTick(func);
        };
        clock.setInterval = function setInterval2(func, timeout) {
          timeout = parseInt(String(timeout), 10);
          return addTimer(clock, {
            func,
            args: Array.prototype.slice.call(arguments, 2),
            delay: timeout,
            interval: timeout
          });
        };
        clock.clearInterval = function clearInterval2(timerId) {
          return clearTimer(clock, timerId, "Interval");
        };
        if (isPresent.setImmediate) {
          clock.setImmediate = /** @type {SetImmediate} */
          (function setImmediate(func) {
            return addTimer(clock, {
              func,
              args: Array.prototype.slice.call(arguments, 1),
              immediate: true
            });
          });
          if (typeof _global.Promise !== "undefined" && utilPromisify) {
            clock.setImmediate[utilPromisify.custom] = function promisifiedSetImmediate(arg) {
              return new _global.Promise(
                function setImmediateExecutor(resolve) {
                  addTimer(clock, {
                    func: resolve,
                    args: [arg],
                    immediate: true
                  });
                }
              );
            };
          }
          clock.clearImmediate = function clearImmediate(timerId) {
            return clearTimer(clock, timerId, "Immediate");
          };
        }
        clock.countTimers = function countTimers() {
          return (clock.timerHeap ? clock.timerHeap.timers.length : 0) + (clock.jobs || []).length;
        };
        clock.requestAnimationFrame = function requestAnimationFrame(func) {
          const result = addTimer(clock, {
            func,
            delay: getTimeToNextFrame(),
            get args() {
              return [fakePerformanceNow()];
            },
            animation: true
          });
          return Number(result);
        };
        clock.cancelAnimationFrame = function cancelAnimationFrame(timerId) {
          return clearTimer(clock, timerId, "AnimationFrame");
        };
        clock.runMicrotasks = function runMicrotasks() {
          runJobs(clock);
        };
        function durationToMs(duration) {
          const relativeTo = NativeTemporal.Instant.fromEpochMilliseconds(
            clock.now
          ).toZonedDateTimeISO(NativeTemporal.Now.timeZoneId());
          return duration.total({ unit: "millisecond", relativeTo });
        }
        function tickValueToMs(tickValue) {
          if (typeof tickValue === "number") {
            return tickValue;
          }
          if (isPresent.Temporal && tickValue !== null && typeof tickValue === "object" && typeof /** @type {TemporalDuration} */
          tickValue.total === "function") {
            return durationToMs(
              /** @type {TemporalDuration} */
              tickValue
            );
          }
          return parseTime(
            /** @type {string} */
            tickValue
          );
        }
        function createTickState(tickValue) {
          const msFloat = tickValueToMs(tickValue);
          const ms = Math.floor(msFloat);
          const remainder = nanoRemainder(msFloat);
          let nanosTotal = nanos + remainder;
          let tickTo = clock.now + ms;
          if (msFloat < 0) {
            throw new TypeError("Negative ticks are not supported");
          }
          if (nanosTotal >= 1e6) {
            tickTo += 1;
            nanosTotal -= 1e6;
          }
          return (
            /** @type {ClockState} */
            {
              msFloat,
              ms,
              nanosTotal,
              tickFrom: clock.now,
              tickTo,
              previous: clock.now,
              timer: null,
              firstException: null,
              oldNow: null
            }
          );
        }
        function applyClockChangeCompensation(state, oldNow, options) {
          if (oldNow !== clock.now) {
            const difference = clock.now - oldNow;
            state.tickFrom += difference;
            state.tickTo += difference;
            if (options && options.includePrevious) {
              state.previous += difference;
            }
          }
        }
        function runInitialJobs(state) {
          state.oldNow = clock.now;
          runJobs(clock);
          applyClockChangeCompensation(state, state.oldNow);
        }
        function runPostLoopJobs(state) {
          state.oldNow = clock.now;
          runJobs(clock);
          applyClockChangeCompensation(state, state.oldNow);
        }
        function selectNextTimerInRange(state) {
          state.timer = firstTimerInRange(
            clock,
            state.previous,
            state.tickTo
          );
          state.previous = state.tickFrom;
        }
        function runTimersInRange(state, isAsync, nextPromiseTick, compensationCheck) {
          state.timer = firstTimerInRange(
            clock,
            state.tickFrom,
            state.tickTo
          );
          while (state.timer && state.tickFrom <= state.tickTo) {
            if (hasTimer(clock, state.timer.id)) {
              state.tickFrom = state.timer.callAt;
              clock.now = state.timer.callAt;
              state.oldNow = clock.now;
              try {
                runJobs(clock);
                callTimer(clock, state.timer);
              } catch (e) {
                state.firstException = state.firstException || e;
              }
              if (isAsync) {
                originalSetTimeout(nextPromiseTick);
                return true;
              }
              compensationCheck();
            }
            selectNextTimerInRange(state);
          }
          return false;
        }
        function finalizeTick(state, isAsync, resolve) {
          state.timer = firstTimerInRange(
            clock,
            state.tickFrom,
            state.tickTo
          );
          if (state.timer) {
            try {
              clock.tick(state.tickTo - clock.now);
            } catch (e) {
              state.firstException = state.firstException || e;
            }
          } else {
            clock.now = state.tickTo;
            nanos = state.nanosTotal;
          }
          if (state.firstException) {
            throw state.firstException;
          }
          if (isAsync) {
            resolve(clock.now);
          } else {
            return clock.now;
          }
        }
        function doTick(tickValue, isAsync, resolve, reject) {
          const state = createTickState(tickValue);
          nanos = state.nanosTotal;
          clock.duringTick = true;
          runInitialJobs(state);
          const compensationCheck = function() {
            applyClockChangeCompensation(state, state.oldNow, {
              includePrevious: true
            });
          };
          const nextPromiseTick = isAsync && function() {
            try {
              compensationCheck();
              selectNextTimerInRange(state);
              doTickInner();
            } catch (e) {
              reject(e);
            }
          };
          function doTickInner() {
            if (runTimersInRange(
              state,
              isAsync,
              nextPromiseTick,
              compensationCheck
            )) {
              return;
            }
            runPostLoopJobs(state);
            clock.duringTick = false;
            return finalizeTick(state, isAsync, resolve);
          }
          return doTickInner();
        }
        clock.tick = function tick(tickValue) {
          return doTick(tickValue, false);
        };
        clock.next = function next() {
          runJobs(clock);
          const timer = firstTimer(clock);
          if (!timer) {
            return clock.now;
          }
          clock.duringTick = true;
          try {
            clock.now = timer.callAt;
            callTimer(clock, timer);
            runJobs(clock);
            return clock.now;
          } finally {
            clock.duringTick = false;
          }
        };
        function runAsyncWithNativeTimeout(callback) {
          return pauseAutoTickUntilFinished(
            new _global.Promise(function(resolve, reject) {
              originalSetTimeout(function() {
                try {
                  callback(resolve, reject);
                } catch (e) {
                  reject(e);
                }
              });
            })
          );
        }
        clock.runAll = function runAll() {
          runJobs(clock);
          for (let i = 0; i < clock.loopLimit; i++) {
            if (!clock.timers) {
              resetIsNearInfiniteLimit(clock);
              return clock.now;
            }
            const numTimers = clock.timerHeap.timers.length;
            if (numTimers === 0) {
              resetIsNearInfiniteLimit(clock);
              return clock.now;
            }
            checkIsNearInfiniteLimit(clock, i);
            clock.next();
          }
          const excessJob = firstTimer(clock);
          throw getInfiniteLoopError(clock, excessJob);
        };
        clock.runToFrame = function runToFrame() {
          return clock.tick(getTimeToNextFrame());
        };
        clock.runToLast = function runToLast() {
          const timer = lastTimer(clock);
          if (!timer) {
            runJobs(clock);
            return clock.now;
          }
          return clock.tick(timer.callAt - clock.now);
        };
        if (typeof _global.Promise !== "undefined") {
          clock.tickAsync = function tickAsync(tickValue) {
            return runAsyncWithNativeTimeout(function(resolve, reject) {
              doTick(tickValue, true, resolve, reject);
            });
          };
          clock.nextAsync = function nextAsync() {
            return runAsyncWithNativeTimeout(function(resolve, reject) {
              const timer = firstTimer(clock);
              if (!timer) {
                resolve(clock.now);
                return;
              }
              let err;
              clock.duringTick = true;
              clock.now = timer.callAt;
              try {
                callTimer(clock, timer);
              } catch (e) {
                err = e;
              }
              clock.duringTick = false;
              originalSetTimeout(function() {
                if (err) {
                  reject(err);
                } else {
                  resolve(clock.now);
                }
              });
            });
          };
          clock.runAllAsync = function runAllAsync() {
            let i = 0;
            function doRun(resolve, reject) {
              try {
                runJobs(clock);
                let numTimers;
                if (i < clock.loopLimit) {
                  if (!clock.timerHeap) {
                    resetIsNearInfiniteLimit(clock);
                    resolve(clock.now);
                    return;
                  }
                  numTimers = clock.timerHeap.timers.length;
                  if (numTimers === 0) {
                    resetIsNearInfiniteLimit(clock);
                    resolve(clock.now);
                    return;
                  }
                  checkIsNearInfiniteLimit(clock, i);
                  clock.next();
                  i++;
                  originalSetTimeout(function() {
                    doRun(resolve, reject);
                  });
                  return;
                }
                const excessJob = firstTimer(clock);
                reject(getInfiniteLoopError(clock, excessJob));
              } catch (e) {
                reject(e);
              }
            }
            return runAsyncWithNativeTimeout(function(resolve, reject) {
              doRun(resolve, reject);
            });
          };
          clock.runToLastAsync = function runToLastAsync() {
            return runAsyncWithNativeTimeout(function(resolve) {
              const timer = lastTimer(clock);
              if (!timer) {
                runJobs(clock);
                resolve(clock.now);
                return;
              }
              resolve(clock.tickAsync(timer.callAt - clock.now));
            });
          };
        }
        clock.reset = function reset() {
          nanos = 0;
          clock.timers = /* @__PURE__ */ new Map();
          clock.timerHeap = new TimerHeap();
          clock.jobs = [];
          clock.now = start;
        };
        clock.setSystemTime = function setSystemTime(systemTime) {
          const newNow = getEpoch(systemTime);
          const difference = newNow - clock.now;
          adjustedSystemTime[0] = adjustedSystemTime[0] + difference;
          adjustedSystemTime[1] = adjustedSystemTime[1] + nanos;
          clock.now = newNow;
          nanos = 0;
          forEachActiveTimer(clock, (timer) => {
            timer.createdAt += difference;
            timer.callAt += difference;
          });
        };
        clock.jump = function jump(tickValue) {
          const msFloat = tickValueToMs(tickValue);
          const ms = Math.floor(msFloat);
          forEachActiveTimer(clock, (timer) => {
            if (clock.now + ms > timer.callAt) {
              timer.callAt = clock.now + ms;
            }
          });
          rebuildTimerHeap(clock);
          clock.tick(ms);
          return clock.now;
        };
        if (isPresent.performance) {
          clock.performance = /* @__PURE__ */ Object.create(null);
          clock.performance.now = fakePerformanceNow;
        }
        if (isPresent.hrtime) {
          clock.hrtime = hrtime;
        }
        clock.uninstall = function() {
          uninstalled = true;
          clock.setTickMode({ mode: "manual" });
          if (clock.methods) {
            const installedHrTime = "_hrtime";
            const installedNextTick = "_nextTick";
            let method, i, l;
            for (i = 0, l = clock.methods.length; i < l; i++) {
              method = clock.methods[i];
              if (method === "hrtime" && _global.process) {
                _global.process.hrtime = clock[installedHrTime];
              } else if (method === "nextTick" && _global.process) {
                _global.process.nextTick = clock[installedNextTick];
              } else if (method === "performance") {
                const originalPerfDescriptor = Object.getOwnPropertyDescriptor(
                  clock,
                  `_${method}`
                );
                if (originalPerfDescriptor && originalPerfDescriptor.get && !originalPerfDescriptor.set) {
                  Object.defineProperty(
                    _global,
                    method,
                    originalPerfDescriptor
                  );
                } else if (originalPerfDescriptor.configurable) {
                  _global[method] = clock[`_${method}`];
                }
              } else {
                if (clock[method] && clock[method].hasOwnProperty) {
                  _global[method] = clock[`_${method}`];
                } else {
                  try {
                    delete _global[method];
                  } catch {
                  }
                }
              }
              if (clock.timersModuleMethods !== void 0) {
                for (let j = 0; j < clock.timersModuleMethods.length; j++) {
                  const entry = clock.timersModuleMethods[j];
                  timersModule[entry.methodName] = entry.original;
                }
              }
              if (clock.timersPromisesModuleMethods !== void 0) {
                for (let j = 0; j < clock.timersPromisesModuleMethods.length; j++) {
                  const entry = clock.timersPromisesModuleMethods[j];
                  timersPromisesModule[entry.methodName] = entry.original;
                }
              }
            }
            clock.methods = [];
          }
          if (clock.abortListenerMap) {
            for (const [
              listener,
              signal
            ] of clock.abortListenerMap.entries()) {
              signal.removeEventListener("abort", listener);
              clock.abortListenerMap.delete(listener);
            }
          }
          if (!clock.timerHeap) {
            return [];
          }
          return clock.timerHeap.timers.slice();
        };
        return clock;
      }
      function createIntervalTick(clock, delta) {
        const intervalTick = doIntervalTick.bind(null, clock, delta);
        const intervalId = originalSetInterval(intervalTick, delta);
        clock.attachedInterval = intervalId;
      }
      function install(config) {
        if (arguments.length > 1 || config instanceof Date || Array.isArray(config) || typeof config === "number") {
          throw new TypeError(
            `FakeTimers.install called with ${String(
              config
            )} install requires an object parameter`
          );
        }
        if (_global.Date.isFake === true) {
          throw new TypeError(
            "Can't install fake timers twice on the same global object."
          );
        }
        config = typeof config !== "undefined" ? config : {};
        config.shouldAdvanceTime = config.shouldAdvanceTime || false;
        config.advanceTimeDelta = config.advanceTimeDelta || 20;
        config.shouldClearNativeTimers = config.shouldClearNativeTimers || false;
        const hasToFake = Object.prototype.hasOwnProperty.call(
          config,
          "toFake"
        );
        const hasToNotFake = Object.prototype.hasOwnProperty.call(
          config,
          "toNotFake"
        );
        if (hasToFake && hasToNotFake) {
          throw new TypeError(
            "config.toFake and config.toNotFake cannot be used together"
          );
        }
        if (config.target) {
          throw new TypeError(
            "config.target is no longer supported. Use `withGlobal(target)` instead."
          );
        }
        function handleMissingTimer(timer) {
          if (config.ignoreMissingTimers) {
            return;
          }
          throw new ReferenceError(
            `non-existent timers and/or objects cannot be faked: '${timer}'`
          );
        }
        let i, l;
        const clock = createClock(config.now, config.loopLimit);
        clock.shouldClearNativeTimers = config.shouldClearNativeTimers;
        clock.abortListenerMap = /* @__PURE__ */ new Map();
        if (hasToFake) {
          clock.methods = /** @type {FakeMethod[]} */
          config.toFake || [];
          if (clock.methods.length === 0) {
            clock.methods = /** @type {FakeMethod[]} */
            Object.keys(timers);
          }
        } else if (hasToNotFake) {
          const methodsToNotFake = (
            /** @type {string[]} */
            config.toNotFake || []
          );
          clock.methods = /** @type {FakeMethod[]} */
          Object.keys(timers).filter(
            (method) => !methodsToNotFake.includes(method)
          );
        } else {
          clock.methods = /** @type {FakeMethod[]} */
          Object.keys(timers);
        }
        if (config.shouldAdvanceTime === true) {
          clock.setTickMode({
            mode: "interval",
            delta: config.advanceTimeDelta
          });
        }
        if (clock.methods.includes("performance")) {
          const proto = (() => {
            if (hasPerformanceConstructorPrototype) {
              return _global.performance.constructor.prototype;
            }
            if (hasPerformancePrototype) {
              return _global.Performance.prototype;
            }
          })();
          if (proto) {
            Object.getOwnPropertyNames(proto).forEach(function(name) {
              if (name !== "now") {
                clock.performance[name] = name.indexOf("getEntries") === 0 ? NOOP_ARRAY : NOOP;
              }
            });
            clock.performance.mark = (name) => new FakePerformanceEntry(name, "mark", 0, 0);
            clock.performance.measure = (name) => new FakePerformanceEntry(name, "measure", 0, 100);
            clock.performance.timeOrigin = getEpoch(config.now);
          } else if ((config.toFake || []).includes("performance")) {
            handleMissingTimer("performance");
          }
        }
        if (_global === globalObject && timersModule) {
          clock.timersModuleMethods = [];
        }
        if (_global === globalObject && timersPromisesModule) {
          clock.timersPromisesModuleMethods = [];
        }
        for (i = 0, l = clock.methods.length; i < l; i++) {
          const nameOfMethodToReplace = clock.methods[i];
          if (!isPresent[nameOfMethodToReplace]) {
            handleMissingTimer(nameOfMethodToReplace);
            continue;
          }
          if (nameOfMethodToReplace === "hrtime") {
            if (_global.process && typeof _global.process.hrtime === "function") {
              hijackMethod(_global.process, nameOfMethodToReplace, clock);
            }
          } else if (nameOfMethodToReplace === "nextTick") {
            if (_global.process && typeof _global.process.nextTick === "function") {
              hijackMethod(_global.process, nameOfMethodToReplace, clock);
            }
          } else {
            hijackMethod(_global, nameOfMethodToReplace, clock);
          }
          if (clock.timersModuleMethods !== void 0 && timersModule[nameOfMethodToReplace]) {
            const original = timersModule[nameOfMethodToReplace];
            clock.timersModuleMethods.push({
              methodName: nameOfMethodToReplace,
              original
            });
            timersModule[nameOfMethodToReplace] = _global[nameOfMethodToReplace];
          }
          if (clock.timersPromisesModuleMethods !== void 0) {
            if (nameOfMethodToReplace === "setTimeout") {
              clock.timersPromisesModuleMethods.push({
                methodName: "setTimeout",
                original: timersPromisesModule.setTimeout
              });
              timersPromisesModule.setTimeout = (delay, value, options = {}) => new Promise((resolve, reject) => {
                const abort = () => {
                  options.signal.removeEventListener(
                    "abort",
                    abort
                  );
                  clock.abortListenerMap.delete(abort);
                  clock.clearTimeout(handle);
                  reject(options.signal.reason);
                };
                const handle = clock.setTimeout(() => {
                  if (options.signal) {
                    options.signal.removeEventListener(
                      "abort",
                      abort
                    );
                    clock.abortListenerMap.delete(abort);
                  }
                  resolve(value);
                }, delay);
                if (options.signal) {
                  if (options.signal.aborted) {
                    abort();
                  } else {
                    options.signal.addEventListener(
                      "abort",
                      abort
                    );
                    clock.abortListenerMap.set(
                      abort,
                      options.signal
                    );
                  }
                }
              });
            } else if (nameOfMethodToReplace === "setImmediate") {
              clock.timersPromisesModuleMethods.push({
                methodName: "setImmediate",
                original: timersPromisesModule.setImmediate
              });
              timersPromisesModule.setImmediate = (value, options = {}) => new Promise((resolve, reject) => {
                const abort = () => {
                  options.signal.removeEventListener(
                    "abort",
                    abort
                  );
                  clock.abortListenerMap.delete(abort);
                  clock.clearImmediate(handle);
                  reject(options.signal.reason);
                };
                const handle = clock.setImmediate(() => {
                  if (options.signal) {
                    options.signal.removeEventListener(
                      "abort",
                      abort
                    );
                    clock.abortListenerMap.delete(abort);
                  }
                  resolve(value);
                });
                if (options.signal) {
                  if (options.signal.aborted) {
                    abort();
                  } else {
                    options.signal.addEventListener(
                      "abort",
                      abort
                    );
                    clock.abortListenerMap.set(
                      abort,
                      options.signal
                    );
                  }
                }
              });
            } else if (nameOfMethodToReplace === "setInterval") {
              clock.timersPromisesModuleMethods.push({
                methodName: "setInterval",
                original: timersPromisesModule.setInterval
              });
              timersPromisesModule.setInterval = (delay, value, options = {}) => ({
                [Symbol.asyncIterator]: () => {
                  const createResolvable = () => {
                    let resolve, reject;
                    const promise = (
                      /** @type {Promise<unknown> & { resolve: (value: unknown) => void; reject: (reason: unknown) => void }} */
                      new Promise((res, rej) => {
                        resolve = res;
                        reject = rej;
                      })
                    );
                    promise.resolve = resolve;
                    promise.reject = reject;
                    return promise;
                  };
                  let done = false;
                  let hasThrown = false;
                  let returnCall;
                  let nextAvailable = 0;
                  const nextQueue = [];
                  const handle = clock.setInterval(() => {
                    if (nextQueue.length > 0) {
                      nextQueue.shift().resolve();
                    } else {
                      nextAvailable++;
                    }
                  }, delay);
                  const abort = () => {
                    options.signal.removeEventListener(
                      "abort",
                      abort
                    );
                    clock.abortListenerMap.delete(abort);
                    clock.clearInterval(handle);
                    done = true;
                    for (const resolvable of nextQueue) {
                      resolvable.resolve();
                    }
                  };
                  if (options.signal) {
                    if (options.signal.aborted) {
                      done = true;
                    } else {
                      options.signal.addEventListener(
                        "abort",
                        abort
                      );
                      clock.abortListenerMap.set(
                        abort,
                        options.signal
                      );
                    }
                  }
                  return {
                    next: async () => {
                      if (options.signal?.aborted && !hasThrown) {
                        hasThrown = true;
                        throw options.signal.reason;
                      }
                      if (done) {
                        return { done: true, value: void 0 };
                      }
                      if (nextAvailable > 0) {
                        nextAvailable--;
                        return { done: false, value };
                      }
                      const resolvable = createResolvable();
                      nextQueue.push(resolvable);
                      await resolvable;
                      if (returnCall && nextQueue.length === 0) {
                        returnCall.resolve();
                      }
                      if (options.signal?.aborted && !hasThrown) {
                        hasThrown = true;
                        throw options.signal.reason;
                      }
                      if (done) {
                        return { done: true, value: void 0 };
                      }
                      return { done: false, value };
                    },
                    return: async () => {
                      if (done) {
                        return { done: true, value: void 0 };
                      }
                      if (nextQueue.length > 0) {
                        returnCall = createResolvable();
                        await returnCall;
                      }
                      clock.clearInterval(handle);
                      done = true;
                      if (options.signal) {
                        options.signal.removeEventListener(
                          "abort",
                          abort
                        );
                        clock.abortListenerMap.delete(abort);
                      }
                      return { done: true, value: void 0 };
                    }
                  };
                }
              });
            }
          }
        }
        return clock;
      }
      return {
        timers,
        createClock,
        install,
        withGlobal
      };
    }
    var defaultImplementation = withGlobal(globalObject);
    exports2.timers = defaultImplementation.timers;
    exports2.createClock = defaultImplementation.createClock;
    exports2.install = defaultImplementation.install;
    exports2.withGlobal = withGlobal;
  }
});

// lib/sinon/util/fake-timers.js
var require_fake_timers = __commonJS({
  "lib/sinon/util/fake-timers.js"(exports2) {
    "use strict";
    var extend = require_extend();
    var FakeTimers = require_fake_timers_src();
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var FakeTimers__default = /* @__PURE__ */ _interopDefault(FakeTimers);
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { global: globalObject } = commons__default.default;
    function createClock(config, globalCtx) {
      let FakeTimersCtx = FakeTimers__default.default;
      if (globalCtx !== null && typeof globalCtx === "object") {
        FakeTimersCtx = FakeTimers__default.default.withGlobal(globalCtx);
      }
      const clock2 = FakeTimersCtx.install(config);
      clock2.restore = clock2.uninstall;
      return clock2;
    }
    function addIfDefined(obj, globalPropName) {
      const globalProp = globalObject[globalPropName];
      if (typeof globalProp !== "undefined") {
        obj[globalPropName] = globalProp;
      }
    }
    function useFakeTimers(dateOrConfig) {
      const hasArguments = typeof dateOrConfig !== "undefined";
      const argumentIsDateLike = (typeof dateOrConfig === "number" || dateOrConfig instanceof Date) && arguments.length === 1;
      const argumentIsObject = dateOrConfig !== null && typeof dateOrConfig === "object" && arguments.length === 1;
      if (!hasArguments) {
        return createClock({
          now: 0
        });
      }
      if (argumentIsDateLike) {
        return createClock({
          now: dateOrConfig
        });
      }
      if (argumentIsObject) {
        const config = extend.nonEnum({}, dateOrConfig);
        const globalCtx = config.global;
        delete config.global;
        return createClock(config, globalCtx);
      }
      throw new TypeError(
        "useFakeTimers expected epoch or config object. See https://github.com/sinonjs/sinon"
      );
    }
    var clock = {
      create: function(now) {
        return FakeTimers__default.default.createClock(now);
      }
    };
    var timers = {
      setTimeout,
      clearTimeout,
      setInterval,
      clearInterval,
      Date
    };
    addIfDefined(timers, "setImmediate");
    addIfDefined(timers, "clearImmediate");
    addIfDefined(timers, "Temporal");
    addIfDefined(timers, "performance");
    addIfDefined(timers, "requestAnimationFrame");
    addIfDefined(timers, "cancelAnimationFrame");
    addIfDefined(timers, "requestIdleCallback");
    addIfDefined(timers, "cancelIdleCallback");
    addIfDefined(timers, "hrtime");
    addIfDefined(timers, "nextTick");
    addIfDefined(timers, "queueMicrotask");
    exports2.clock = clock;
    exports2.timers = timers;
    exports2.useFakeTimers = useFakeTimers;
  }
});

// lib/sinon/proxy-call-util.js
var require_proxy_call_util = __commonJS({
  "lib/sinon/proxy-call-util.js"(exports2) {
    "use strict";
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { push } = prototypes.array;
    function incrementCallCount(proxy) {
      proxy.called = true;
      proxy.callCount += 1;
      proxy.notCalled = false;
      proxy.calledOnce = proxy.callCount === 1;
      proxy.calledTwice = proxy.callCount === 2;
      proxy.calledThrice = proxy.callCount === 3;
    }
    function createCallProperties(proxy) {
      proxy.firstCall = proxy.getCall(0);
      proxy.secondCall = proxy.getCall(1);
      proxy.thirdCall = proxy.getCall(2);
      proxy.lastCall = proxy.getCall(proxy.callCount - 1);
    }
    function delegateToCalls(proxy, method, matchAny, actual, returnsValues, notCalled, totalCallCount) {
      proxy[method] = function() {
        if (!this.called) {
          if (notCalled) {
            return notCalled.apply(this, arguments);
          }
          return false;
        }
        if (totalCallCount !== void 0 && this.callCount !== totalCallCount) {
          return false;
        }
        let currentCall;
        let matches = 0;
        const returnValues = [];
        for (let i = 0, l = this.callCount; i < l; i += 1) {
          currentCall = this.getCall(i);
          const returnValue = currentCall[actual || method].apply(
            currentCall,
            arguments
          );
          push(returnValues, returnValue);
          if (returnValue) {
            matches += 1;
            if (matchAny) {
              return true;
            }
          }
        }
        if (returnsValues) {
          return returnValues;
        }
        return matches === this.callCount;
      };
    }
    exports2.createCallProperties = createCallProperties;
    exports2.delegateToCalls = delegateToCalls;
    exports2.incrementCallCount = incrementCallCount;
  }
});

// lib/sinon/proxy-invoke.js
var require_proxy_invoke = __commonJS({
  "lib/sinon/proxy-invoke.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var proxyCallUtil = require_proxy_call_util();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { push, forEach, concat } = prototypes.array;
    var ErrorConstructor = Error.prototype.constructor;
    var { bind } = Function.prototype;
    var maxSafeInteger = Number.MAX_SAFE_INTEGER;
    var defaultContext = { callId: 0 };
    function invoke(func, thisValue, args) {
      const matchings = this.matchingFakes(args);
      const ctx = this.sinonContext || defaultContext;
      const currentCallId = ctx.callId;
      ctx.callId = ctx.callId >= maxSafeInteger ? 0 : ctx.callId + 1;
      let exception, returnValue;
      proxyCallUtil.incrementCallCount(this);
      push(this.thisValues, thisValue);
      push(this.args, args);
      push(this.callIds, currentCallId);
      forEach(matchings, function(matching) {
        proxyCallUtil.incrementCallCount(matching);
        push(matching.thisValues, thisValue);
        push(matching.args, args);
        push(matching.callIds, currentCallId);
      });
      proxyCallUtil.createCallProperties(this);
      forEach(matchings, proxyCallUtil.createCallProperties);
      try {
        this.invoking = true;
        const thisCall = this.getCall(this.callCount - 1);
        if (thisCall.calledWithNew()) {
          returnValue = new (bind.apply(
            this.func || func,
            concat([thisValue], args)
          ))();
          if (typeof returnValue !== "object" && typeof returnValue !== "function") {
            returnValue = thisValue;
          }
        } else {
          returnValue = (this.func || func).apply(thisValue, args);
        }
      } catch (e) {
        exception = e;
      } finally {
        delete this.invoking;
      }
      push(this.exceptions, exception);
      push(this.returnValues, returnValue);
      forEach(matchings, function(matching) {
        push(matching.exceptions, exception);
        push(matching.returnValues, returnValue);
      });
      const err = new ErrorConstructor();
      try {
        throw err;
      } catch (e) {
      }
      push(this.errorsWithCallStack, err);
      forEach(matchings, function(matching) {
        push(matching.errorsWithCallStack, err);
      });
      proxyCallUtil.createCallProperties(this);
      forEach(matchings, proxyCallUtil.createCallProperties);
      if (exception !== void 0) {
        throw exception;
      }
      return returnValue;
    }
    module2.exports = invoke;
  }
});

// lib/sinon/proxy-call.js
var require_proxy_call = __commonJS({
  "lib/sinon/proxy-call.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var samsam = require_samsam();
    var util = require_util();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var { prototypes, functionName, valueToString } = commons__default.default;
    var { createMatcher: match, deepEqual } = samsam__default.default;
    var { concat, filter, join, map, reduce, slice } = prototypes.array;
    function throwYieldError(proxy, text, args) {
      let msg = functionName(proxy) + text;
      if (args.length) {
        msg += ` Received [${join(slice(args), ", ")}]`;
      }
      throw new Error(msg);
    }
    var callProto = {
      calledOn: function calledOn(thisValue) {
        if (match.isMatcher(thisValue)) {
          return thisValue.test(this.thisValue);
        }
        return this.thisValue === thisValue;
      },
      calledWith: function calledWith() {
        const self2 = this;
        const calledWithArgs = slice(arguments);
        if (calledWithArgs.length > self2.args.length) {
          return false;
        }
        return reduce(
          calledWithArgs,
          function(prev, arg, i) {
            return prev && deepEqual(self2.args[i], arg);
          },
          true
        );
      },
      calledWithMatch: function calledWithMatch() {
        const self2 = this;
        const calledWithMatchArgs = slice(arguments);
        if (calledWithMatchArgs.length > self2.args.length) {
          return false;
        }
        return reduce(
          calledWithMatchArgs,
          function(prev, expectation, i) {
            const actual = self2.args[i];
            return prev && match(expectation).test(actual);
          },
          true
        );
      },
      calledWithExactly: function calledWithExactly() {
        return arguments.length === this.args.length && this.calledWith.apply(this, arguments);
      },
      notCalledWith: function notCalledWith() {
        return !this.calledWith.apply(this, arguments);
      },
      notCalledWithMatch: function notCalledWithMatch() {
        return !this.calledWithMatch.apply(this, arguments);
      },
      returned: function returned(value) {
        return deepEqual(this.returnValue, value);
      },
      threw: function threw(error) {
        if (typeof error === "undefined" || !this.exception) {
          return Boolean(this.exception);
        }
        return this.exception === error || this.exception.name === error;
      },
      calledWithNew: function calledWithNew() {
        return this.proxy.prototype && this.thisValue instanceof this.proxy;
      },
      calledBefore: function(other) {
        return this.callId < other.callId;
      },
      calledAfter: function(other) {
        return this.callId > other.callId;
      },
      calledImmediatelyBefore: function(other) {
        return this.callId === other.callId - 1;
      },
      calledImmediatelyAfter: function(other) {
        return this.callId === other.callId + 1;
      },
      callArg: function(pos) {
        this.ensureArgIsAFunction(pos);
        return this.args[pos]();
      },
      callArgOn: function(pos, thisValue) {
        this.ensureArgIsAFunction(pos);
        return this.args[pos].apply(thisValue);
      },
      callArgWith: function(pos) {
        return this.callArgOnWith.apply(
          this,
          concat([pos, null], slice(arguments, 1))
        );
      },
      callArgOnWith: function(pos, thisValue) {
        this.ensureArgIsAFunction(pos);
        const args = slice(arguments, 2);
        return this.args[pos].apply(thisValue, args);
      },
      throwArg: function(pos) {
        if (pos >= this.args.length) {
          throw new TypeError(
            `Not enough arguments: ${pos} required but only ${this.args.length} present`
          );
        }
        throw this.args[pos];
      },
      yield: function() {
        return this.yieldOn.apply(this, concat([null], slice(arguments, 0)));
      },
      yieldOn: function(thisValue) {
        const args = slice(this.args);
        const yieldFn = filter(args, function(arg) {
          return typeof arg === "function";
        })[0];
        if (!yieldFn) {
          throwYieldError(
            this.proxy,
            " cannot yield since no callback was passed.",
            args
          );
        }
        return yieldFn.apply(thisValue, slice(arguments, 1));
      },
      yieldTo: function(prop) {
        return this.yieldToOn.apply(
          this,
          concat([prop, null], slice(arguments, 1))
        );
      },
      yieldToOn: function(prop, thisValue) {
        const args = slice(this.args);
        const yieldArg = filter(args, function(arg) {
          return arg && typeof arg[prop] === "function";
        })[0];
        const yieldFn = yieldArg && yieldArg[prop];
        if (!yieldFn) {
          throwYieldError(
            this.proxy,
            ` cannot yield to '${valueToString(
              prop
            )}' since no callback was passed.`,
            args
          );
        }
        return yieldFn.apply(thisValue, slice(arguments, 2));
      },
      toString: function() {
        if (!this.args) {
          return ":(";
        }
        let callStr = this.proxy ? `${String(this.proxy)}(` : "";
        const formattedArgs = map(this.args, function(arg) {
          return util.inspect(arg);
        });
        callStr = `${callStr + join(formattedArgs, ", ")})`;
        if (typeof this.returnValue !== "undefined") {
          callStr += ` => ${util.inspect(this.returnValue)}`;
        }
        if (this.exception) {
          callStr += ` !${this.exception.name}`;
          if (this.exception.message) {
            callStr += `(${this.exception.message})`;
          }
        }
        if (this.stack) {
          callStr += (this.stack.split("\n")[3] || "unknown").replace(
            /^\s*(?:at\s+|@)?/,
            " at "
          );
        }
        return callStr;
      },
      ensureArgIsAFunction: function(pos) {
        if (typeof this.args[pos] !== "function") {
          throw new TypeError(
            `Expected argument at position ${pos} to be a Function, but was ${typeof this.args[pos]}`
          );
        }
      }
    };
    Object.defineProperty(callProto, "stack", {
      enumerable: true,
      configurable: true,
      get: function() {
        return this.errorWithCallStack && this.errorWithCallStack.stack || "";
      }
    });
    callProto.invokeCallback = callProto.yield;
    function createProxyCall(proxy, thisValue, args, returnValue, exception, id, errorWithCallStack) {
      if (typeof id !== "number") {
        throw new TypeError("Call id is not a number");
      }
      let firstArg, lastArg;
      if (args.length > 0) {
        firstArg = args[0];
        lastArg = args[args.length - 1];
      }
      const proxyCall = Object.create(callProto);
      const callback = lastArg && typeof lastArg === "function" ? lastArg : void 0;
      proxyCall.proxy = proxy;
      proxyCall.thisValue = thisValue;
      proxyCall.args = args;
      proxyCall.firstArg = firstArg;
      proxyCall.lastArg = lastArg;
      proxyCall.callback = callback;
      proxyCall.returnValue = returnValue;
      proxyCall.exception = exception;
      proxyCall.callId = id;
      proxyCall.errorWithCallStack = errorWithCallStack;
      return proxyCall;
    }
    createProxyCall.toString = callProto.toString;
    module2.exports = createProxyCall;
  }
});

// lib/sinon/util/core/is-property-configurable.js
var require_is_property_configurable = __commonJS({
  "lib/sinon/util/core/is-property-configurable.js"(exports2, module2) {
    "use strict";
    var getPropertyDescriptor = require_get_property_descriptor();
    function isPropertyConfigurable(obj, propName) {
      const propertyDescriptor = getPropertyDescriptor(obj, propName);
      return propertyDescriptor ? propertyDescriptor.configurable : true;
    }
    module2.exports = isPropertyConfigurable;
  }
});

// lib/sinon/default-behaviors.js
var require_default_behaviors = __commonJS({
  "lib/sinon/default-behaviors.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var isPropertyConfigurable = require_is_property_configurable();
    var exportAsyncBehaviors = require_export_async_behaviors();
    var extend = require_extend();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { slice } = prototypes.array;
    var useLeftMostCallback = -1;
    var useRightMostCallback = -2;
    function throwsException(fake, error, message) {
      if (typeof error === "function") {
        fake.exceptionCreator = error;
      } else if (typeof error === "string") {
        fake.exceptionCreator = function() {
          const newException = new Error(
            message || `Sinon-provided ${error}`
          );
          newException.name = error;
          return newException;
        };
      } else if (!error) {
        fake.exceptionCreator = function() {
          return new Error("Error");
        };
      } else {
        fake.exception = error;
      }
    }
    var defaultBehaviors = {
      callsFake: function callsFake(fake, fn) {
        fake.fakeFn = fn;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.callsThrough = false;
      },
      callsArg: function callsArg(fake, index) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.callArgAt = index;
        fake.callbackArguments = [];
        fake.callbackContext = void 0;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.callsThrough = false;
      },
      callsArgOn: function callsArgOn(fake, index, context) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.callArgAt = index;
        fake.callbackArguments = [];
        fake.callbackContext = context;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.callsThrough = false;
      },
      callsArgWith: function callsArgWith(fake, index) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.callArgAt = index;
        fake.callbackArguments = slice(arguments, 2);
        fake.callbackContext = void 0;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.callsThrough = false;
      },
      callsArgOnWith: function callsArgWith(fake, index, context) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.callArgAt = index;
        fake.callbackArguments = slice(arguments, 3);
        fake.callbackContext = context;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.callsThrough = false;
      },
      yields: function(fake) {
        fake.callArgAt = useLeftMostCallback;
        fake.callbackArguments = slice(arguments, 1);
        fake.callbackContext = void 0;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.fakeFn = void 0;
        fake.callsThrough = false;
      },
      yieldsRight: function(fake) {
        fake.callArgAt = useRightMostCallback;
        fake.callbackArguments = slice(arguments, 1);
        fake.callbackContext = void 0;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.callsThrough = false;
        fake.fakeFn = void 0;
      },
      yieldsOn: function(fake, context) {
        fake.callArgAt = useLeftMostCallback;
        fake.callbackArguments = slice(arguments, 2);
        fake.callbackContext = context;
        fake.callArgProp = void 0;
        fake.callbackAsync = false;
        fake.callsThrough = false;
        fake.fakeFn = void 0;
      },
      yieldsTo: function(fake, prop) {
        fake.callArgAt = useLeftMostCallback;
        fake.callbackArguments = slice(arguments, 2);
        fake.callbackContext = void 0;
        fake.callArgProp = prop;
        fake.callbackAsync = false;
        fake.callsThrough = false;
        fake.fakeFn = void 0;
      },
      yieldsToOn: function(fake, prop, context) {
        fake.callArgAt = useLeftMostCallback;
        fake.callbackArguments = slice(arguments, 3);
        fake.callbackContext = context;
        fake.callArgProp = prop;
        fake.callbackAsync = false;
        fake.fakeFn = void 0;
      },
      throws: throwsException,
      throwsException,
      returns: function returns(fake, value) {
        fake.callsThrough = false;
        fake.returnValue = value;
        fake.returnArgAt = void 0;
        fake.resolve = false;
        fake.reject = false;
        fake.returnValueDefined = true;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.fakeFn = void 0;
      },
      returnsArg: function returnsArg(fake, index) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.callsThrough = false;
        fake.returnArgAt = index;
      },
      throwsArg: function throwsArg(fake, index) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.callsThrough = false;
        fake.throwArgAt = index;
      },
      returnsThis: function returnsThis(fake) {
        fake.returnThis = true;
        fake.callsThrough = false;
      },
      resolves: function resolves(fake, value) {
        fake.returnValue = value;
        fake.resolve = true;
        fake.resolveThis = false;
        fake.reject = false;
        fake.returnValueDefined = true;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.fakeFn = void 0;
        fake.callsThrough = false;
      },
      resolvesArg: function resolvesArg(fake, index) {
        if (typeof index !== "number") {
          throw new TypeError("argument index is not number");
        }
        fake.resolveArgAt = index;
        fake.returnValue = void 0;
        fake.resolve = true;
        fake.resolveThis = false;
        fake.reject = false;
        fake.returnValueDefined = false;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.fakeFn = void 0;
        fake.callsThrough = false;
      },
      rejects: function rejects(fake, error, message) {
        let reason;
        if (typeof error === "string") {
          reason = new Error(message || "");
          reason.name = error;
        } else if (!error) {
          reason = new Error("Error");
        } else {
          reason = error;
        }
        fake.returnValue = reason;
        fake.resolve = false;
        fake.resolveThis = false;
        fake.reject = true;
        fake.returnValueDefined = true;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.fakeFn = void 0;
        fake.callsThrough = false;
        return fake;
      },
      resolvesThis: function resolvesThis(fake) {
        fake.returnValue = void 0;
        fake.resolve = false;
        fake.resolveThis = true;
        fake.reject = false;
        fake.returnValueDefined = false;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.fakeFn = void 0;
        fake.callsThrough = false;
      },
      callThrough: function callThrough(fake) {
        fake.callsThrough = true;
        fake.callArgAt = void 0;
        fake.callsThroughWithNew = false;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.fakeFn = void 0;
        fake.reject = false;
        fake.resolve = false;
        fake.resolveArgAt = void 0;
        fake.resolveThis = false;
        fake.returnArgAt = void 0;
        fake.returnThis = false;
        fake.returnValue = void 0;
        fake.throwArgAt = void 0;
        fake.callArgProp = void 0;
        fake.callbackArguments = [];
        fake.callbackContext = void 0;
        fake.callbackAsync = false;
        fake.returnValueDefined = false;
      },
      callThroughWithNew: function callThroughWithNew(fake) {
        fake.callsThroughWithNew = true;
        fake.callArgAt = void 0;
        fake.exception = void 0;
        fake.exceptionCreator = void 0;
        fake.throwArgAt = void 0;
        fake.callArgProp = void 0;
        fake.callbackArguments = [];
        fake.callbackContext = void 0;
        fake.callbackAsync = false;
      },
      get: function get(fake, getterFunction) {
        const rootStub = fake.stub || fake;
        Object.defineProperty(rootStub.rootObj, rootStub.propName, {
          get: getterFunction,
          configurable: isPropertyConfigurable(
            rootStub.rootObj,
            rootStub.propName
          )
        });
        return fake;
      },
      set: function set(fake, setterFunction) {
        const rootStub = fake.stub || fake;
        Object.defineProperty(
          rootStub.rootObj,
          rootStub.propName,
          // eslint-disable-next-line accessor-pairs
          {
            set: setterFunction,
            configurable: isPropertyConfigurable(
              rootStub.rootObj,
              rootStub.propName
            )
          }
        );
        return fake;
      },
      value: function value(fake, newVal) {
        const rootStub = fake.stub || fake;
        Object.defineProperty(rootStub.rootObj, rootStub.propName, {
          value: newVal,
          enumerable: true,
          writable: true,
          configurable: rootStub.shadowsPropOnPrototype || isPropertyConfigurable(rootStub.rootObj, rootStub.propName)
        });
        return fake;
      }
    };
    var asyncBehaviors = exportAsyncBehaviors(defaultBehaviors);
    var behaviors = extend({}, defaultBehaviors, asyncBehaviors);
    module2.exports = behaviors;
  }
});

// lib/sinon/util/core/function-to-string.js
var require_function_to_string = __commonJS({
  "lib/sinon/util/core/function-to-string.js"(exports2, module2) {
    "use strict";
    function functionToString() {
      let i, prop, thisValue;
      if (this.getCall && this.callCount) {
        i = this.callCount;
        while (i--) {
          thisValue = this.getCall(i).thisValue;
          for (prop in thisValue) {
            try {
              if (thisValue[prop] === this) {
                return prop;
              }
            } catch (e) {
            }
          }
        }
      }
      return this.displayName || "sinon fake";
    }
    module2.exports = functionToString;
  }
});

// lib/sinon/colorizer.js
var require_colorizer = __commonJS({
  "lib/sinon/colorizer.js"(exports2, module2) {
    "use strict";
    function getSupportsColor() {
      if (typeof process === "undefined" || typeof process.stdout === "undefined") {
        return { stdout: false };
      }
      return { stdout: Boolean(process.stdout.isTTY) };
    }
    var Colorizer = class {
      /**
       * @param {object} [supportsColorModule] The supports-color module
       */
      constructor(supportsColorModule = getSupportsColor()) {
        this.supportsColor = supportsColorModule;
      }
      /**
       * Colorizes a string with the given color code.
       *
       * @param {string} str The string to colorize
       * @param {number} color The color code
       * @returns {string} The colorized string
       * @private
       */
      colorize(str, color) {
        if (this.supportsColor.stdout === false) {
          return str;
        }
        return `\x1B[${color}m${str}\x1B[0m`;
      }
      /**
       * Colorizes a string red.
       *
       * @param {string} str The string to colorize
       * @returns {string} The colorized string
       */
      red(str) {
        return this.colorize(str, 31);
      }
      /**
       * Colorizes a string green.
       *
       * @param {string} str The string to colorize
       * @returns {string} The colorized string
       */
      green(str) {
        return this.colorize(str, 32);
      }
      /**
       * Colorizes a string cyan.
       *
       * @param {string} str The string to colorize
       * @returns {string} The colorized string
       */
      cyan(str) {
        return this.colorize(str, 96);
      }
      /**
       * Colorizes a string white.
       *
       * @param {string} str The string to colorize
       * @returns {string} The colorized string
       */
      white(str) {
        return this.colorize(str, 39);
      }
      /**
       * Colorizes a string bold.
       *
       * @param {string} str The string to colorize
       * @returns {string} The colorized string
       */
      bold(str) {
        return this.colorize(str, 1);
      }
    };
    module2.exports = Colorizer;
  }
});

// node_modules/diff/libcjs/diff/base.js
var require_base = __commonJS({
  "node_modules/diff/libcjs/diff/base.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var Diff = class {
      diff(oldStr, newStr, options = {}) {
        let callback;
        if (typeof options === "function") {
          callback = options;
          options = {};
        } else if ("callback" in options) {
          callback = options.callback;
        }
        const oldString = this.castInput(oldStr, options);
        const newString = this.castInput(newStr, options);
        const oldTokens = this.removeEmpty(this.tokenize(oldString, options));
        const newTokens = this.removeEmpty(this.tokenize(newString, options));
        return this.diffWithOptionsObj(oldTokens, newTokens, options, callback);
      }
      diffWithOptionsObj(oldTokens, newTokens, options, callback) {
        var _a;
        const done = (value) => {
          value = this.postProcess(value, options);
          if (callback) {
            setTimeout(function() {
              callback(value);
            }, 0);
            return void 0;
          } else {
            return value;
          }
        };
        const newLen = newTokens.length, oldLen = oldTokens.length;
        let editLength = 1;
        let maxEditLength = newLen + oldLen;
        if (options.maxEditLength != null) {
          maxEditLength = Math.min(maxEditLength, options.maxEditLength);
        }
        const maxExecutionTime = (_a = options.timeout) !== null && _a !== void 0 ? _a : Infinity;
        const abortAfterTimestamp = Date.now() + maxExecutionTime;
        const bestPath = [{ oldPos: -1, lastComponent: void 0 }];
        let newPos = this.extractCommon(bestPath[0], newTokens, oldTokens, 0, options);
        if (bestPath[0].oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
          return done(this.buildValues(bestPath[0].lastComponent, newTokens, oldTokens));
        }
        let minDiagonalToConsider = -Infinity, maxDiagonalToConsider = Infinity;
        const execEditLength = () => {
          for (let diagonalPath = Math.max(minDiagonalToConsider, -editLength); diagonalPath <= Math.min(maxDiagonalToConsider, editLength); diagonalPath += 2) {
            let basePath;
            const removePath = bestPath[diagonalPath - 1], addPath = bestPath[diagonalPath + 1];
            if (removePath) {
              bestPath[diagonalPath - 1] = void 0;
            }
            let canAdd = false;
            if (addPath) {
              const addPathNewPos = addPath.oldPos - diagonalPath;
              canAdd = addPath && 0 <= addPathNewPos && addPathNewPos < newLen;
            }
            const canRemove = removePath && removePath.oldPos + 1 < oldLen;
            if (!canAdd && !canRemove) {
              bestPath[diagonalPath] = void 0;
              continue;
            }
            if (!canRemove || canAdd && removePath.oldPos < addPath.oldPos) {
              basePath = this.addToPath(addPath, true, false, 0, options);
            } else {
              basePath = this.addToPath(removePath, false, true, 1, options);
            }
            newPos = this.extractCommon(basePath, newTokens, oldTokens, diagonalPath, options);
            if (basePath.oldPos + 1 >= oldLen && newPos + 1 >= newLen) {
              return done(this.buildValues(basePath.lastComponent, newTokens, oldTokens)) || true;
            } else {
              bestPath[diagonalPath] = basePath;
              if (basePath.oldPos + 1 >= oldLen) {
                maxDiagonalToConsider = Math.min(maxDiagonalToConsider, diagonalPath - 1);
              }
              if (newPos + 1 >= newLen) {
                minDiagonalToConsider = Math.max(minDiagonalToConsider, diagonalPath + 1);
              }
            }
          }
          editLength++;
        };
        if (callback) {
          (function exec() {
            setTimeout(function() {
              if (editLength > maxEditLength || Date.now() > abortAfterTimestamp) {
                return callback(void 0);
              }
              if (!execEditLength()) {
                exec();
              }
            }, 0);
          })();
        } else {
          while (editLength <= maxEditLength && Date.now() <= abortAfterTimestamp) {
            const ret = execEditLength();
            if (ret) {
              return ret;
            }
          }
        }
      }
      addToPath(path, added, removed, oldPosInc, options) {
        const last = path.lastComponent;
        if (last && !options.oneChangePerToken && last.added === added && last.removed === removed) {
          return {
            oldPos: path.oldPos + oldPosInc,
            lastComponent: { count: last.count + 1, added, removed, previousComponent: last.previousComponent }
          };
        } else {
          return {
            oldPos: path.oldPos + oldPosInc,
            lastComponent: { count: 1, added, removed, previousComponent: last }
          };
        }
      }
      extractCommon(basePath, newTokens, oldTokens, diagonalPath, options) {
        const newLen = newTokens.length, oldLen = oldTokens.length;
        let oldPos = basePath.oldPos, newPos = oldPos - diagonalPath, commonCount = 0;
        while (newPos + 1 < newLen && oldPos + 1 < oldLen && this.equals(oldTokens[oldPos + 1], newTokens[newPos + 1], options)) {
          newPos++;
          oldPos++;
          commonCount++;
          if (options.oneChangePerToken) {
            basePath.lastComponent = { count: 1, previousComponent: basePath.lastComponent, added: false, removed: false };
          }
        }
        if (commonCount && !options.oneChangePerToken) {
          basePath.lastComponent = { count: commonCount, previousComponent: basePath.lastComponent, added: false, removed: false };
        }
        basePath.oldPos = oldPos;
        return newPos;
      }
      equals(left, right, options) {
        if (options.comparator) {
          return options.comparator(left, right);
        } else {
          return left === right || !!options.ignoreCase && left.toLowerCase() === right.toLowerCase();
        }
      }
      removeEmpty(array) {
        const ret = [];
        for (let i = 0; i < array.length; i++) {
          if (array[i]) {
            ret.push(array[i]);
          }
        }
        return ret;
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      castInput(value, options) {
        return value;
      }
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      tokenize(value, options) {
        return Array.from(value);
      }
      join(chars) {
        return chars.join("");
      }
      postProcess(changeObjects, options) {
        return changeObjects;
      }
      get useLongestToken() {
        return false;
      }
      buildValues(lastComponent, newTokens, oldTokens) {
        const components = [];
        let nextComponent;
        while (lastComponent) {
          components.push(lastComponent);
          nextComponent = lastComponent.previousComponent;
          delete lastComponent.previousComponent;
          lastComponent = nextComponent;
        }
        components.reverse();
        const componentLen = components.length;
        let componentPos = 0, newPos = 0, oldPos = 0;
        for (; componentPos < componentLen; componentPos++) {
          const component = components[componentPos];
          if (!component.removed) {
            if (!component.added && this.useLongestToken) {
              let value = newTokens.slice(newPos, newPos + component.count);
              value = value.map(function(value2, i) {
                const oldValue = oldTokens[oldPos + i];
                return oldValue.length > value2.length ? oldValue : value2;
              });
              component.value = this.join(value);
            } else {
              component.value = this.join(newTokens.slice(newPos, newPos + component.count));
            }
            newPos += component.count;
            if (!component.added) {
              oldPos += component.count;
            }
          } else {
            component.value = this.join(oldTokens.slice(oldPos, oldPos + component.count));
            oldPos += component.count;
          }
        }
        return components;
      }
    };
    exports2.default = Diff;
  }
});

// node_modules/diff/libcjs/diff/character.js
var require_character = __commonJS({
  "node_modules/diff/libcjs/diff/character.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.characterDiff = void 0;
    exports2.diffChars = diffChars;
    var base_js_1 = __importDefault(require_base());
    var CharacterDiff = class extends base_js_1.default {
    };
    exports2.characterDiff = new CharacterDiff();
    function diffChars(oldStr, newStr, options) {
      return exports2.characterDiff.diff(oldStr, newStr, options);
    }
  }
});

// node_modules/diff/libcjs/util/string.js
var require_string2 = __commonJS({
  "node_modules/diff/libcjs/util/string.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.longestCommonPrefix = longestCommonPrefix;
    exports2.longestCommonSuffix = longestCommonSuffix;
    exports2.replacePrefix = replacePrefix;
    exports2.replaceSuffix = replaceSuffix;
    exports2.removePrefix = removePrefix;
    exports2.removeSuffix = removeSuffix;
    exports2.maximumOverlap = maximumOverlap;
    exports2.hasOnlyWinLineEndings = hasOnlyWinLineEndings;
    exports2.hasOnlyUnixLineEndings = hasOnlyUnixLineEndings;
    exports2.segment = segment;
    exports2.trailingWs = trailingWs;
    exports2.leadingWs = leadingWs;
    exports2.leadingAndTrailingWs = leadingAndTrailingWs;
    function longestCommonPrefix(str1, str2) {
      let i;
      for (i = 0; i < str1.length && i < str2.length; i++) {
        if (str1[i] != str2[i]) {
          return str1.slice(0, i);
        }
      }
      return str1.slice(0, i);
    }
    function longestCommonSuffix(str1, str2) {
      let i;
      if (!str1 || !str2 || str1[str1.length - 1] != str2[str2.length - 1]) {
        return "";
      }
      for (i = 0; i < str1.length && i < str2.length; i++) {
        if (str1[str1.length - (i + 1)] != str2[str2.length - (i + 1)]) {
          return str1.slice(-i);
        }
      }
      return str1.slice(-i);
    }
    function replacePrefix(string, oldPrefix, newPrefix) {
      if (string.slice(0, oldPrefix.length) != oldPrefix) {
        throw Error(`string ${JSON.stringify(string)} doesn't start with prefix ${JSON.stringify(oldPrefix)}; this is a bug`);
      }
      return newPrefix + string.slice(oldPrefix.length);
    }
    function replaceSuffix(string, oldSuffix, newSuffix) {
      if (!oldSuffix) {
        return string + newSuffix;
      }
      if (string.slice(-oldSuffix.length) != oldSuffix) {
        throw Error(`string ${JSON.stringify(string)} doesn't end with suffix ${JSON.stringify(oldSuffix)}; this is a bug`);
      }
      return string.slice(0, -oldSuffix.length) + newSuffix;
    }
    function removePrefix(string, oldPrefix) {
      return replacePrefix(string, oldPrefix, "");
    }
    function removeSuffix(string, oldSuffix) {
      return replaceSuffix(string, oldSuffix, "");
    }
    function maximumOverlap(string1, string2) {
      return string2.slice(0, overlapCount(string1, string2));
    }
    function overlapCount(a, b) {
      let startA = 0;
      if (a.length > b.length) {
        startA = a.length - b.length;
      }
      let endB = b.length;
      if (a.length < b.length) {
        endB = a.length;
      }
      const map = Array(endB);
      let k = 0;
      map[0] = 0;
      for (let j = 1; j < endB; j++) {
        if (b[j] == b[k]) {
          map[j] = map[k];
        } else {
          map[j] = k;
        }
        while (k > 0 && b[j] != b[k]) {
          k = map[k];
        }
        if (b[j] == b[k]) {
          k++;
        }
      }
      k = 0;
      for (let i = startA; i < a.length; i++) {
        while (k > 0 && a[i] != b[k]) {
          k = map[k];
        }
        if (a[i] == b[k]) {
          k++;
        }
      }
      return k;
    }
    function hasOnlyWinLineEndings(string) {
      return string.includes("\r\n") && !string.startsWith("\n") && !string.match(/[^\r]\n/);
    }
    function hasOnlyUnixLineEndings(string) {
      return !string.includes("\r\n") && string.includes("\n");
    }
    function segment(string, segmenter) {
      const parts = [];
      for (const segmentObj of Array.from(segmenter.segment(string))) {
        const segment2 = segmentObj.segment;
        if (parts.length && /\s/.test(parts[parts.length - 1]) && /\s/.test(segment2)) {
          parts[parts.length - 1] += segment2;
        } else {
          parts.push(segment2);
        }
      }
      return parts;
    }
    function trailingWs(string, segmenter) {
      if (segmenter) {
        return leadingAndTrailingWs(string, segmenter)[1];
      }
      let i;
      for (i = string.length - 1; i >= 0; i--) {
        if (!string[i].match(/\s/)) {
          break;
        }
      }
      return string.substring(i + 1);
    }
    function leadingWs(string, segmenter) {
      if (segmenter) {
        return leadingAndTrailingWs(string, segmenter)[0];
      }
      const match = string.match(/^\s*/);
      return match ? match[0] : "";
    }
    function leadingAndTrailingWs(string, segmenter) {
      if (!segmenter) {
        return [leadingWs(string), trailingWs(string)];
      }
      if (segmenter.resolvedOptions().granularity != "word") {
        throw new Error('The segmenter passed must have a granularity of "word"');
      }
      const segments = segment(string, segmenter);
      const firstSeg = segments[0];
      const lastSeg = segments[segments.length - 1];
      const head = /\s/.test(firstSeg) ? firstSeg : "";
      const tail = /\s/.test(lastSeg) ? lastSeg : "";
      return [head, tail];
    }
  }
});

// node_modules/diff/libcjs/diff/word.js
var require_word = __commonJS({
  "node_modules/diff/libcjs/diff/word.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.wordsWithSpaceDiff = exports2.wordDiff = void 0;
    exports2.diffWords = diffWords;
    exports2.diffWordsWithSpace = diffWordsWithSpace;
    var base_js_1 = __importDefault(require_base());
    var string_js_1 = require_string2();
    var extendedWordChars = "a-zA-Z0-9_\\u{AD}\\u{C0}-\\u{D6}\\u{D8}-\\u{F6}\\u{F8}-\\u{2C6}\\u{2C8}-\\u{2D7}\\u{2DE}-\\u{2FF}\\u{1E00}-\\u{1EFF}";
    var tokenizeIncludingWhitespace = new RegExp(`[${extendedWordChars}]+|\\s+|[^${extendedWordChars}]`, "ug");
    var WordDiff = class extends base_js_1.default {
      equals(left, right, options) {
        if (options.ignoreCase) {
          left = left.toLowerCase();
          right = right.toLowerCase();
        }
        return left.trim() === right.trim();
      }
      tokenize(value, options = {}) {
        let parts;
        if (options.intlSegmenter) {
          const segmenter = options.intlSegmenter;
          if (segmenter.resolvedOptions().granularity != "word") {
            throw new Error('The segmenter passed must have a granularity of "word"');
          }
          parts = (0, string_js_1.segment)(value, segmenter);
        } else {
          parts = value.match(tokenizeIncludingWhitespace) || [];
        }
        const tokens = [];
        let prevPart = null;
        parts.forEach((part) => {
          if (/\s/.test(part)) {
            if (prevPart == null) {
              tokens.push(part);
            } else {
              tokens.push(tokens.pop() + part);
            }
          } else if (prevPart != null && /\s/.test(prevPart)) {
            if (tokens[tokens.length - 1] == prevPart) {
              tokens.push(tokens.pop() + part);
            } else {
              tokens.push(prevPart + part);
            }
          } else {
            tokens.push(part);
          }
          prevPart = part;
        });
        return tokens;
      }
      join(tokens) {
        return tokens.map((token, i) => {
          if (i == 0) {
            return token;
          } else {
            return token.replace(/^\s+/, "");
          }
        }).join("");
      }
      postProcess(changes, options) {
        if (!changes || options.oneChangePerToken) {
          return changes;
        }
        let lastKeep = null;
        let insertion = null;
        let deletion = null;
        changes.forEach((change) => {
          if (change.added) {
            insertion = change;
          } else if (change.removed) {
            deletion = change;
          } else {
            if (insertion || deletion) {
              dedupeWhitespaceInChangeObjects(lastKeep, deletion, insertion, change, options.intlSegmenter);
            }
            lastKeep = change;
            insertion = null;
            deletion = null;
          }
        });
        if (insertion || deletion) {
          dedupeWhitespaceInChangeObjects(lastKeep, deletion, insertion, null, options.intlSegmenter);
        }
        return changes;
      }
    };
    exports2.wordDiff = new WordDiff();
    function diffWords(oldStr, newStr, options) {
      if ((options === null || options === void 0 ? void 0 : options.ignoreWhitespace) != null && !options.ignoreWhitespace) {
        return diffWordsWithSpace(oldStr, newStr, options);
      }
      return exports2.wordDiff.diff(oldStr, newStr, options);
    }
    function dedupeWhitespaceInChangeObjects(startKeep, deletion, insertion, endKeep, segmenter) {
      if (deletion && insertion) {
        const [oldWsPrefix, oldWsSuffix] = (0, string_js_1.leadingAndTrailingWs)(deletion.value, segmenter);
        const [newWsPrefix, newWsSuffix] = (0, string_js_1.leadingAndTrailingWs)(insertion.value, segmenter);
        if (startKeep) {
          const commonWsPrefix = (0, string_js_1.longestCommonPrefix)(oldWsPrefix, newWsPrefix);
          startKeep.value = (0, string_js_1.replaceSuffix)(startKeep.value, newWsPrefix, commonWsPrefix);
          deletion.value = (0, string_js_1.removePrefix)(deletion.value, commonWsPrefix);
          insertion.value = (0, string_js_1.removePrefix)(insertion.value, commonWsPrefix);
        }
        if (endKeep) {
          const commonWsSuffix = (0, string_js_1.longestCommonSuffix)(oldWsSuffix, newWsSuffix);
          endKeep.value = (0, string_js_1.replacePrefix)(endKeep.value, newWsSuffix, commonWsSuffix);
          deletion.value = (0, string_js_1.removeSuffix)(deletion.value, commonWsSuffix);
          insertion.value = (0, string_js_1.removeSuffix)(insertion.value, commonWsSuffix);
        }
      } else if (insertion) {
        if (startKeep) {
          const ws = (0, string_js_1.leadingWs)(insertion.value, segmenter);
          insertion.value = insertion.value.substring(ws.length);
        }
        if (endKeep) {
          const ws = (0, string_js_1.leadingWs)(endKeep.value, segmenter);
          endKeep.value = endKeep.value.substring(ws.length);
        }
      } else if (startKeep && endKeep) {
        const newWsFull = (0, string_js_1.leadingWs)(endKeep.value, segmenter), [delWsStart, delWsEnd] = (0, string_js_1.leadingAndTrailingWs)(deletion.value, segmenter);
        const newWsStart = (0, string_js_1.longestCommonPrefix)(newWsFull, delWsStart);
        deletion.value = (0, string_js_1.removePrefix)(deletion.value, newWsStart);
        const newWsEnd = (0, string_js_1.longestCommonSuffix)((0, string_js_1.removePrefix)(newWsFull, newWsStart), delWsEnd);
        deletion.value = (0, string_js_1.removeSuffix)(deletion.value, newWsEnd);
        endKeep.value = (0, string_js_1.replacePrefix)(endKeep.value, newWsFull, newWsEnd);
        startKeep.value = (0, string_js_1.replaceSuffix)(startKeep.value, newWsFull, newWsFull.slice(0, newWsFull.length - newWsEnd.length));
      } else if (endKeep) {
        const endKeepWsPrefix = (0, string_js_1.leadingWs)(endKeep.value, segmenter);
        const deletionWsSuffix = (0, string_js_1.trailingWs)(deletion.value, segmenter);
        const overlap = (0, string_js_1.maximumOverlap)(deletionWsSuffix, endKeepWsPrefix);
        deletion.value = (0, string_js_1.removeSuffix)(deletion.value, overlap);
      } else if (startKeep) {
        const startKeepWsSuffix = (0, string_js_1.trailingWs)(startKeep.value, segmenter);
        const deletionWsPrefix = (0, string_js_1.leadingWs)(deletion.value, segmenter);
        const overlap = (0, string_js_1.maximumOverlap)(startKeepWsSuffix, deletionWsPrefix);
        deletion.value = (0, string_js_1.removePrefix)(deletion.value, overlap);
      }
    }
    var WordsWithSpaceDiff = class extends base_js_1.default {
      tokenize(value) {
        const regex = new RegExp(`(\\r?\\n)|[${extendedWordChars}]+|[^\\S\\n\\r]+|[^${extendedWordChars}]`, "ug");
        return value.match(regex) || [];
      }
    };
    exports2.wordsWithSpaceDiff = new WordsWithSpaceDiff();
    function diffWordsWithSpace(oldStr, newStr, options) {
      return exports2.wordsWithSpaceDiff.diff(oldStr, newStr, options);
    }
  }
});

// node_modules/diff/libcjs/util/params.js
var require_params = __commonJS({
  "node_modules/diff/libcjs/util/params.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.generateOptions = generateOptions;
    function generateOptions(options, defaults) {
      if (typeof options === "function") {
        defaults.callback = options;
      } else if (options) {
        for (const name in options) {
          if (Object.prototype.hasOwnProperty.call(options, name)) {
            defaults[name] = options[name];
          }
        }
      }
      return defaults;
    }
  }
});

// node_modules/diff/libcjs/diff/line.js
var require_line = __commonJS({
  "node_modules/diff/libcjs/diff/line.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.lineDiff = void 0;
    exports2.diffLines = diffLines;
    exports2.diffTrimmedLines = diffTrimmedLines;
    exports2.tokenize = tokenize;
    var base_js_1 = __importDefault(require_base());
    var params_js_1 = require_params();
    var LineDiff = class extends base_js_1.default {
      constructor() {
        super(...arguments);
        this.tokenize = tokenize;
      }
      equals(left, right, options) {
        if (options.ignoreWhitespace) {
          if (!options.newlineIsToken || !left.includes("\n")) {
            left = left.trim();
          }
          if (!options.newlineIsToken || !right.includes("\n")) {
            right = right.trim();
          }
        } else if (options.ignoreNewlineAtEof && !options.newlineIsToken) {
          if (left.endsWith("\n")) {
            left = left.slice(0, -1);
          }
          if (right.endsWith("\n")) {
            right = right.slice(0, -1);
          }
        }
        return super.equals(left, right, options);
      }
    };
    exports2.lineDiff = new LineDiff();
    function diffLines(oldStr, newStr, options) {
      return exports2.lineDiff.diff(oldStr, newStr, options);
    }
    function diffTrimmedLines(oldStr, newStr, options) {
      options = (0, params_js_1.generateOptions)(options, { ignoreWhitespace: true });
      return exports2.lineDiff.diff(oldStr, newStr, options);
    }
    function tokenize(value, options) {
      if (options.stripTrailingCr) {
        value = value.replace(/\r\n/g, "\n");
      }
      const retLines = [], linesAndNewlines = value.split(/(\n|\r\n)/);
      if (!linesAndNewlines[linesAndNewlines.length - 1]) {
        linesAndNewlines.pop();
      }
      for (let i = 0; i < linesAndNewlines.length; i++) {
        const line = linesAndNewlines[i];
        if (i % 2 && !options.newlineIsToken) {
          retLines[retLines.length - 1] += line;
        } else {
          retLines.push(line);
        }
      }
      return retLines;
    }
  }
});

// node_modules/diff/libcjs/diff/sentence.js
var require_sentence = __commonJS({
  "node_modules/diff/libcjs/diff/sentence.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.sentenceDiff = void 0;
    exports2.diffSentences = diffSentences;
    var base_js_1 = __importDefault(require_base());
    function isSentenceEndPunct(char) {
      return char == "." || char == "!" || char == "?";
    }
    var SentenceDiff = class extends base_js_1.default {
      tokenize(value) {
        var _a;
        const result = [];
        let tokenStartI = 0;
        for (let i = 0; i < value.length; i++) {
          if (i == value.length - 1) {
            result.push(value.slice(tokenStartI));
            break;
          }
          if (isSentenceEndPunct(value[i]) && value[i + 1].match(/\s/)) {
            result.push(value.slice(tokenStartI, i + 1));
            i = tokenStartI = i + 1;
            while ((_a = value[i + 1]) === null || _a === void 0 ? void 0 : _a.match(/\s/)) {
              i++;
            }
            result.push(value.slice(tokenStartI, i + 1));
            tokenStartI = i + 1;
          }
        }
        return result;
      }
    };
    exports2.sentenceDiff = new SentenceDiff();
    function diffSentences(oldStr, newStr, options) {
      return exports2.sentenceDiff.diff(oldStr, newStr, options);
    }
  }
});

// node_modules/diff/libcjs/diff/css.js
var require_css = __commonJS({
  "node_modules/diff/libcjs/diff/css.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.cssDiff = void 0;
    exports2.diffCss = diffCss;
    var base_js_1 = __importDefault(require_base());
    var CssDiff = class extends base_js_1.default {
      tokenize(value) {
        return value.split(/([{}:;,]|\s+)/);
      }
    };
    exports2.cssDiff = new CssDiff();
    function diffCss(oldStr, newStr, options) {
      return exports2.cssDiff.diff(oldStr, newStr, options);
    }
  }
});

// node_modules/diff/libcjs/diff/json.js
var require_json = __commonJS({
  "node_modules/diff/libcjs/diff/json.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.jsonDiff = void 0;
    exports2.diffJson = diffJson;
    exports2.canonicalize = canonicalize;
    var base_js_1 = __importDefault(require_base());
    var line_js_1 = require_line();
    var JsonDiff = class extends base_js_1.default {
      constructor() {
        super(...arguments);
        this.tokenize = line_js_1.tokenize;
      }
      get useLongestToken() {
        return true;
      }
      castInput(value, options) {
        const { undefinedReplacement, stringifyReplacer = (k, v) => typeof v === "undefined" ? undefinedReplacement : v } = options;
        return typeof value === "string" ? value : JSON.stringify(canonicalize(value, null, null, stringifyReplacer), null, "  ");
      }
      equals(left, right, options) {
        return super.equals(left.replace(/,([\r\n])/g, "$1"), right.replace(/,([\r\n])/g, "$1"), options);
      }
    };
    exports2.jsonDiff = new JsonDiff();
    function diffJson(oldStr, newStr, options) {
      return exports2.jsonDiff.diff(oldStr, newStr, options);
    }
    function canonicalize(obj, stack, replacementStack, replacer, key) {
      stack = stack || [];
      replacementStack = replacementStack || [];
      if (replacer) {
        obj = replacer(key === void 0 ? "" : key, obj);
      }
      let i;
      for (i = 0; i < stack.length; i += 1) {
        if (stack[i] === obj) {
          return replacementStack[i];
        }
      }
      let canonicalizedObj;
      if ("[object Array]" === Object.prototype.toString.call(obj)) {
        stack.push(obj);
        canonicalizedObj = new Array(obj.length);
        replacementStack.push(canonicalizedObj);
        for (i = 0; i < obj.length; i += 1) {
          canonicalizedObj[i] = canonicalize(obj[i], stack, replacementStack, replacer, String(i));
        }
        stack.pop();
        replacementStack.pop();
        return canonicalizedObj;
      }
      if (obj && obj.toJSON) {
        obj = obj.toJSON();
      }
      if (typeof obj === "object" && obj !== null) {
        stack.push(obj);
        canonicalizedObj = {};
        replacementStack.push(canonicalizedObj);
        const sortedKeys = [];
        let key2;
        for (key2 in obj) {
          if (Object.prototype.hasOwnProperty.call(obj, key2)) {
            sortedKeys.push(key2);
          }
        }
        sortedKeys.sort();
        for (i = 0; i < sortedKeys.length; i += 1) {
          key2 = sortedKeys[i];
          canonicalizedObj[key2] = canonicalize(obj[key2], stack, replacementStack, replacer, key2);
        }
        stack.pop();
        replacementStack.pop();
      } else {
        canonicalizedObj = obj;
      }
      return canonicalizedObj;
    }
  }
});

// node_modules/diff/libcjs/diff/array.js
var require_array2 = __commonJS({
  "node_modules/diff/libcjs/diff/array.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.arrayDiff = void 0;
    exports2.diffArrays = diffArrays;
    var base_js_1 = __importDefault(require_base());
    var ArrayDiff = class extends base_js_1.default {
      tokenize(value) {
        return value.slice();
      }
      join(value) {
        return value;
      }
      removeEmpty(value) {
        return value;
      }
    };
    exports2.arrayDiff = new ArrayDiff();
    function diffArrays(oldArr, newArr, options) {
      return exports2.arrayDiff.diff(oldArr, newArr, options);
    }
  }
});

// node_modules/diff/libcjs/patch/line-endings.js
var require_line_endings = __commonJS({
  "node_modules/diff/libcjs/patch/line-endings.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.unixToWin = unixToWin;
    exports2.winToUnix = winToUnix;
    exports2.isUnix = isUnix;
    exports2.isWin = isWin;
    function unixToWin(patch) {
      if (Array.isArray(patch)) {
        return patch.map((p) => unixToWin(p));
      }
      return Object.assign(Object.assign({}, patch), { hunks: patch.hunks.map((hunk) => Object.assign(Object.assign({}, hunk), { lines: hunk.lines.map((line, i) => {
        var _a;
        return line.startsWith("\\") || line.endsWith("\r") || ((_a = hunk.lines[i + 1]) === null || _a === void 0 ? void 0 : _a.startsWith("\\")) ? line : line + "\r";
      }) })) });
    }
    function winToUnix(patch) {
      if (Array.isArray(patch)) {
        return patch.map((p) => winToUnix(p));
      }
      return Object.assign(Object.assign({}, patch), { hunks: patch.hunks.map((hunk) => Object.assign(Object.assign({}, hunk), { lines: hunk.lines.map((line) => line.endsWith("\r") ? line.substring(0, line.length - 1) : line) })) });
    }
    function isUnix(patch) {
      if (!Array.isArray(patch)) {
        patch = [patch];
      }
      return !patch.some((index) => index.hunks.some((hunk) => hunk.lines.some((line) => !line.startsWith("\\") && line.endsWith("\r"))));
    }
    function isWin(patch) {
      if (!Array.isArray(patch)) {
        patch = [patch];
      }
      return patch.some((index) => index.hunks.some((hunk) => hunk.lines.some((line) => line.endsWith("\r")))) && patch.every((index) => index.hunks.every((hunk) => hunk.lines.every((line, i) => {
        var _a;
        return line.startsWith("\\") || line.endsWith("\r") || ((_a = hunk.lines[i + 1]) === null || _a === void 0 ? void 0 : _a.startsWith("\\"));
      })));
    }
  }
});

// node_modules/diff/libcjs/patch/parse.js
var require_parse = __commonJS({
  "node_modules/diff/libcjs/patch/parse.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.parsePatch = parsePatch;
    function parsePatch(uniDiff) {
      const diffstr = uniDiff.split(/\n/), list = [];
      let i = 0;
      function isGitDiffHeader(line) {
        return /^diff --git /.test(line);
      }
      function isDiffHeader(line) {
        return isGitDiffHeader(line) || /^Index:\s/.test(line) || /^diff(?: -r \w+)+\s/.test(line);
      }
      function isFileHeader(line) {
        return /^(---|\+\+\+)\s/.test(line);
      }
      function isHunkHeader(line) {
        return /^@@\s/.test(line);
      }
      function parseIndex() {
        var _a;
        const index = {};
        index.hunks = [];
        list.push(index);
        let seenDiffHeader = false;
        while (i < diffstr.length) {
          const line = diffstr[i];
          if (isFileHeader(line) || isHunkHeader(line)) {
            break;
          }
          if (isGitDiffHeader(line)) {
            if (seenDiffHeader) {
              return;
            }
            seenDiffHeader = true;
            index.isGit = true;
            const paths = parseGitDiffHeader(line);
            if (paths) {
              index.oldFileName = paths.oldFileName;
              index.newFileName = paths.newFileName;
            }
            i++;
            while (i < diffstr.length) {
              const extLine = diffstr[i];
              if (isFileHeader(extLine) || isHunkHeader(extLine) || isDiffHeader(extLine)) {
                break;
              }
              const renameFromMatch = /^rename from (.*)/.exec(extLine);
              if (renameFromMatch) {
                index.oldFileName = "a/" + unquoteIfQuoted(renameFromMatch[1]);
                index.isRename = true;
              }
              const renameToMatch = /^rename to (.*)/.exec(extLine);
              if (renameToMatch) {
                index.newFileName = "b/" + unquoteIfQuoted(renameToMatch[1]);
                index.isRename = true;
              }
              const copyFromMatch = /^copy from (.*)/.exec(extLine);
              if (copyFromMatch) {
                index.oldFileName = "a/" + unquoteIfQuoted(copyFromMatch[1]);
                index.isCopy = true;
              }
              const copyToMatch = /^copy to (.*)/.exec(extLine);
              if (copyToMatch) {
                index.newFileName = "b/" + unquoteIfQuoted(copyToMatch[1]);
                index.isCopy = true;
              }
              const newFileModeMatch = /^new file mode (\d+)/.exec(extLine);
              if (newFileModeMatch) {
                index.isCreate = true;
                index.newMode = newFileModeMatch[1];
              }
              const deletedFileModeMatch = /^deleted file mode (\d+)/.exec(extLine);
              if (deletedFileModeMatch) {
                index.isDelete = true;
                index.oldMode = deletedFileModeMatch[1];
              }
              const oldModeMatch = /^old mode (\d+)/.exec(extLine);
              if (oldModeMatch) {
                index.oldMode = oldModeMatch[1];
              }
              const newModeMatch = /^new mode (\d+)/.exec(extLine);
              if (newModeMatch) {
                index.newMode = newModeMatch[1];
              }
              if (/^Binary files /.test(extLine)) {
                index.isBinary = true;
              }
              i++;
            }
            continue;
          } else if (isDiffHeader(line)) {
            if (seenDiffHeader) {
              return;
            }
            seenDiffHeader = true;
            const headerMatch = /^(?:Index:|diff(?: -r \w+)+)\s+/.exec(line);
            if (headerMatch) {
              index.index = line.substring(headerMatch[0].length).trim();
            }
          }
          i++;
        }
        parseFileHeader(index);
        parseFileHeader(index);
        if (index.oldFileName === void 0 !== (index.newFileName === void 0)) {
          throw new Error("Missing " + (index.oldFileName !== void 0 ? '"+++ ..."' : '"--- ..."') + " file header for " + ((_a = index.oldFileName) !== null && _a !== void 0 ? _a : index.newFileName));
        }
        while (i < diffstr.length) {
          const line = diffstr[i];
          if (isDiffHeader(line) || isFileHeader(line) || /^===================================================================/.test(line)) {
            break;
          } else if (isHunkHeader(line)) {
            index.hunks.push(parseHunk());
          } else {
            i++;
          }
        }
      }
      function parseGitDiffHeader(line) {
        const rest = line.substring("diff --git ".length);
        if (rest.startsWith('"')) {
          const oldPath = parseQuotedFileName(rest);
          if (oldPath === null) {
            return null;
          }
          const afterOld = rest.substring(oldPath.rawLength + 1);
          let newFileName;
          if (afterOld.startsWith('"')) {
            const newPath = parseQuotedFileName(afterOld);
            if (newPath === null) {
              return null;
            }
            newFileName = newPath.fileName;
          } else {
            newFileName = afterOld;
          }
          return {
            oldFileName: oldPath.fileName,
            newFileName
          };
        }
        const quoteIdx = rest.indexOf('"');
        if (quoteIdx > 0) {
          const oldFileName = rest.substring(0, quoteIdx - 1);
          const newPath = parseQuotedFileName(rest.substring(quoteIdx));
          if (newPath === null) {
            return null;
          }
          return {
            oldFileName,
            newFileName: newPath.fileName
          };
        }
        if (rest.startsWith("a/")) {
          const splits = [];
          let idx = 0;
          while (true) {
            idx = rest.indexOf(" b/", idx + 1);
            if (idx === -1) {
              break;
            }
            splits.push(idx);
          }
          if (splits.length > 0) {
            const mid = splits[Math.floor(splits.length / 2)];
            return {
              oldFileName: rest.substring(0, mid),
              newFileName: rest.substring(mid + 1)
            };
          }
        }
        return null;
      }
      function unquoteIfQuoted(s) {
        if (s.startsWith('"')) {
          const parsed = parseQuotedFileName(s);
          if (parsed) {
            return parsed.fileName;
          }
        }
        return s;
      }
      function parseQuotedFileName(s) {
        if (!s.startsWith('"')) {
          return null;
        }
        let result = "";
        let j = 1;
        while (j < s.length) {
          if (s[j] === '"') {
            return { fileName: result, rawLength: j + 1 };
          }
          if (s[j] === "\\" && j + 1 < s.length) {
            j++;
            switch (s[j]) {
              case "a":
                result += "\x07";
                break;
              case "b":
                result += "\b";
                break;
              case "f":
                result += "\f";
                break;
              case "n":
                result += "\n";
                break;
              case "r":
                result += "\r";
                break;
              case "t":
                result += "	";
                break;
              case "v":
                result += "\v";
                break;
              case "\\":
                result += "\\";
                break;
              case '"':
                result += '"';
                break;
              case "0":
              case "1":
              case "2":
              case "3":
              case "4":
              case "5":
              case "6":
              case "7": {
                if (j + 2 >= s.length || s[j + 1] < "0" || s[j + 1] > "7" || s[j + 2] < "0" || s[j + 2] > "7") {
                  return null;
                }
                const bytes = [parseInt(s.substring(j, j + 3), 8)];
                j += 3;
                while (s[j] === "\\" && s[j + 1] >= "0" && s[j + 1] <= "7") {
                  if (j + 3 >= s.length || s[j + 2] < "0" || s[j + 2] > "7" || s[j + 3] < "0" || s[j + 3] > "7") {
                    return null;
                  }
                  bytes.push(parseInt(s.substring(j + 1, j + 4), 8));
                  j += 4;
                }
                result += new TextDecoder("utf-8").decode(new Uint8Array(bytes));
                continue;
              }
              // Note that in C, there are also three kinds of hex escape sequences:
              // - \xhh
              // - \uhhhh
              // - \Uhhhhhhhh
              // We do not bother to parse them here because, so far as we know,
              // they are never emitted by any tools that generate unified diff
              // format diffs, and so for now jsdiff does not consider them legal.
              default:
                return null;
            }
          } else {
            result += s[j];
          }
          j++;
        }
        return null;
      }
      function parseFileHeader(index) {
        const fileHeaderMatch = /^(---|\+\+\+)\s+/.exec(diffstr[i]);
        if (fileHeaderMatch) {
          const prefix = fileHeaderMatch[1], data = diffstr[i].substring(3).trim().split("	", 2), header = (data[1] || "").trim();
          let fileName = data[0];
          if (fileName.startsWith('"')) {
            fileName = unquoteIfQuoted(fileName);
          } else {
            fileName = fileName.replace(/\\\\/g, "\\");
          }
          if (prefix === "---") {
            index.oldFileName = fileName;
            index.oldHeader = header;
          } else {
            index.newFileName = fileName;
            index.newHeader = header;
          }
          i++;
        }
      }
      function parseHunk() {
        var _a;
        const chunkHeaderIndex = i, chunkHeaderLine = diffstr[i++], chunkHeader = chunkHeaderLine.split(/@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@/);
        const hunk = {
          oldStart: +chunkHeader[1],
          oldLines: typeof chunkHeader[2] === "undefined" ? 1 : +chunkHeader[2],
          newStart: +chunkHeader[3],
          newLines: typeof chunkHeader[4] === "undefined" ? 1 : +chunkHeader[4],
          lines: []
        };
        if (hunk.oldLines === 0) {
          hunk.oldStart += 1;
        }
        if (hunk.newLines === 0) {
          hunk.newStart += 1;
        }
        let addCount = 0, removeCount = 0;
        for (; i < diffstr.length && (removeCount < hunk.oldLines || addCount < hunk.newLines || ((_a = diffstr[i]) === null || _a === void 0 ? void 0 : _a.startsWith("\\"))); i++) {
          const operation = diffstr[i].length == 0 && i != diffstr.length - 1 ? " " : diffstr[i][0];
          if (operation === "+" || operation === "-" || operation === " " || operation === "\\") {
            hunk.lines.push(diffstr[i]);
            if (operation === "+") {
              addCount++;
            } else if (operation === "-") {
              removeCount++;
            } else if (operation === " ") {
              addCount++;
              removeCount++;
            }
          } else {
            throw new Error(`Hunk at line ${chunkHeaderIndex + 1} contained invalid line ${diffstr[i]}`);
          }
        }
        if (!addCount && hunk.newLines === 1) {
          hunk.newLines = 0;
        }
        if (!removeCount && hunk.oldLines === 1) {
          hunk.oldLines = 0;
        }
        if (addCount !== hunk.newLines) {
          throw new Error("Added line count did not match for hunk at line " + (chunkHeaderIndex + 1));
        }
        if (removeCount !== hunk.oldLines) {
          throw new Error("Removed line count did not match for hunk at line " + (chunkHeaderIndex + 1));
        }
        if (i < diffstr.length && diffstr[i] && /^[+ -]/.test(diffstr[i]) && !isFileHeader(diffstr[i])) {
          throw new Error("Hunk at line " + (chunkHeaderIndex + 1) + " has more lines than expected (expected " + hunk.oldLines + " old lines and " + hunk.newLines + " new lines)");
        }
        return hunk;
      }
      while (i < diffstr.length) {
        parseIndex();
      }
      return list;
    }
  }
});

// node_modules/diff/libcjs/util/distance-iterator.js
var require_distance_iterator = __commonJS({
  "node_modules/diff/libcjs/util/distance-iterator.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.default = default_1;
    function default_1(start, minLine, maxLine) {
      let wantForward = true, backwardExhausted = false, forwardExhausted = false, localOffset = 1;
      return function iterator() {
        if (wantForward && !forwardExhausted) {
          if (backwardExhausted) {
            localOffset++;
          } else {
            wantForward = false;
          }
          if (start + localOffset <= maxLine) {
            return start + localOffset;
          }
          forwardExhausted = true;
        }
        if (!backwardExhausted) {
          if (!forwardExhausted) {
            wantForward = true;
          }
          if (minLine <= start - localOffset) {
            return start - localOffset++;
          }
          backwardExhausted = true;
          return iterator();
        }
        return void 0;
      };
    }
  }
});

// node_modules/diff/libcjs/patch/apply.js
var require_apply = __commonJS({
  "node_modules/diff/libcjs/patch/apply.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.applyPatch = applyPatch;
    exports2.applyPatches = applyPatches;
    var string_js_1 = require_string2();
    var line_endings_js_1 = require_line_endings();
    var parse_js_1 = require_parse();
    var distance_iterator_js_1 = __importDefault(require_distance_iterator());
    function applyPatch(source, patch, options = {}) {
      let patches;
      if (typeof patch === "string") {
        patches = (0, parse_js_1.parsePatch)(patch);
      } else if (Array.isArray(patch)) {
        patches = patch;
      } else {
        patches = [patch];
      }
      if (patches.length > 1) {
        throw new Error("applyPatch only works with a single input.");
      }
      return applyStructuredPatch(source, patches[0], options);
    }
    function applyStructuredPatch(source, patch, options = {}) {
      if (options.autoConvertLineEndings || options.autoConvertLineEndings == null) {
        if ((0, string_js_1.hasOnlyWinLineEndings)(source) && (0, line_endings_js_1.isUnix)(patch)) {
          patch = (0, line_endings_js_1.unixToWin)(patch);
        } else if ((0, string_js_1.hasOnlyUnixLineEndings)(source) && (0, line_endings_js_1.isWin)(patch)) {
          patch = (0, line_endings_js_1.winToUnix)(patch);
        }
      }
      const lines = source.split("\n"), hunks = patch.hunks, compareLine = options.compareLine || ((lineNumber, line, operation, patchContent) => line === patchContent), fuzzFactor = options.fuzzFactor || 0;
      let minLine = 0;
      if (fuzzFactor < 0 || !Number.isInteger(fuzzFactor)) {
        throw new Error("fuzzFactor must be a non-negative integer");
      }
      if (!hunks.length) {
        return source;
      }
      let prevLine = "", removeEOFNL = false, addEOFNL = false;
      for (let i = 0; i < hunks[hunks.length - 1].lines.length; i++) {
        const line = hunks[hunks.length - 1].lines[i];
        if (line[0] == "\\") {
          if (prevLine[0] == "+") {
            removeEOFNL = true;
          } else if (prevLine[0] == "-") {
            addEOFNL = true;
          }
        }
        prevLine = line;
      }
      if (removeEOFNL) {
        if (addEOFNL) {
          if (!fuzzFactor && lines[lines.length - 1] == "") {
            return false;
          }
        } else if (lines[lines.length - 1] == "") {
          lines.pop();
        } else if (!fuzzFactor) {
          return false;
        }
      } else if (addEOFNL) {
        if (lines[lines.length - 1] != "") {
          lines.push("");
        } else if (!fuzzFactor) {
          return false;
        }
      }
      function applyHunk(hunkLines, toPos, maxErrors, hunkLinesI = 0, lastContextLineMatched = true, patchedLines = [], patchedLinesLength = 0) {
        let nConsecutiveOldContextLines = 0;
        let nextContextLineMustMatch = false;
        for (; hunkLinesI < hunkLines.length; hunkLinesI++) {
          const hunkLine = hunkLines[hunkLinesI], operation = hunkLine.length > 0 ? hunkLine[0] : " ", content = hunkLine.length > 0 ? hunkLine.substr(1) : hunkLine;
          if (operation === "-") {
            if (compareLine(toPos + 1, lines[toPos], operation, content)) {
              toPos++;
              nConsecutiveOldContextLines = 0;
            } else {
              if (!maxErrors || lines[toPos] == null) {
                return null;
              }
              patchedLines[patchedLinesLength] = lines[toPos];
              return applyHunk(hunkLines, toPos + 1, maxErrors - 1, hunkLinesI, false, patchedLines, patchedLinesLength + 1);
            }
          }
          if (operation === "+") {
            if (!lastContextLineMatched) {
              return null;
            }
            patchedLines[patchedLinesLength] = content;
            patchedLinesLength++;
            nConsecutiveOldContextLines = 0;
            nextContextLineMustMatch = true;
          }
          if (operation === " ") {
            nConsecutiveOldContextLines++;
            patchedLines[patchedLinesLength] = lines[toPos];
            if (compareLine(toPos + 1, lines[toPos], operation, content)) {
              patchedLinesLength++;
              lastContextLineMatched = true;
              nextContextLineMustMatch = false;
              toPos++;
            } else {
              if (nextContextLineMustMatch || !maxErrors) {
                return null;
              }
              return lines[toPos] && (applyHunk(hunkLines, toPos + 1, maxErrors - 1, hunkLinesI + 1, false, patchedLines, patchedLinesLength + 1) || applyHunk(hunkLines, toPos + 1, maxErrors - 1, hunkLinesI, false, patchedLines, patchedLinesLength + 1)) || applyHunk(hunkLines, toPos, maxErrors - 1, hunkLinesI + 1, false, patchedLines, patchedLinesLength);
            }
          }
        }
        patchedLinesLength -= nConsecutiveOldContextLines;
        toPos -= nConsecutiveOldContextLines;
        patchedLines.length = patchedLinesLength;
        return {
          patchedLines,
          oldLineLastI: toPos - 1
        };
      }
      const resultLines = [];
      let prevHunkOffset = 0;
      for (let i = 0; i < hunks.length; i++) {
        const hunk = hunks[i];
        let hunkResult;
        const maxLine = lines.length - hunk.oldLines + fuzzFactor;
        let toPos;
        for (let maxErrors = 0; maxErrors <= fuzzFactor; maxErrors++) {
          toPos = hunk.oldStart + prevHunkOffset - 1;
          const iterator = (0, distance_iterator_js_1.default)(toPos, minLine, maxLine);
          for (; toPos !== void 0; toPos = iterator()) {
            hunkResult = applyHunk(hunk.lines, toPos, maxErrors);
            if (hunkResult) {
              break;
            }
          }
          if (hunkResult) {
            break;
          }
        }
        if (!hunkResult) {
          return false;
        }
        for (let i2 = minLine; i2 < toPos; i2++) {
          resultLines.push(lines[i2]);
        }
        for (let i2 = 0; i2 < hunkResult.patchedLines.length; i2++) {
          const line = hunkResult.patchedLines[i2];
          resultLines.push(line);
        }
        minLine = hunkResult.oldLineLastI + 1;
        prevHunkOffset = toPos + 1 - hunk.oldStart;
      }
      for (let i = minLine; i < lines.length; i++) {
        resultLines.push(lines[i]);
      }
      return resultLines.join("\n");
    }
    function applyPatches(uniDiff, options) {
      const spDiff = typeof uniDiff === "string" ? (0, parse_js_1.parsePatch)(uniDiff) : uniDiff;
      let currentIndex = 0;
      function processIndex() {
        const index = spDiff[currentIndex++];
        if (!index) {
          return options.complete();
        }
        options.loadFile(index, function(err, data) {
          if (err) {
            return options.complete(err);
          }
          const updatedContent = applyPatch(data, index, options);
          options.patched(index, updatedContent, function(err2) {
            if (err2) {
              return options.complete(err2);
            }
            processIndex();
          });
        });
      }
      processIndex();
    }
  }
});

// node_modules/diff/libcjs/patch/reverse.js
var require_reverse = __commonJS({
  "node_modules/diff/libcjs/patch/reverse.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.reversePatch = reversePatch;
    function swapPrefix(fileName) {
      if (fileName === void 0 || fileName === "/dev/null") {
        return fileName;
      }
      if (fileName.startsWith("a/")) {
        return "b/" + fileName.slice(2);
      }
      if (fileName.startsWith("b/")) {
        return "a/" + fileName.slice(2);
      }
      return fileName;
    }
    function reversePatch(structuredPatch) {
      if (Array.isArray(structuredPatch)) {
        return structuredPatch.map((patch) => reversePatch(patch)).reverse();
      }
      const reversed = Object.assign(Object.assign({}, structuredPatch), { oldFileName: structuredPatch.isGit ? swapPrefix(structuredPatch.newFileName) : structuredPatch.newFileName, oldHeader: structuredPatch.newHeader, newFileName: structuredPatch.isGit ? swapPrefix(structuredPatch.oldFileName) : structuredPatch.oldFileName, newHeader: structuredPatch.oldHeader, oldMode: structuredPatch.newMode, newMode: structuredPatch.oldMode, isCreate: structuredPatch.isDelete, isDelete: structuredPatch.isCreate, hunks: structuredPatch.hunks.map((hunk) => {
        return {
          oldLines: hunk.newLines,
          oldStart: hunk.newStart,
          newLines: hunk.oldLines,
          newStart: hunk.oldStart,
          lines: hunk.lines.map((l) => {
            if (l.startsWith("-")) {
              return `+${l.slice(1)}`;
            }
            if (l.startsWith("+")) {
              return `-${l.slice(1)}`;
            }
            return l;
          })
        };
      }) });
      if (structuredPatch.isCopy) {
        reversed.newFileName = "/dev/null";
        reversed.newHeader = void 0;
        reversed.isDelete = true;
        delete reversed.isCreate;
        delete reversed.isCopy;
        delete reversed.isRename;
        reversed.hunks = [];
      }
      return reversed;
    }
  }
});

// node_modules/diff/libcjs/patch/create.js
var require_create = __commonJS({
  "node_modules/diff/libcjs/patch/create.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.OMIT_HEADERS = exports2.FILE_HEADERS_ONLY = exports2.INCLUDE_HEADERS = void 0;
    exports2.structuredPatch = structuredPatch;
    exports2.formatPatch = formatPatch;
    exports2.createTwoFilesPatch = createTwoFilesPatch;
    exports2.createPatch = createPatch;
    var line_js_1 = require_line();
    function needsQuoting(s) {
      for (let i = 0; i < s.length; i++) {
        if (s[i] < " " || s[i] > "~" || s[i] === '"' || s[i] === "\\") {
          return true;
        }
      }
      return false;
    }
    function quoteFileNameIfNeeded(s) {
      if (!needsQuoting(s)) {
        return s;
      }
      let result = '"';
      const bytes = new TextEncoder().encode(s);
      let i = 0;
      while (i < bytes.length) {
        const b = bytes[i];
        if (b === 7) {
          result += "\\a";
        } else if (b === 8) {
          result += "\\b";
        } else if (b === 9) {
          result += "\\t";
        } else if (b === 10) {
          result += "\\n";
        } else if (b === 11) {
          result += "\\v";
        } else if (b === 12) {
          result += "\\f";
        } else if (b === 13) {
          result += "\\r";
        } else if (b === 34) {
          result += '\\"';
        } else if (b === 92) {
          result += "\\\\";
        } else if (b >= 32 && b <= 126) {
          result += String.fromCharCode(b);
        } else {
          result += "\\" + b.toString(8).padStart(3, "0");
        }
        i++;
      }
      result += '"';
      return result;
    }
    exports2.INCLUDE_HEADERS = {
      includeIndex: true,
      includeUnderline: true,
      includeFileHeaders: true
    };
    exports2.FILE_HEADERS_ONLY = {
      includeIndex: false,
      includeUnderline: false,
      includeFileHeaders: true
    };
    exports2.OMIT_HEADERS = {
      includeIndex: false,
      includeUnderline: false,
      includeFileHeaders: false
    };
    function structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options) {
      let optionsObj;
      if (!options) {
        optionsObj = {};
      } else if (typeof options === "function") {
        optionsObj = { callback: options };
      } else {
        optionsObj = options;
      }
      if (typeof optionsObj.context === "undefined") {
        optionsObj.context = 4;
      }
      const context = optionsObj.context;
      if (optionsObj.newlineIsToken) {
        throw new Error("newlineIsToken may not be used with patch-generation functions, only with diffing functions");
      }
      if (!optionsObj.callback) {
        return diffLinesResultToPatch((0, line_js_1.diffLines)(oldStr, newStr, optionsObj));
      } else {
        const { callback } = optionsObj;
        (0, line_js_1.diffLines)(oldStr, newStr, Object.assign(Object.assign({}, optionsObj), { callback: (diff) => {
          const patch = diffLinesResultToPatch(diff);
          callback(patch);
        } }));
      }
      function diffLinesResultToPatch(diff) {
        if (!diff) {
          return;
        }
        diff.push({ value: "", lines: [] });
        function contextLines(lines) {
          return lines.map(function(entry) {
            return " " + entry;
          });
        }
        const hunks = [];
        let oldRangeStart = 0, newRangeStart = 0, curRange = [], oldLine = 1, newLine = 1;
        for (let i = 0; i < diff.length; i++) {
          const current = diff[i], lines = current.lines || splitLines(current.value);
          current.lines = lines;
          if (current.added || current.removed) {
            if (!oldRangeStart) {
              const prev = diff[i - 1];
              oldRangeStart = oldLine;
              newRangeStart = newLine;
              if (prev) {
                curRange = context > 0 ? contextLines(prev.lines.slice(-context)) : [];
                oldRangeStart -= curRange.length;
                newRangeStart -= curRange.length;
              }
            }
            for (const line of lines) {
              curRange.push((current.added ? "+" : "-") + line);
            }
            if (current.added) {
              newLine += lines.length;
            } else {
              oldLine += lines.length;
            }
          } else {
            if (oldRangeStart) {
              if (lines.length <= context * 2 && i < diff.length - 2) {
                for (const line of contextLines(lines)) {
                  curRange.push(line);
                }
              } else {
                const contextSize = Math.min(lines.length, context);
                for (const line of contextLines(lines.slice(0, contextSize))) {
                  curRange.push(line);
                }
                const hunk = {
                  oldStart: oldRangeStart,
                  oldLines: oldLine - oldRangeStart + contextSize,
                  newStart: newRangeStart,
                  newLines: newLine - newRangeStart + contextSize,
                  lines: curRange
                };
                hunks.push(hunk);
                oldRangeStart = 0;
                newRangeStart = 0;
                curRange = [];
              }
            }
            oldLine += lines.length;
            newLine += lines.length;
          }
        }
        for (const hunk of hunks) {
          for (let i = 0; i < hunk.lines.length; i++) {
            if (hunk.lines[i].endsWith("\n")) {
              hunk.lines[i] = hunk.lines[i].slice(0, -1);
            } else {
              hunk.lines.splice(i + 1, 0, "\\ No newline at end of file");
              i++;
            }
          }
        }
        return {
          oldFileName,
          newFileName,
          oldHeader,
          newHeader,
          hunks
        };
      }
    }
    function formatPatch(patch, headerOptions) {
      var _a, _b, _c, _d, _e, _f;
      if (!headerOptions) {
        headerOptions = exports2.INCLUDE_HEADERS;
      }
      if (Array.isArray(patch)) {
        if (patch.length > 1 && !headerOptions.includeFileHeaders && !patch.every((p) => p.isGit)) {
          throw new Error("Cannot omit file headers on a multi-file patch. (The result would be unparseable; how would a tool trying to apply the patch know which changes are to which file?)");
        }
        return patch.map((p) => formatPatch(p, headerOptions)).join("\n");
      }
      const ret = [];
      if (patch.isGit) {
        headerOptions = exports2.INCLUDE_HEADERS;
        if (!patch.oldFileName) {
          throw new Error("oldFileName must be specified for Git patches");
        }
        if (!patch.newFileName) {
          throw new Error("newFileName must be specified for Git patches");
        }
        let gitOldName = patch.oldFileName;
        let gitNewName = patch.newFileName;
        if (patch.isCreate && gitOldName === "/dev/null") {
          gitOldName = gitNewName.replace(/^b\//, "a/");
        } else if (patch.isDelete && gitNewName === "/dev/null") {
          gitNewName = gitOldName.replace(/^a\//, "b/");
        }
        ret.push("diff --git " + quoteFileNameIfNeeded(gitOldName) + " " + quoteFileNameIfNeeded(gitNewName));
        if (patch.isDelete) {
          ret.push("deleted file mode " + ((_a = patch.oldMode) !== null && _a !== void 0 ? _a : "100644"));
        }
        if (patch.isCreate) {
          ret.push("new file mode " + ((_b = patch.newMode) !== null && _b !== void 0 ? _b : "100644"));
        }
        if (patch.oldMode && patch.newMode && !patch.isDelete && !patch.isCreate) {
          ret.push("old mode " + patch.oldMode);
          ret.push("new mode " + patch.newMode);
        }
        if (patch.isRename) {
          ret.push("rename from " + quoteFileNameIfNeeded(((_c = patch.oldFileName) !== null && _c !== void 0 ? _c : "").replace(/^a\//, "")));
          ret.push("rename to " + quoteFileNameIfNeeded(((_d = patch.newFileName) !== null && _d !== void 0 ? _d : "").replace(/^b\//, "")));
        }
        if (patch.isCopy) {
          ret.push("copy from " + quoteFileNameIfNeeded(((_e = patch.oldFileName) !== null && _e !== void 0 ? _e : "").replace(/^a\//, "")));
          ret.push("copy to " + quoteFileNameIfNeeded(((_f = patch.newFileName) !== null && _f !== void 0 ? _f : "").replace(/^b\//, "")));
        }
      } else {
        if (headerOptions.includeIndex && patch.oldFileName == patch.newFileName && patch.oldFileName !== void 0) {
          ret.push("Index: " + patch.oldFileName);
        }
        if (headerOptions.includeUnderline) {
          ret.push("===================================================================");
        }
      }
      const hasHunks = patch.hunks.length > 0;
      if (headerOptions.includeFileHeaders && patch.oldFileName !== void 0 && patch.newFileName !== void 0 && (!patch.isGit || hasHunks)) {
        ret.push("--- " + quoteFileNameIfNeeded(patch.oldFileName) + (patch.oldHeader ? "	" + patch.oldHeader : ""));
        ret.push("+++ " + quoteFileNameIfNeeded(patch.newFileName) + (patch.newHeader ? "	" + patch.newHeader : ""));
      }
      for (let i = 0; i < patch.hunks.length; i++) {
        const hunk = patch.hunks[i];
        const oldStart = hunk.oldLines === 0 ? hunk.oldStart - 1 : hunk.oldStart;
        const newStart = hunk.newLines === 0 ? hunk.newStart - 1 : hunk.newStart;
        ret.push("@@ -" + oldStart + "," + hunk.oldLines + " +" + newStart + "," + hunk.newLines + " @@");
        for (const line of hunk.lines) {
          ret.push(line);
        }
      }
      return ret.join("\n") + "\n";
    }
    function createTwoFilesPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options) {
      if (typeof options === "function") {
        options = { callback: options };
      }
      if (!(options === null || options === void 0 ? void 0 : options.callback)) {
        const patchObj = structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, options);
        if (!patchObj) {
          return;
        }
        return formatPatch(patchObj, options === null || options === void 0 ? void 0 : options.headerOptions);
      } else {
        const { callback } = options;
        structuredPatch(oldFileName, newFileName, oldStr, newStr, oldHeader, newHeader, Object.assign(Object.assign({}, options), { callback: (patchObj) => {
          if (!patchObj) {
            callback(void 0);
          } else {
            callback(formatPatch(patchObj, options.headerOptions));
          }
        } }));
      }
    }
    function createPatch(fileName, oldStr, newStr, oldHeader, newHeader, options) {
      return createTwoFilesPatch(fileName, fileName, oldStr, newStr, oldHeader, newHeader, options);
    }
    function splitLines(text) {
      const hasTrailingNl = text.endsWith("\n");
      const result = text.split("\n").map((line) => line + "\n");
      if (hasTrailingNl) {
        result.pop();
      } else {
        result.push(result.pop().slice(0, -1));
      }
      return result;
    }
  }
});

// node_modules/diff/libcjs/convert/dmp.js
var require_dmp = __commonJS({
  "node_modules/diff/libcjs/convert/dmp.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.convertChangesToDMP = convertChangesToDMP;
    function convertChangesToDMP(changes) {
      const ret = [];
      let change, operation;
      for (let i = 0; i < changes.length; i++) {
        change = changes[i];
        if (change.added) {
          operation = 1;
        } else if (change.removed) {
          operation = -1;
        } else {
          operation = 0;
        }
        ret.push([operation, change.value]);
      }
      return ret;
    }
  }
});

// node_modules/diff/libcjs/convert/xml.js
var require_xml = __commonJS({
  "node_modules/diff/libcjs/convert/xml.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.convertChangesToXML = convertChangesToXML;
    function convertChangesToXML(changes) {
      const ret = [];
      for (let i = 0; i < changes.length; i++) {
        const change = changes[i];
        if (change.added) {
          ret.push("<ins>");
        } else if (change.removed) {
          ret.push("<del>");
        }
        ret.push(escapeHTML(change.value));
        if (change.added) {
          ret.push("</ins>");
        } else if (change.removed) {
          ret.push("</del>");
        }
      }
      return ret.join("");
    }
    function escapeHTML(s) {
      let n = s;
      n = n.replace(/&/g, "&amp;");
      n = n.replace(/</g, "&lt;");
      n = n.replace(/>/g, "&gt;");
      n = n.replace(/"/g, "&quot;");
      return n;
    }
  }
});

// node_modules/diff/libcjs/index.js
var require_libcjs = __commonJS({
  "node_modules/diff/libcjs/index.js"(exports2) {
    "use strict";
    var __importDefault = exports2 && exports2.__importDefault || function(mod) {
      return mod && mod.__esModule ? mod : { "default": mod };
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.canonicalize = exports2.convertChangesToXML = exports2.convertChangesToDMP = exports2.reversePatch = exports2.parsePatch = exports2.applyPatches = exports2.applyPatch = exports2.OMIT_HEADERS = exports2.FILE_HEADERS_ONLY = exports2.INCLUDE_HEADERS = exports2.formatPatch = exports2.createPatch = exports2.createTwoFilesPatch = exports2.structuredPatch = exports2.arrayDiff = exports2.diffArrays = exports2.jsonDiff = exports2.diffJson = exports2.cssDiff = exports2.diffCss = exports2.sentenceDiff = exports2.diffSentences = exports2.diffTrimmedLines = exports2.lineDiff = exports2.diffLines = exports2.wordsWithSpaceDiff = exports2.diffWordsWithSpace = exports2.wordDiff = exports2.diffWords = exports2.characterDiff = exports2.diffChars = exports2.Diff = void 0;
    var base_js_1 = __importDefault(require_base());
    exports2.Diff = base_js_1.default;
    var character_js_1 = require_character();
    Object.defineProperty(exports2, "diffChars", { enumerable: true, get: function() {
      return character_js_1.diffChars;
    } });
    Object.defineProperty(exports2, "characterDiff", { enumerable: true, get: function() {
      return character_js_1.characterDiff;
    } });
    var word_js_1 = require_word();
    Object.defineProperty(exports2, "diffWords", { enumerable: true, get: function() {
      return word_js_1.diffWords;
    } });
    Object.defineProperty(exports2, "diffWordsWithSpace", { enumerable: true, get: function() {
      return word_js_1.diffWordsWithSpace;
    } });
    Object.defineProperty(exports2, "wordDiff", { enumerable: true, get: function() {
      return word_js_1.wordDiff;
    } });
    Object.defineProperty(exports2, "wordsWithSpaceDiff", { enumerable: true, get: function() {
      return word_js_1.wordsWithSpaceDiff;
    } });
    var line_js_1 = require_line();
    Object.defineProperty(exports2, "diffLines", { enumerable: true, get: function() {
      return line_js_1.diffLines;
    } });
    Object.defineProperty(exports2, "diffTrimmedLines", { enumerable: true, get: function() {
      return line_js_1.diffTrimmedLines;
    } });
    Object.defineProperty(exports2, "lineDiff", { enumerable: true, get: function() {
      return line_js_1.lineDiff;
    } });
    var sentence_js_1 = require_sentence();
    Object.defineProperty(exports2, "diffSentences", { enumerable: true, get: function() {
      return sentence_js_1.diffSentences;
    } });
    Object.defineProperty(exports2, "sentenceDiff", { enumerable: true, get: function() {
      return sentence_js_1.sentenceDiff;
    } });
    var css_js_1 = require_css();
    Object.defineProperty(exports2, "diffCss", { enumerable: true, get: function() {
      return css_js_1.diffCss;
    } });
    Object.defineProperty(exports2, "cssDiff", { enumerable: true, get: function() {
      return css_js_1.cssDiff;
    } });
    var json_js_1 = require_json();
    Object.defineProperty(exports2, "diffJson", { enumerable: true, get: function() {
      return json_js_1.diffJson;
    } });
    Object.defineProperty(exports2, "canonicalize", { enumerable: true, get: function() {
      return json_js_1.canonicalize;
    } });
    Object.defineProperty(exports2, "jsonDiff", { enumerable: true, get: function() {
      return json_js_1.jsonDiff;
    } });
    var array_js_1 = require_array2();
    Object.defineProperty(exports2, "diffArrays", { enumerable: true, get: function() {
      return array_js_1.diffArrays;
    } });
    Object.defineProperty(exports2, "arrayDiff", { enumerable: true, get: function() {
      return array_js_1.arrayDiff;
    } });
    var apply_js_1 = require_apply();
    Object.defineProperty(exports2, "applyPatch", { enumerable: true, get: function() {
      return apply_js_1.applyPatch;
    } });
    Object.defineProperty(exports2, "applyPatches", { enumerable: true, get: function() {
      return apply_js_1.applyPatches;
    } });
    var parse_js_1 = require_parse();
    Object.defineProperty(exports2, "parsePatch", { enumerable: true, get: function() {
      return parse_js_1.parsePatch;
    } });
    var reverse_js_1 = require_reverse();
    Object.defineProperty(exports2, "reversePatch", { enumerable: true, get: function() {
      return reverse_js_1.reversePatch;
    } });
    var create_js_1 = require_create();
    Object.defineProperty(exports2, "structuredPatch", { enumerable: true, get: function() {
      return create_js_1.structuredPatch;
    } });
    Object.defineProperty(exports2, "createTwoFilesPatch", { enumerable: true, get: function() {
      return create_js_1.createTwoFilesPatch;
    } });
    Object.defineProperty(exports2, "createPatch", { enumerable: true, get: function() {
      return create_js_1.createPatch;
    } });
    Object.defineProperty(exports2, "formatPatch", { enumerable: true, get: function() {
      return create_js_1.formatPatch;
    } });
    Object.defineProperty(exports2, "INCLUDE_HEADERS", { enumerable: true, get: function() {
      return create_js_1.INCLUDE_HEADERS;
    } });
    Object.defineProperty(exports2, "FILE_HEADERS_ONLY", { enumerable: true, get: function() {
      return create_js_1.FILE_HEADERS_ONLY;
    } });
    Object.defineProperty(exports2, "OMIT_HEADERS", { enumerable: true, get: function() {
      return create_js_1.OMIT_HEADERS;
    } });
    var dmp_js_1 = require_dmp();
    Object.defineProperty(exports2, "convertChangesToDMP", { enumerable: true, get: function() {
      return dmp_js_1.convertChangesToDMP;
    } });
    var xml_js_1 = require_xml();
    Object.defineProperty(exports2, "convertChangesToXML", { enumerable: true, get: function() {
      return xml_js_1.convertChangesToXML;
    } });
  }
});

// lib/sinon/spy-formatters.js
var require_spy_formatters = __commonJS({
  "lib/sinon/spy-formatters.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var colorizer$1 = require_colorizer();
    var samsam = require_samsam();
    var timesInWords = require_times_in_words();
    var util = require_util();
    var jsDiff = require_libcjs();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    function _interopNamespace(e) {
      if (e && e.__esModule) return e;
      var n = /* @__PURE__ */ Object.create(null);
      if (e) {
        Object.keys(e).forEach(function(k) {
          if (k !== "default") {
            var d = Object.getOwnPropertyDescriptor(e, k);
            Object.defineProperty(n, k, d.get ? d : {
              enumerable: true,
              get: function() {
                return e[k];
              }
            });
          }
        });
      }
      n.default = e;
      return Object.freeze(n);
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var jsDiff__namespace = /* @__PURE__ */ _interopNamespace(jsDiff);
    var { prototypes } = commons__default.default;
    var { createMatcher: match } = samsam__default.default;
    var { join, map, push, slice } = prototypes.array;
    var colorizer = new colorizer$1();
    function colorSinonMatchText(matcher, calledArg, calledArgMessage) {
      let calledArgumentMessage = calledArgMessage;
      let matcherMessage = matcher.message;
      if (!matcher.test(calledArg)) {
        matcherMessage = colorizer.red(matcher.message);
        if (calledArgumentMessage) {
          calledArgumentMessage = colorizer.green(calledArgumentMessage);
        }
      }
      return `${calledArgumentMessage} ${matcherMessage}`;
    }
    function colorDiffText(diff) {
      const objects = map(diff, function(part) {
        let text = part.value;
        if (part.added) {
          text = colorizer.green(text);
        } else if (part.removed) {
          text = colorizer.red(text);
        }
        if (diff.length === 2) {
          text += " ";
        }
        return text;
      });
      return join(objects, "");
    }
    function quoteStringValue(value) {
      if (typeof value === "string") {
        return JSON.stringify(value);
      }
      return value;
    }
    var formatters = {
      c: function(spyInstance) {
        return timesInWords(spyInstance.callCount);
      },
      n: function(spyInstance) {
        return spyInstance.toString();
      },
      D: function(spyInstance, args) {
        let message = "";
        for (let i = 0, l = spyInstance.callCount; i < l; ++i) {
          if (l > 1) {
            message += `
Call ${i + 1}:`;
          }
          const calledArgs = spyInstance.getCall(i).args;
          const expectedArgs = slice(args);
          for (let j = 0; j < calledArgs.length || j < expectedArgs.length; ++j) {
            let calledArg = calledArgs[j];
            let expectedArg = expectedArgs[j];
            if (calledArg) {
              calledArg = quoteStringValue(calledArg);
            }
            if (expectedArg) {
              expectedArg = quoteStringValue(expectedArg);
            }
            message += "\n";
            const calledArgMessage = j < calledArgs.length ? util.inspect(calledArg) : "";
            if (match.isMatcher(expectedArg)) {
              message += colorSinonMatchText(
                expectedArg,
                calledArg,
                calledArgMessage
              );
            } else {
              const expectedArgMessage = j < expectedArgs.length ? util.inspect(expectedArg) : "";
              const diff = jsDiff__namespace.diffJson(
                calledArgMessage,
                expectedArgMessage
              );
              message += colorDiffText(diff);
            }
          }
        }
        return message;
      },
      C: function(spyInstance) {
        const calls = [];
        for (let i = 0, l = spyInstance.callCount; i < l; ++i) {
          let stringifiedCall = `    ${spyInstance.getCall(i).toString()}`;
          if (/\n/.test(calls[i - 1])) {
            stringifiedCall = `
${stringifiedCall}`;
          }
          push(calls, stringifiedCall);
        }
        return calls.length > 0 ? `
${join(calls, "\n")}` : "";
      },
      t: function(spyInstance) {
        const objects = [];
        for (let i = 0, l = spyInstance.callCount; i < l; ++i) {
          push(objects, util.inspect(spyInstance.thisValues[i]));
        }
        return join(objects, ", ");
      },
      "*": function(spyInstance, args) {
        return join(
          map(args, function(arg) {
            return util.inspect(arg);
          }),
          ", "
        );
      }
    };
    module2.exports = formatters;
  }
});

// lib/sinon/proxy.js
var require_proxy = __commonJS({
  "lib/sinon/proxy.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var extend = require_extend();
    var functionToString = require_function_to_string();
    var proxyCall = require_proxy_call();
    var proxyCallUtil = require_proxy_call_util();
    var proxyInvoke = require_proxy_invoke();
    var util = require_util();
    var spyFormatters = require_spy_formatters();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { push, forEach, slice } = prototypes.array;
    var emptyFakes = [];
    var proxyApi = {
      toString: functionToString,
      named: function named(name) {
        this.displayName = name;
        const nameDescriptor = Object.getOwnPropertyDescriptor(this, "name");
        if (nameDescriptor && nameDescriptor.configurable) {
          nameDescriptor.value = name;
          Object.defineProperty(this, "name", nameDescriptor);
        }
        return this;
      },
      invoke: proxyInvoke,
      /*
       * Hook for derived implementation to return fake instances matching the
       * given arguments.
       */
      matchingFakes: function() {
        return emptyFakes;
      },
      getCall: function getCall(index) {
        let i = index;
        if (i < 0) {
          i += this.callCount;
        }
        if (i < 0 || i >= this.callCount) {
          return null;
        }
        return proxyCall(
          this,
          this.thisValues[i],
          this.args[i],
          this.returnValues[i],
          this.exceptions[i],
          this.callIds[i],
          this.errorsWithCallStack[i]
        );
      },
      getCalls: function() {
        const calls = [];
        let i;
        for (i = 0; i < this.callCount; i++) {
          push(calls, this.getCall(i));
        }
        return calls;
      },
      calledBefore: function calledBefore(proxy) {
        if (!this.called) {
          return false;
        }
        if (!proxy.called) {
          return true;
        }
        return this.callIds[0] < proxy.callIds[proxy.callIds.length - 1];
      },
      calledAfter: function calledAfter(proxy) {
        if (!this.called || !proxy.called) {
          return false;
        }
        return this.callIds[this.callCount - 1] > proxy.callIds[0];
      },
      calledImmediatelyBefore: function calledImmediatelyBefore(proxy) {
        if (!this.called || !proxy.called) {
          return false;
        }
        return this.callIds[this.callCount - 1] === proxy.callIds[proxy.callCount - 1] - 1;
      },
      calledImmediatelyAfter: function calledImmediatelyAfter(proxy) {
        if (!this.called || !proxy.called) {
          return false;
        }
        return this.callIds[this.callCount - 1] === proxy.callIds[proxy.callCount - 1] + 1;
      },
      formatters: spyFormatters,
      printf: function(format) {
        const spyInstance = this;
        const args = slice(arguments, 1);
        let formatter;
        return (format || "").replace(/%(.)/g, function(match, specifier) {
          formatter = proxyApi.formatters[specifier];
          if (typeof formatter === "function") {
            return String(formatter(spyInstance, args));
          } else if (!isNaN(parseInt(specifier, 10))) {
            return util.inspect(args[specifier - 1]);
          }
          return `%${specifier}`;
        });
      },
      resetHistory: function() {
        if (this.invoking) {
          const err = new Error(
            "Cannot reset Sinon function while invoking it. Move the call to .resetHistory outside of the callback."
          );
          err.name = "InvalidResetException";
          throw err;
        }
        this.called = false;
        this.notCalled = true;
        this.calledOnce = false;
        this.calledTwice = false;
        this.calledThrice = false;
        this.callCount = 0;
        this.firstCall = null;
        this.secondCall = null;
        this.thirdCall = null;
        this.lastCall = null;
        this.lastArg = null;
        this.args = [];
        this.firstArg = null;
        this.returnValues = [];
        this.thisValues = [];
        this.exceptions = [];
        this.callIds = [];
        this.errorsWithCallStack = [];
        if (this.fakes) {
          forEach(this.fakes, function(fake) {
            fake.resetHistory();
          });
        }
        return this;
      }
    };
    var delegateToCalls = proxyCallUtil.delegateToCalls;
    delegateToCalls(proxyApi, "calledOn", true);
    delegateToCalls(proxyApi, "alwaysCalledOn", false, "calledOn");
    delegateToCalls(proxyApi, "calledWith", true);
    delegateToCalls(
      proxyApi,
      "calledOnceWith",
      true,
      "calledWith",
      false,
      void 0,
      1
    );
    delegateToCalls(proxyApi, "calledWithMatch", true);
    delegateToCalls(proxyApi, "alwaysCalledWith", false, "calledWith");
    delegateToCalls(proxyApi, "alwaysCalledWithMatch", false, "calledWithMatch");
    delegateToCalls(proxyApi, "calledWithExactly", true);
    delegateToCalls(
      proxyApi,
      "calledOnceWithExactly",
      true,
      "calledWithExactly",
      false,
      void 0,
      1
    );
    delegateToCalls(
      proxyApi,
      "calledOnceWithMatch",
      true,
      "calledWithMatch",
      false,
      void 0,
      1
    );
    delegateToCalls(
      proxyApi,
      "alwaysCalledWithExactly",
      false,
      "calledWithExactly"
    );
    delegateToCalls(
      proxyApi,
      "neverCalledWith",
      false,
      "notCalledWith",
      false,
      function() {
        return true;
      }
    );
    delegateToCalls(
      proxyApi,
      "neverCalledWithMatch",
      false,
      "notCalledWithMatch",
      false,
      function() {
        return true;
      }
    );
    delegateToCalls(proxyApi, "threw", true);
    delegateToCalls(proxyApi, "alwaysThrew", false, "threw");
    delegateToCalls(proxyApi, "returned", true);
    delegateToCalls(proxyApi, "alwaysReturned", false, "returned");
    delegateToCalls(proxyApi, "calledWithNew", true);
    delegateToCalls(proxyApi, "alwaysCalledWithNew", false, "calledWithNew");
    function wrapFunction(func, originalFunc) {
      const arity = originalFunc.length;
      let p;
      switch (arity) {
        /*eslint-disable no-unused-vars*/
        case 0:
          p = function proxy() {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 1:
          p = function proxy(a) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 2:
          p = function proxy(a, b) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 3:
          p = function proxy(a, b, c) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 4:
          p = function proxy(a, b, c, d) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 5:
          p = function proxy(a, b, c, d, e) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 6:
          p = function proxy(a, b, c, d, e, f) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 7:
          p = function proxy(a, b, c, d, e, f, g) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 8:
          p = function proxy(a, b, c, d, e, f, g, h) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 9:
          p = function proxy(a, b, c, d, e, f, g, h, i) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 10:
          p = function proxy(a, b, c, d, e, f, g, h, i, j) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 11:
          p = function proxy(a, b, c, d, e, f, g, h, i, j, k) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        case 12:
          p = function proxy(a, b, c, d, e, f, g, h, i, j, k, l) {
            return p.invoke(func, this, slice(arguments));
          };
          break;
        default:
          p = function proxy() {
            return p.invoke(func, this, slice(arguments));
          };
          break;
      }
      const nameDescriptor = Object.getOwnPropertyDescriptor(
        originalFunc,
        "name"
      );
      if (nameDescriptor && nameDescriptor.configurable) {
        Object.defineProperty(p, "name", nameDescriptor);
      }
      extend.nonEnum(p, {
        isSinonProxy: true,
        called: false,
        notCalled: true,
        calledOnce: false,
        calledTwice: false,
        calledThrice: false,
        callCount: 0,
        firstCall: null,
        firstArg: null,
        secondCall: null,
        thirdCall: null,
        lastCall: null,
        lastArg: null,
        args: [],
        returnValues: [],
        thisValues: [],
        exceptions: [],
        callIds: [],
        errorsWithCallStack: []
      });
      return p;
    }
    function createProxy(func, originalFunc, context) {
      const proxy = wrapFunction(func, originalFunc);
      extend(proxy, func);
      proxy.prototype = func.prototype;
      extend.nonEnum(proxy, proxyApi);
      if (context) {
        extend.nonEnum(proxy, { sinonContext: context });
      }
      return proxy;
    }
    module2.exports = createProxy;
  }
});

// lib/sinon/util/core/is-non-existent-property.js
var require_is_non_existent_property = __commonJS({
  "lib/sinon/util/core/is-non-existent-property.js"(exports2, module2) {
    "use strict";
    function isNonExistentProperty(object, property) {
      return Boolean(
        object && typeof property !== "undefined" && !(property in object)
      );
    }
    module2.exports = isNonExistentProperty;
  }
});

// lib/sinon/util/core/is-es-module.js
var require_is_es_module = __commonJS({
  "lib/sinon/util/core/is-es-module.js"(exports2, module2) {
    "use strict";
    function isEsModule(object) {
      return object && typeof Symbol !== "undefined" && object[Symbol.toStringTag] === "Module" && Object.isSealed(object);
    }
    module2.exports = isEsModule;
  }
});

// lib/sinon/util/core/walk-object.js
var require_walk_object = __commonJS({
  "lib/sinon/util/core/walk-object.js"(exports2) {
    "use strict";
    var commons = require_lib();
    var getPropertyDescriptor = require_get_property_descriptor();
    var walk = require_walk();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { functionName } = commons__default.default;
    var applyMutations = function(mutator, object, filter) {
      let called = false;
      const name = functionName(mutator);
      if (!object) {
        throw new Error(
          `Trying to ${name} object but received ${String(object)}`
        );
      }
      walk(object, function(prop, propOwner) {
        if (propOwner !== Object.prototype && prop !== "constructor" && typeof getPropertyDescriptor(propOwner, prop).value === "function") {
          if (filter) {
            if (filter(object, prop)) {
              called = true;
              mutator(object, prop);
            }
          } else {
            called = true;
            mutator(object, prop);
          }
        }
      });
      return called;
    };
    var walkObject = function(mutator, object, filter) {
      applyMutations(mutator, object, filter);
      return object;
    };
    var walkObjectStrict = function(mutator, object, filter) {
      if (!applyMutations(mutator, object, filter)) {
        throw new Error(
          `Found no methods on object to which we could apply mutations`
        );
      }
      return object;
    };
    exports2.walkObject = walkObject;
    exports2.walkObjectStrict = walkObjectStrict;
  }
});

// lib/sinon/util/core/sinon-type.js
var require_sinon_type = __commonJS({
  "lib/sinon/util/core/sinon-type.js"(exports2, module2) {
    "use strict";
    var sinonTypeSymbolProperty = /* @__PURE__ */ Symbol("SinonType");
    var sinonType = {
      /**
       * Set the type of a Sinon object to make it possible to identify it later at runtime
       *
       * @param {object|((...args: unknown[]) => unknown)} object  object/function to set the type on
       * @param {string} type the named type of the object/function
       */
      set(object, type) {
        Object.defineProperty(object, sinonTypeSymbolProperty, {
          value: type,
          configurable: false,
          enumerable: false
        });
      },
      get(object) {
        return object && object[sinonTypeSymbolProperty];
      }
    };
    module2.exports = sinonType;
  }
});

// lib/sinon/util/core/wrap-method.js
var require_wrap_method = __commonJS({
  "lib/sinon/util/core/wrap-method.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var getPropertyDescriptor = require_get_property_descriptor();
    var extend = require_extend();
    var sinonType = require_sinon_type();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes, valueToString } = commons__default.default;
    var { hasOwnProperty } = prototypes.object;
    var { push } = prototypes.array;
    var noop = () => {
    };
    function isFunction(obj) {
      return typeof obj === "function" || Boolean(obj && obj.constructor && obj.call && obj.apply);
    }
    function mirrorProperties(target, source) {
      for (const prop in source) {
        if (!hasOwnProperty(target, prop)) {
          target[prop] = source[prop];
        }
      }
    }
    function getAccessor(object, property, method) {
      const accessors = ["get", "set"];
      const descriptor = getPropertyDescriptor(object, property);
      for (let i = 0; i < accessors.length; i++) {
        if (descriptor[accessors[i]] && descriptor[accessors[i]].name === method.name) {
          return accessors[i];
        }
      }
      return null;
    }
    var hasES5Support = "keys" in Object;
    function wrapMethod(object, property, method) {
      if (!object) {
        throw new TypeError("Should wrap property of object");
      }
      if (typeof method !== "function" && typeof method !== "object") {
        throw new TypeError(
          "Method wrapper should be a function or a property descriptor"
        );
      }
      function checkWrappedMethod(wrappedMethod2) {
        let error2;
        if (!isFunction(wrappedMethod2)) {
          error2 = new TypeError(
            `Attempted to wrap ${typeof wrappedMethod2} property ${valueToString(
              property
            )} as function`
          );
        } else if (wrappedMethod2.restore && wrappedMethod2.restore.sinon) {
          error2 = new TypeError(
            `Attempted to wrap ${valueToString(
              property
            )} which is already wrapped`
          );
        } else if (wrappedMethod2.calledBefore) {
          const verb = wrappedMethod2.returns ? "stubbed" : "spied on";
          error2 = new TypeError(
            `Attempted to wrap ${valueToString(
              property
            )} which is already ${verb}`
          );
        }
        if (error2) {
          if (wrappedMethod2 && wrappedMethod2.stackTraceError) {
            error2.stack += `
--------------
${wrappedMethod2.stackTraceError.stack}`;
          }
          throw error2;
        }
      }
      let error, wrappedMethod, i, wrappedMethodDesc, target, accessor;
      const wrappedMethods = [];
      function simplePropertyAssignment() {
        wrappedMethod = object[property];
        checkWrappedMethod(wrappedMethod);
        object[property] = method;
        method.displayName = property;
      }
      const owned = object.hasOwnProperty ? object.hasOwnProperty(property) : hasOwnProperty(object, property);
      if (hasES5Support) {
        const methodDesc = typeof method === "function" ? { value: method } : method;
        wrappedMethodDesc = getPropertyDescriptor(object, property);
        if (!wrappedMethodDesc) {
          error = new TypeError(
            `Attempted to wrap ${typeof wrappedMethod} property ${property} as function`
          );
        } else if (wrappedMethodDesc.restore && wrappedMethodDesc.restore.sinon) {
          error = new TypeError(
            `Attempted to wrap ${property} which is already wrapped`
          );
        }
        if (error) {
          if (wrappedMethodDesc && wrappedMethodDesc.stackTraceError) {
            error.stack += `
--------------
${wrappedMethodDesc.stackTraceError.stack}`;
          }
          throw error;
        }
        const types = Object.keys(methodDesc);
        for (i = 0; i < types.length; i++) {
          wrappedMethod = wrappedMethodDesc[types[i]];
          checkWrappedMethod(wrappedMethod);
          push(wrappedMethods, wrappedMethod);
        }
        mirrorProperties(methodDesc, wrappedMethodDesc);
        for (i = 0; i < types.length; i++) {
          mirrorProperties(methodDesc[types[i]], wrappedMethodDesc[types[i]]);
        }
        if (!owned) {
          methodDesc.configurable = true;
        }
        Object.defineProperty(object, property, methodDesc);
        if (typeof method === "function" && object[property] !== method) {
          delete object[property];
          simplePropertyAssignment();
        }
      } else {
        simplePropertyAssignment();
      }
      function restore() {
        accessor = getAccessor(object, property, this.wrappedMethod);
        let descriptor;
        if (accessor) {
          if (!owned) {
            try {
              delete object[property][accessor];
            } catch (e) {
            }
          } else if (hasES5Support) {
            descriptor = getPropertyDescriptor(object, property);
            descriptor[accessor] = wrappedMethodDesc[accessor];
            Object.defineProperty(object, property, descriptor);
          }
          if (hasES5Support) {
            descriptor = getPropertyDescriptor(object, property);
            if (descriptor && descriptor.value === target) {
              object[property][accessor] = this.wrappedMethod;
            }
          } else {
            if (object[property][accessor] === target) {
              object[property][accessor] = this.wrappedMethod;
            }
          }
        } else {
          if (!owned) {
            try {
              delete object[property];
            } catch (e) {
            }
          } else if (hasES5Support) {
            Object.defineProperty(object, property, wrappedMethodDesc);
          }
          if (hasES5Support) {
            descriptor = getPropertyDescriptor(object, property);
            if (descriptor && descriptor.value === target) {
              object[property] = this.wrappedMethod;
            }
          } else {
            if (object[property] === target) {
              object[property] = this.wrappedMethod;
            }
          }
        }
        if (sinonType.get(object) === "stub-instance") {
          object[property] = noop;
        }
      }
      function extendObjectWithWrappedMethods() {
        for (i = 0; i < wrappedMethods.length; i++) {
          accessor = getAccessor(object, property, wrappedMethods[i]);
          target = accessor ? method[accessor] : method;
          extend.nonEnum(target, {
            displayName: property,
            wrappedMethod: wrappedMethods[i],
            // Set up an Error object for a stack trace which can be used later to find what line of
            // code the original method was created on.
            stackTraceError: new Error("Stack Trace for original"),
            restore
          });
          target.restore.sinon = true;
          if (!hasES5Support) {
            mirrorProperties(target, wrappedMethod);
          }
        }
      }
      extendObjectWithWrappedMethods();
      return method;
    }
    module2.exports = wrapMethod;
  }
});

// lib/sinon/spy.js
var require_spy = __commonJS({
  "lib/sinon/spy.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var samsam = require_samsam();
    var proxy = require_proxy();
    var extend = require_extend();
    var getPropertyDescriptor = require_get_property_descriptor();
    var isEsModule = require_is_es_module();
    var proxyCallUtil = require_proxy_call_util();
    var walkObject = require_walk_object();
    var wrapMethod = require_wrap_method();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var { prototypes, functionName, valueToString } = commons__default.default;
    var { deepEqual } = samsam__default.default;
    var { forEach, pop, push, slice } = prototypes.array;
    var filter = Array.prototype.filter;
    var uuid = 0;
    function matches(fake, args, strict) {
      const margs = fake.matchingArguments;
      if (margs.length <= args.length && deepEqual(slice(args, 0, margs.length), margs)) {
        return !strict || margs.length === args.length;
      }
      return false;
    }
    var spyApi = {
      withArgs: function() {
        const args = slice(arguments);
        const matching = pop(this.matchingFakes(args, true));
        if (matching) {
          return matching;
        }
        const original = this;
        const fakeInstance = this.instantiateFake();
        fakeInstance.matchingArguments = args;
        fakeInstance.parent = this;
        push(this.fakes, fakeInstance);
        fakeInstance.withArgs = function() {
          return original.withArgs.apply(original, arguments);
        };
        forEach(original.args, function(arg, i) {
          if (!matches(fakeInstance, arg)) {
            return;
          }
          proxyCallUtil.incrementCallCount(fakeInstance);
          push(fakeInstance.thisValues, original.thisValues[i]);
          push(fakeInstance.args, arg);
          push(fakeInstance.returnValues, original.returnValues[i]);
          push(fakeInstance.exceptions, original.exceptions[i]);
          push(fakeInstance.callIds, original.callIds[i]);
        });
        proxyCallUtil.createCallProperties(fakeInstance);
        return fakeInstance;
      },
      // Override proxy default implementation
      matchingFakes: function(args, strict) {
        return filter.call(this.fakes, function(fakeInstance) {
          return matches(fakeInstance, args, strict);
        });
      }
    };
    var delegateToCalls = proxyCallUtil.delegateToCalls;
    delegateToCalls(spyApi, "callArg", false, "callArgWith", true, function() {
      throw new Error(
        `${this.toString()} cannot call arg since it was not yet invoked.`
      );
    });
    spyApi.callArgWith = spyApi.callArg;
    delegateToCalls(spyApi, "callArgOn", false, "callArgOnWith", true, function() {
      throw new Error(
        `${this.toString()} cannot call arg since it was not yet invoked.`
      );
    });
    spyApi.callArgOnWith = spyApi.callArgOn;
    delegateToCalls(spyApi, "throwArg", false, "throwArg", false, function() {
      throw new Error(
        `${this.toString()} cannot throw arg since it was not yet invoked.`
      );
    });
    delegateToCalls(spyApi, "yield", false, "yield", true, function() {
      throw new Error(
        `${this.toString()} cannot yield since it was not yet invoked.`
      );
    });
    spyApi.invokeCallback = spyApi.yield;
    delegateToCalls(spyApi, "yieldOn", false, "yieldOn", true, function() {
      throw new Error(
        `${this.toString()} cannot yield since it was not yet invoked.`
      );
    });
    delegateToCalls(spyApi, "yieldTo", false, "yieldTo", true, function(property) {
      throw new Error(
        `${this.toString()} cannot yield to '${valueToString(
          property
        )}' since it was not yet invoked.`
      );
    });
    delegateToCalls(
      spyApi,
      "yieldToOn",
      false,
      "yieldToOn",
      true,
      function(property) {
        throw new Error(
          `${this.toString()} cannot yield to '${valueToString(
            property
          )}' since it was not yet invoked.`
        );
      }
    );
    function createSpy(func, context) {
      let name;
      let funk = func;
      if (typeof funk !== "function") {
        funk = function() {
          return;
        };
      } else {
        name = functionName(funk);
      }
      const proxy$1 = proxy(funk, funk, context);
      const instantiateFake = function(f) {
        return createSpy(f, context);
      };
      extend.nonEnum(proxy$1, spyApi);
      extend.nonEnum(proxy$1, {
        displayName: name || "spy",
        fakes: [],
        instantiateFake,
        id: `spy#${uuid++}`
      });
      return proxy$1;
    }
    function spyImpl(object, property, types, context) {
      if (isEsModule(object)) {
        throw new TypeError("ES Modules cannot be spied");
      }
      if (!property && typeof object === "function") {
        return createSpy(object, context);
      }
      if (!property && typeof object === "object") {
        return walkObject.walkObjectStrict(function(obj, prop, propTypes) {
          return spyImpl(obj, prop, propTypes, context);
        }, object);
      }
      if (!object && !property) {
        return createSpy(function() {
          return;
        }, context);
      }
      if (!types) {
        return wrapMethod(
          object,
          property,
          createSpy(object[property], context)
        );
      }
      const descriptor = {};
      const methodDesc = getPropertyDescriptor(object, property);
      forEach(types, function(type) {
        descriptor[type] = createSpy(methodDesc[type], context);
      });
      return wrapMethod(object, property, descriptor);
    }
    function spy(object, property, types) {
      return spyImpl(object, property, types, void 0);
    }
    spy.withContext = function(context, object, property, types) {
      return spyImpl(object, property, types, context);
    };
    extend(spy, spyApi);
    module2.exports = spy;
  }
});

// lib/sinon/throw-on-falsy-object.js
var require_throw_on_falsy_object = __commonJS({
  "lib/sinon/throw-on-falsy-object.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { valueToString } = commons__default.default;
    function throwOnFalsyObject(object, property) {
      if (property && !object) {
        const type = object === null ? "null" : "undefined";
        throw new Error(
          `Trying to stub property '${valueToString(property)}' of ${type}`
        );
      }
    }
    module2.exports = throwOnFalsyObject;
  }
});

// lib/sinon/stub.js
var require_stub = __commonJS({
  "lib/sinon/stub.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var behavior = require_behavior();
    var defaultBehaviors = require_default_behaviors();
    var proxy = require_proxy();
    var isNonExistentProperty = require_is_non_existent_property();
    var spy = require_spy();
    var extend = require_extend();
    var getPropertyDescriptor = require_get_property_descriptor();
    var isEsModule = require_is_es_module();
    var sinonType = require_sinon_type();
    var wrapMethod = require_wrap_method();
    var throwOnFalsyObject = require_throw_on_falsy_object();
    var walkObject = require_walk_object();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes: commonsPrototypes, functionName, valueToString } = commons__default.default;
    var { array: arrayProto, object: objectProto } = commonsPrototypes;
    var { hasOwnProperty } = objectProto;
    var forEach = arrayProto.forEach;
    var pop = arrayProto.pop;
    var slice = arrayProto.slice;
    var sort = arrayProto.sort;
    var uuid = 0;
    function createStub(originalFunc, context) {
      let proxy$1;
      function functionStub() {
        const args = slice(arguments);
        const matchings = proxy$1.matchingFakes(args);
        const fnStub = pop(
          sort(matchings, function(a, b) {
            return a.matchingArguments.length - b.matchingArguments.length;
          })
        ) || proxy$1;
        return getCurrentBehavior(fnStub).invoke(this, arguments);
      }
      proxy$1 = proxy(functionStub, originalFunc || functionStub, context);
      extend.nonEnum(proxy$1, spy);
      extend.nonEnum(proxy$1, stub);
      const instantiateFake = function(f) {
        return createStub(f, context);
      };
      const name = originalFunc ? functionName(originalFunc) : null;
      extend.nonEnum(proxy$1, {
        fakes: [],
        instantiateFake,
        displayName: name || "stub",
        defaultBehavior: null,
        behaviors: [],
        id: `stub#${uuid++}`
      });
      sinonType.set(proxy$1, "stub");
      return proxy$1;
    }
    function stubImpl(object, property, context) {
      if (isEsModule(object)) {
        throw new TypeError("ES Modules cannot be stubbed");
      }
      throwOnFalsyObject(object, property);
      if (isNonExistentProperty(object, property)) {
        throw new TypeError(
          `Cannot stub non-existent property ${valueToString(property)}`
        );
      }
      const actualDescriptor = getPropertyDescriptor(object, property);
      assertValidPropertyDescriptor(actualDescriptor, property);
      const isObjectOrFunction = typeof object === "object" || typeof object === "function";
      const isStubbingEntireObject = typeof property === "undefined" && isObjectOrFunction;
      const isCreatingNewStub = !object && typeof property === "undefined";
      const isStubbingNonFuncProperty = isObjectOrFunction && typeof property !== "undefined" && (typeof actualDescriptor === "undefined" || typeof actualDescriptor.value !== "function");
      if (isStubbingEntireObject) {
        return walkObject.walkObjectStrict(function(obj, prop) {
          return stubImpl(obj, prop, context);
        }, object);
      }
      if (isCreatingNewStub) {
        return createStub(void 0, context);
      }
      const func = typeof actualDescriptor.value === "function" ? actualDescriptor.value : null;
      const s = createStub(func, context);
      extend.nonEnum(s, {
        rootObj: object,
        propName: property,
        shadowsPropOnPrototype: !actualDescriptor.isOwn,
        restore: function restore() {
          if (actualDescriptor !== void 0 && actualDescriptor.isOwn) {
            Object.defineProperty(object, property, actualDescriptor);
            return;
          }
          delete object[property];
        }
      });
      return isStubbingNonFuncProperty ? s : wrapMethod(object, property, s);
    }
    function stub(object, property) {
      if (arguments.length > 2) {
        throw new TypeError(
          "stub(obj, 'meth', fn) has been removed, see documentation"
        );
      }
      return stubImpl(object, property, void 0);
    }
    stub.withContext = function(context, object, property) {
      return stubImpl(object, property, context);
    };
    function assertValidPropertyDescriptor(descriptor, property) {
      if (!descriptor || !property) {
        return;
      }
      if (descriptor.isOwn && !descriptor.configurable && !descriptor.writable) {
        throw new TypeError(
          `The descriptor for property \`${property}\` is non-configurable and non-writable. Sinon cannot stub properties that are immutable. See https://sinonjs.org/faq#property-descriptor-errors for help fixing this issue.`
        );
      }
      if ((descriptor.get || descriptor.set) && !descriptor.configurable) {
        throw new TypeError(
          `Descriptor for accessor property ${property} is non-configurable`
        );
      }
      if (isDataDescriptor(descriptor) && !descriptor.writable) {
        throw new TypeError(
          `Descriptor for data property ${property} is non-writable`
        );
      }
    }
    function isDataDescriptor(descriptor) {
      return !descriptor.value && !descriptor.writable && !descriptor.set && !descriptor.get;
    }
    function getParentBehaviour(stubInstance) {
      return stubInstance.parent && getCurrentBehavior(stubInstance.parent);
    }
    function getDefaultBehavior(stubInstance) {
      return stubInstance.defaultBehavior || getParentBehaviour(stubInstance) || behavior.create(stubInstance);
    }
    function getCurrentBehavior(stubInstance) {
      const currentBehavior = stubInstance.behaviors[stubInstance.callCount - 1];
      return currentBehavior && currentBehavior.isPresent() ? currentBehavior : getDefaultBehavior(stubInstance);
    }
    var proto = {
      resetBehavior: function() {
        this.defaultBehavior = null;
        this.behaviors = [];
        delete this.returnValue;
        delete this.returnArgAt;
        delete this.throwArgAt;
        delete this.resolveArgAt;
        delete this.fakeFn;
        this.returnThis = false;
        this.resolveThis = false;
        forEach(this.fakes, function(fake) {
          fake.resetBehavior();
        });
      },
      reset: function() {
        this.resetHistory();
        this.resetBehavior();
      },
      onCall: function onCall(index) {
        if (!this.behaviors[index]) {
          this.behaviors[index] = behavior.create(this);
        }
        return this.behaviors[index];
      },
      onFirstCall: function onFirstCall() {
        return this.onCall(0);
      },
      onSecondCall: function onSecondCall() {
        return this.onCall(1);
      },
      onThirdCall: function onThirdCall() {
        return this.onCall(2);
      },
      withArgs: function withArgs() {
        const fake = spy.withArgs.apply(this, arguments);
        if (this.defaultBehavior && this.defaultBehavior.promiseLibrary) {
          fake.defaultBehavior = fake.defaultBehavior || behavior.create(fake);
          fake.defaultBehavior.promiseLibrary = this.defaultBehavior.promiseLibrary;
        }
        return fake;
      }
    };
    forEach(Object.keys(behavior), function(method) {
      if (hasOwnProperty(behavior, method) && !hasOwnProperty(proto, method) && method !== "create" && method !== "invoke") {
        proto[method] = behavior.createBehavior(method);
      }
    });
    forEach(Object.keys(defaultBehaviors), function(method) {
      if (hasOwnProperty(defaultBehaviors, method) && !hasOwnProperty(proto, method)) {
        behavior.addBehavior(stub, method, defaultBehaviors[method]);
      }
    });
    extend(stub, proto);
    module2.exports = stub;
  }
});

// lib/sinon/mock-expectation.js
var require_mock_expectation = __commonJS({
  "lib/sinon/mock-expectation.js"(exports2, module2) {
    "use strict";
    var util = require_util();
    var commons = require_lib();
    var samsam = require_samsam();
    var proxyInvoke = require_proxy_invoke();
    var proxyCall = require_proxy_call();
    var timesInWords = require_times_in_words();
    var extend = require_extend();
    var stub = require_stub();
    var assert = require_assert();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var { prototypes: commonsPrototypes, valueToString } = commons__default.default;
    var { array: arrayProto } = commonsPrototypes;
    var { createMatcher: match, deepEqual } = samsam__default.default;
    var every = arrayProto.every;
    var forEach = arrayProto.forEach;
    var push = arrayProto.push;
    var slice = arrayProto.slice;
    function callCountInWords(callCount) {
      if (callCount === 0) {
        return "never called";
      }
      return `called ${timesInWords(callCount)}`;
    }
    function expectedCallCountInWords(expectation) {
      const min = expectation.minCalls;
      const max = expectation.maxCalls;
      if (typeof min === "number" && typeof max === "number") {
        let str = timesInWords(min);
        if (min !== max) {
          str = `at least ${str} and at most ${timesInWords(max)}`;
        }
        return str;
      }
      if (typeof min === "number") {
        return `at least ${timesInWords(min)}`;
      }
      return `at most ${timesInWords(max)}`;
    }
    function receivedMinCalls(expectation) {
      const hasMinLimit = typeof expectation.minCalls === "number";
      return !hasMinLimit || expectation.callCount >= expectation.minCalls;
    }
    function receivedMaxCalls(expectation) {
      if (typeof expectation.maxCalls !== "number") {
        return false;
      }
      return expectation.callCount === expectation.maxCalls;
    }
    function verifyMatcher(possibleMatcher, arg) {
      const isMatcher = match.isMatcher(possibleMatcher);
      return isMatcher && possibleMatcher.test(arg) || true;
    }
    var mockExpectation = {
      minCalls: 1,
      maxCalls: 1,
      create: function create(methodName) {
        const expectation = extend.nonEnum(stub(), mockExpectation);
        delete expectation.create;
        expectation.method = methodName;
        return expectation;
      },
      invoke: function invoke(func, thisValue, args) {
        this.verifyCallAllowed(thisValue, args);
        return proxyInvoke.apply(this, arguments);
      },
      atLeast: function atLeast(num) {
        if (typeof num !== "number") {
          throw new TypeError(`'${valueToString(num)}' is not number`);
        }
        if (!this.limitsSet) {
          this.maxCalls = null;
          this.limitsSet = true;
        }
        this.minCalls = num;
        return this;
      },
      atMost: function atMost(num) {
        if (typeof num !== "number") {
          throw new TypeError(`'${valueToString(num)}' is not number`);
        }
        if (!this.limitsSet) {
          this.minCalls = null;
          this.limitsSet = true;
        }
        this.maxCalls = num;
        return this;
      },
      never: function never() {
        return this.exactly(0);
      },
      once: function once() {
        return this.exactly(1);
      },
      twice: function twice() {
        return this.exactly(2);
      },
      thrice: function thrice() {
        return this.exactly(3);
      },
      exactly: function exactly(num) {
        if (typeof num !== "number") {
          throw new TypeError(`'${valueToString(num)}' is not a number`);
        }
        this.atLeast(num);
        return this.atMost(num);
      },
      met: function met() {
        return !this.failed && receivedMinCalls(this);
      },
      verifyCallAllowed: function verifyCallAllowed(thisValue, args) {
        const expectedArguments = this.expectedArguments;
        if (receivedMaxCalls(this)) {
          this.failed = true;
          mockExpectation.fail(
            `${this.method} already called ${timesInWords(this.maxCalls)}`
          );
        }
        if ("expectedThis" in this && this.expectedThis !== thisValue) {
          mockExpectation.fail(
            `${this.method} called with ${valueToString(
              thisValue
            )} as thisValue, expected ${valueToString(this.expectedThis)}`
          );
        }
        if (!("expectedArguments" in this)) {
          return;
        }
        if (!args) {
          mockExpectation.fail(
            `${this.method} received no arguments, expected ${util.inspect(
              expectedArguments
            )}`
          );
        }
        if (args.length < expectedArguments.length) {
          mockExpectation.fail(
            `${this.method} received too few arguments (${util.inspect(
              args
            )}), expected ${util.inspect(expectedArguments)}`
          );
        }
        if (this.expectsExactArgCount && args.length !== expectedArguments.length) {
          mockExpectation.fail(
            `${this.method} received too many arguments (${util.inspect(
              args
            )}), expected ${util.inspect(expectedArguments)}`
          );
        }
        forEach(
          expectedArguments,
          function(expectedArgument, i) {
            if (!verifyMatcher(expectedArgument, args[i])) ;
            if (!deepEqual(args[i], expectedArgument)) {
              mockExpectation.fail(
                `${this.method} received wrong arguments ${util.inspect(
                  args
                )}, expected ${util.inspect(expectedArguments)}`
              );
            }
          },
          this
        );
      },
      allowsCall: function allowsCall(thisValue, args) {
        const expectedArguments = this.expectedArguments;
        if (this.met() && receivedMaxCalls(this)) {
          return false;
        }
        if ("expectedThis" in this && this.expectedThis !== thisValue) {
          return false;
        }
        if (!("expectedArguments" in this)) {
          return true;
        }
        const _args = args || [];
        if (_args.length < expectedArguments.length) {
          return false;
        }
        if (this.expectsExactArgCount && _args.length !== expectedArguments.length) {
          return false;
        }
        return every(expectedArguments, function(expectedArgument, i) {
          if (!verifyMatcher(expectedArgument, _args[i])) ;
          if (!deepEqual(_args[i], expectedArgument)) {
            return false;
          }
          return true;
        });
      },
      withArgs: function withArgs() {
        this.expectedArguments = slice(arguments);
        return this;
      },
      withExactArgs: function withExactArgs() {
        this.withArgs.apply(this, arguments);
        this.expectsExactArgCount = true;
        return this;
      },
      on: function on(thisValue) {
        this.expectedThis = thisValue;
        return this;
      },
      toString: function() {
        const args = slice(this.expectedArguments || []);
        if (!this.expectsExactArgCount) {
          push(args, "[...]");
        }
        const callStr = proxyCall.toString.call({
          proxy: this.method || "anonymous mock expectation",
          args
        });
        const message = `${callStr.replace(
          ", [...",
          "[, ..."
        )} ${expectedCallCountInWords(this)}`;
        if (this.met()) {
          return `Expectation met: ${message}`;
        }
        return `Expected ${message} (${callCountInWords(this.callCount)})`;
      },
      verify: function verify() {
        if (!this.met()) {
          mockExpectation.fail(String(this));
        } else {
          mockExpectation.pass(String(this));
        }
        return true;
      },
      pass: function pass(message) {
        assert.pass(message);
      },
      fail: function fail(message) {
        const exception = new Error(message);
        exception.name = "ExpectationError";
        throw exception;
      }
    };
    module2.exports = mockExpectation;
  }
});

// lib/sinon/mock.js
var require_mock = __commonJS({
  "lib/sinon/mock.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var mockExpectation = require_mock_expectation();
    var proxyCall = require_proxy_call();
    var extend = require_extend();
    var samsam = require_samsam();
    var wrapMethod = require_wrap_method();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var { prototypes } = commons__default.default;
    var { deepEqual } = samsam__default.default;
    var { concat, filter, forEach, every, join, push, slice, unshift } = prototypes.array;
    function mock(object) {
      if (!object || typeof object === "string") {
        return mockExpectation.create(object ? object : "Anonymous mock");
      }
      return mock.create(object);
    }
    function each(collection, callback) {
      const col = collection || [];
      forEach(col, callback);
    }
    function arrayEquals(arr1, arr2, compareLength) {
      if (compareLength && arr1.length !== arr2.length) {
        return false;
      }
      return every(arr1, function(element, i) {
        return deepEqual(arr2[i], element);
      });
    }
    extend(mock, {
      create: function create(object) {
        if (!object) {
          throw new TypeError("object is null");
        }
        const mockObject = extend.nonEnum({}, mock, { object });
        delete mockObject.create;
        return mockObject;
      },
      expects: function expects(method) {
        if (!method) {
          throw new TypeError("method is falsy");
        }
        if (!this.expectations) {
          this.expectations = {};
          this.proxies = [];
          this.failures = [];
        }
        if (!this.expectations[method]) {
          this.expectations[method] = [];
          const mockObject = this;
          wrapMethod(this.object, method, function() {
            return mockObject.invokeMethod(method, this, arguments);
          });
          push(this.proxies, method);
        }
        const expectation = mockExpectation.create(method);
        expectation.wrappedMethod = this.object[method].wrappedMethod;
        push(this.expectations[method], expectation);
        return expectation;
      },
      restore: function restore() {
        const object = this.object;
        each(this.proxies, function(proxy) {
          if (typeof object[proxy].restore === "function") {
            object[proxy].restore();
          }
        });
      },
      verify: function verify() {
        const expectations = this.expectations || {};
        const messages = this.failures ? slice(this.failures) : [];
        const met = [];
        each(this.proxies, function(proxy) {
          each(expectations[proxy], function(expectation) {
            if (!expectation.met()) {
              push(messages, String(expectation));
            } else {
              push(met, String(expectation));
            }
          });
        });
        this.restore();
        if (messages.length > 0) {
          mockExpectation.fail(join(concat(messages, met), "\n"));
        } else if (met.length > 0) {
          mockExpectation.pass(join(concat(messages, met), "\n"));
        }
        return true;
      },
      invokeMethod: function invokeMethod(method, thisValue, args) {
        const expectations = this.expectations && this.expectations[method] ? this.expectations[method] : [];
        const currentArgs = args || [];
        let available;
        const expectationsWithMatchingArgs = filter(
          expectations,
          function(expectation) {
            const expectedArgs = expectation.expectedArguments || [];
            return arrayEquals(
              expectedArgs,
              currentArgs,
              expectation.expectsExactArgCount
            );
          }
        );
        const expectationsToApply = filter(
          expectationsWithMatchingArgs,
          function(expectation) {
            return !expectation.met() && expectation.allowsCall(thisValue, args);
          }
        );
        if (expectationsToApply.length > 0) {
          return expectationsToApply[0].apply(thisValue, args);
        }
        const messages = [];
        let exhausted = 0;
        forEach(expectationsWithMatchingArgs, function(expectation) {
          if (expectation.allowsCall(thisValue, args)) {
            available = available || expectation;
          } else {
            exhausted += 1;
          }
        });
        if (available && exhausted === 0) {
          return available.apply(thisValue, args);
        }
        forEach(expectations, function(expectation) {
          push(messages, `    ${String(expectation)}`);
        });
        unshift(
          messages,
          `Unexpected call: ${proxyCall.toString.call({
            proxy: method,
            args
          })}`
        );
        const err = new Error();
        if (!err.stack) {
          try {
            throw err;
          } catch (e) {
          }
        }
        push(
          this.failures,
          `Unexpected call: ${proxyCall.toString.call({
            proxy: method,
            args,
            stack: err.stack
          })}`
        );
        mockExpectation.fail(join(messages, "\n"));
      }
    });
    module2.exports = mock;
  }
});

// lib/sinon/create-stub-instance.js
var require_create_stub_instance = __commonJS({
  "lib/sinon/create-stub-instance.js"(exports2, module2) {
    "use strict";
    var stub = require_stub();
    var sinonType = require_sinon_type();
    var commons = require_lib();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { forEach } = prototypes.array;
    function isStub(value) {
      return sinonType.get(value) === "stub";
    }
    function createStubInstance(constructor, overrides) {
      if (typeof constructor !== "function") {
        throw new TypeError("The constructor should be a function.");
      }
      const stubInstance = Object.create(constructor.prototype);
      sinonType.set(stubInstance, "stub-instance");
      const stubbedObject = stub(stubInstance);
      forEach(Object.keys(overrides || {}), function(propertyName) {
        if (propertyName in stubbedObject) {
          const value = overrides[propertyName];
          if (isStub(value)) {
            stubbedObject[propertyName] = value;
          } else {
            stubbedObject[propertyName].returns(value);
          }
        } else {
          throw new Error(
            `Cannot stub ${propertyName}. Property does not exist!`
          );
        }
      });
      return stubbedObject;
    }
    module2.exports = createStubInstance;
  }
});

// lib/sinon/fake.js
var require_fake = __commonJS({
  "lib/sinon/fake.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var proxy = require_proxy();
    var nextTick = require_next_tick();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { prototypes } = commons__default.default;
    var { slice } = prototypes.array;
    function fakeImpl(f, context, hasFunctionArgument) {
      if (hasFunctionArgument && typeof f !== "function") {
        throw new TypeError("Expected f argument to be a Function");
      }
      return wrapFunc(f, context);
    }
    function fake(f) {
      return fakeImpl(f, void 0, arguments.length > 0);
    }
    fake.withContext = function(context, f) {
      return fakeImpl(f, context, arguments.length > 1);
    };
    fake.returns = function returns(value, context) {
      function f() {
        return value;
      }
      return wrapFunc(f, context);
    };
    fake.throws = function throws(value, context) {
      function f() {
        throw getError(value);
      }
      return wrapFunc(f, context);
    };
    fake.resolves = function resolves(value, context) {
      function f() {
        return Promise.resolve(value);
      }
      return wrapFunc(f, context);
    };
    fake.rejects = function rejects(value, context) {
      function f() {
        return Promise.reject(getError(value));
      }
      return wrapFunc(f, context);
    };
    fake.yields = function yields() {
      const values = slice(arguments);
      function f() {
        const callback = arguments[arguments.length - 1];
        if (typeof callback !== "function") {
          throw new TypeError("Expected last argument to be a function");
        }
        callback.apply(null, values);
      }
      return wrapFunc(f);
    };
    fake.yieldsAsync = function yieldsAsync() {
      const values = slice(arguments);
      function f() {
        const callback = arguments[arguments.length - 1];
        if (typeof callback !== "function") {
          throw new TypeError("Expected last argument to be a function");
        }
        nextTick(function() {
          callback.apply(null, values);
        });
      }
      return wrapFunc(f);
    };
    var uuid = 0;
    function wrapFunc(f, context) {
      const fakeInstance = function() {
        let firstArg, lastArg;
        if (arguments.length > 0) {
          firstArg = arguments[0];
          lastArg = arguments[arguments.length - 1];
        }
        const callback = lastArg && typeof lastArg === "function" ? lastArg : void 0;
        proxy$1.firstArg = firstArg;
        proxy$1.lastArg = lastArg;
        proxy$1.callback = callback;
        return f && f.apply(this, arguments);
      };
      const proxy$1 = proxy(fakeInstance, f || fakeInstance, context);
      Object.defineProperty(proxy$1, "name", {
        value: "fake",
        configurable: true
      });
      proxy$1.displayName = "fake";
      proxy$1.id = `fake#${uuid++}`;
      return proxy$1;
    }
    function getError(value) {
      return value instanceof Error ? value : new Error(value);
    }
    module2.exports = fake;
  }
});

// lib/sinon/sandbox.js
var require_sandbox = __commonJS({
  "lib/sinon/sandbox.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var samsam = require_samsam();
    var collectOwnMethods = require_collect_own_methods();
    var getPropertyDescriptor = require_get_property_descriptor();
    var assert = require_assert();
    var fakeTimers = require_fake_timers();
    var mock = require_mock();
    var spy = require_spy();
    var stub = require_stub();
    var createStubInstance = require_create_stub_instance();
    var fake = require_fake();
    var extend = require_extend();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    var { array: arrayProto } = commons__default.default.prototypes;
    var { deprecated: logger, valueToString } = commons__default.default;
    var { createMatcher: match } = samsam__default.default;
    var DEFAULT_LEAK_THRESHOLD = 1e4;
    var filter = arrayProto.filter;
    var forEach = arrayProto.forEach;
    var push = arrayProto.push;
    var reverse = arrayProto.reverse;
    function applyOnEach(fakes, method) {
      const matchingFakes = filter(fakes, function(fake2) {
        return typeof fake2[method] === "function";
      });
      forEach(matchingFakes, function(fake2) {
        fake2[method]();
      });
    }
    function throwOnAccessors(descriptor) {
      if (typeof descriptor.get === "function") {
        throw new Error("Use sandbox.replaceGetter for replacing getters");
      }
      if (typeof descriptor.set === "function") {
        throw new Error("Use sandbox.replaceSetter for replacing setters");
      }
    }
    function verifySameType(object, property, replacement) {
      const original = object[property];
      const originalType = typeof original;
      const replacementType = typeof replacement;
      if (originalType !== replacementType) {
        throw new TypeError(
          `Cannot replace ${originalType} with ${replacementType}`
        );
      }
    }
    function checkForValidArguments(descriptor, property, replacement) {
      if (typeof descriptor === "undefined") {
        throw new TypeError(
          `Cannot replace non-existent property ${valueToString(
            property
          )}. Perhaps you meant sandbox.define()?`
        );
      }
      if (typeof replacement === "undefined") {
        throw new TypeError("Expected replacement argument to be defined");
      }
    }
    function Sandbox(opts = {}) {
      const sandbox = this;
      const assertOptions = opts.assertOptions || {};
      const fakeRestorers = [];
      let collection = [];
      let loggedLeakWarning = false;
      sandbox.leakThreshold = DEFAULT_LEAK_THRESHOLD;
      const sandboxContext = { callId: 0 };
      function addToCollection(object) {
        if (push(collection, object) > sandbox.leakThreshold && !loggedLeakWarning) {
          logger.printWarning(
            `Sinon sandbox: The number of fakes in the sandbox has exceeded the leak threshold of ${sandbox.leakThreshold}. To avoid memory leaks, ensure you are restoring the sandbox after each test. To disable this warning, modify the leakThreshold property of your sandbox.`
          );
          loggedLeakWarning = true;
        }
      }
      sandbox.assert = assert.createAssertObject(assertOptions);
      sandbox.getFakes = function getFakes() {
        return collection;
      };
      sandbox.createStubInstance = function createStubInstance$1() {
        const stubbed = createStubInstance.apply(null, arguments);
        const ownMethods = collectOwnMethods(stubbed);
        forEach(ownMethods, function(method) {
          addToCollection(method);
        });
        return stubbed;
      };
      sandbox.inject = function inject(obj) {
        obj.spy = function spy2() {
          return sandbox.spy.apply(null, arguments);
        };
        obj.stub = function stub2() {
          return sandbox.stub.apply(null, arguments);
        };
        obj.mock = function mock2() {
          return sandbox.mock.apply(null, arguments);
        };
        obj.createStubInstance = function createStubInstanceWrapper() {
          return sandbox.createStubInstance.apply(sandbox, arguments);
        };
        obj.fake = function fake2() {
          return sandbox.fake.apply(null, arguments);
        };
        obj.define = function define2() {
          return sandbox.define.apply(null, arguments);
        };
        obj.replace = function replace() {
          return sandbox.replace.apply(null, arguments);
        };
        obj.replaceSetter = function replaceSetter() {
          return sandbox.replaceSetter.apply(null, arguments);
        };
        obj.replaceGetter = function replaceGetter() {
          return sandbox.replaceGetter.apply(null, arguments);
        };
        if (sandbox.clock) {
          obj.clock = sandbox.clock;
        }
        obj.match = match;
        return obj;
      };
      function commonPostInitSetup(args, spy2, isStub, shouldAddToCollection = true) {
        if (isStub && args.length >= 3) {
          throw new TypeError(
            "stub(obj, 'meth', fn) has been removed, see documentation"
          );
        }
        if (shouldAddToCollection) {
          addToCollection(spy2);
        }
        return spy2;
      }
      function addReturnedMethodsToCollection(result) {
        if (result && (typeof result === "object" || typeof result === "function")) {
          forEach(collectOwnMethods(result), addToCollection);
        }
      }
      sandbox.spy = function() {
        const args = arrayProto.concat(
          [sandboxContext],
          arrayProto.slice(arguments)
        );
        const createdSpy = spy.withContext.apply(spy, args);
        const result = commonPostInitSetup(
          arguments,
          createdSpy,
          false,
          !(arguments.length === 1 && typeof arguments[0] === "object")
        );
        addReturnedMethodsToCollection(result);
        return result;
      };
      Object.defineProperty(sandbox.spy, "name", {
        value: "spy",
        configurable: true
      });
      Object.defineProperty(sandbox.spy, "length", {
        value: 0,
        configurable: true
      });
      extend(sandbox.spy, spy);
      sandbox.stub = function() {
        const args = arrayProto.concat(
          [sandboxContext],
          arrayProto.slice(arguments)
        );
        const createdStub = stub.withContext.apply(stub, args);
        const result = commonPostInitSetup(
          arguments,
          createdStub,
          true,
          !(arguments.length === 1 && typeof arguments[0] === "object")
        );
        addReturnedMethodsToCollection(result);
        return result;
      };
      Object.defineProperty(sandbox.stub, "name", {
        value: "stub",
        configurable: true
      });
      Object.defineProperty(sandbox.stub, "length", {
        value: 0,
        configurable: true
      });
      extend(sandbox.stub, stub);
      sandbox.mock = function() {
        const m = mock.apply(null, arguments);
        addToCollection(m);
        return m;
      };
      Object.defineProperty(sandbox.mock, "name", {
        value: "mock",
        configurable: true
      });
      Object.defineProperty(sandbox.mock, "length", {
        value: 0,
        configurable: true
      });
      extend(sandbox.mock, mock);
      sandbox.reset = function reset() {
        applyOnEach(collection, "reset");
        applyOnEach(collection, "resetHistory");
      };
      sandbox.resetBehavior = function resetBehavior() {
        applyOnEach(collection, "resetBehavior");
      };
      sandbox.resetHistory = function resetHistory() {
        for (let i = 0; i < collection.length; i++) {
          const f = collection[i];
          const method = f.resetHistory || f.reset;
          if (typeof method === "function") {
            method.call(f);
          }
        }
      };
      sandbox.verify = function verify() {
        applyOnEach(collection, "verify");
      };
      sandbox.verifyAndRestore = function verifyAndRestore() {
        let exception;
        try {
          sandbox.verify();
        } catch (e) {
          exception = e;
        }
        sandbox.restore();
        if (exception) {
          throw exception;
        }
      };
      sandbox.restore = function restore() {
        if (arguments.length) {
          throw new Error(
            "sandbox.restore() does not take any parameters. Perhaps you meant stub.restore()"
          );
        }
        reverse(fakeRestorers);
        forEach(fakeRestorers, function(restorer) {
          restorer();
        });
        fakeRestorers.length = 0;
        reverse(collection);
        applyOnEach(collection, "restore");
        collection = [];
      };
      sandbox.restoreContext = function restoreContext() {
        forEach(sandbox.injectedKeys, function(injectedKey) {
          delete sandbox.injectInto[injectedKey];
        });
        sandbox.injectedKeys.length = 0;
      };
      function getFakeRestorer(object, property, forceAssignment = false) {
        const descriptor = getPropertyDescriptor(object, property);
        const value = forceAssignment && object[property];
        function restorer() {
          if (forceAssignment) {
            object[property] = value;
          } else if (descriptor?.isOwn) {
            Object.defineProperty(object, property, descriptor);
          } else {
            delete object[property];
          }
        }
        restorer.sinon = true;
        restorer.object = object;
        restorer.property = property;
        return restorer;
      }
      function verifyNotReplaced(object, property) {
        forEach(fakeRestorers, function(fakeRestorer) {
          if (fakeRestorer.object === object && fakeRestorer.property === property) {
            throw new TypeError(
              `Attempted to replace ${valueToString(
                property
              )} which is already replaced`
            );
          }
        });
      }
      sandbox.replace = function replace(object, property, replacement) {
        const descriptor = getPropertyDescriptor(object, property);
        checkForValidArguments(descriptor, property, replacement);
        verifyNotReplaced(object, property);
        throwOnAccessors(descriptor);
        verifySameType(object, property, replacement);
        push(fakeRestorers, getFakeRestorer(object, property));
        object[property] = replacement;
        return replacement;
      };
      sandbox.replace.usingAccessor = function replaceUsingAccessor(object, property, replacement) {
        const descriptor = getPropertyDescriptor(object, property);
        checkForValidArguments(descriptor, property, replacement);
        verifyNotReplaced(object, property);
        verifySameType(object, property, replacement);
        push(fakeRestorers, getFakeRestorer(object, property, true));
        object[property] = replacement;
        return replacement;
      };
      sandbox.define = function define2(object, property, value) {
        const descriptor = getPropertyDescriptor(object, property);
        if (typeof property === "undefined") {
          throw new TypeError(
            `Cannot define the already existing property ${valueToString(
              property
            )}. Perhaps you meant sandbox.replace()?`
          );
        }
        if (descriptor && descriptor.isOwn) {
          throw new TypeError(
            `Cannot define the already existing property ${valueToString(
              property
            )}. Perhaps you meant sandbox.replace()?`
          );
        }
        push(fakeRestorers, getFakeRestorer(object, property));
        Object.defineProperty(object, property, {
          value,
          configurable: true,
          enumerable: true,
          writable: true
        });
        return value;
      };
      sandbox.replaceSetter = function replaceSetter(object, property, replacement) {
        const descriptor = getPropertyDescriptor(object, property);
        if (typeof descriptor === "undefined") {
          throw new TypeError(
            `Cannot replace non-existent property ${valueToString(
              property
            )}`
          );
        }
        if (typeof replacement !== "function") {
          throw new TypeError(
            "Expected replacement argument to be a function"
          );
        }
        verifyNotReplaced(object, property);
        if (typeof descriptor.set !== "function") {
          throw new Error("`object.property` is not a setter");
        }
        if (!descriptor.configurable) {
          throw new TypeError(
            `Descriptor for property ${valueToString(
              property
            )} is not configurable`
          );
        }
        push(fakeRestorers, getFakeRestorer(object, property));
        Object.defineProperty(object, property, {
          set: replacement,
          configurable: true,
          enumerable: descriptor.enumerable
        });
        return replacement;
      };
      sandbox.replaceGetter = function replaceGetter(object, property, replacement) {
        const descriptor = getPropertyDescriptor(object, property);
        if (typeof descriptor === "undefined") {
          throw new TypeError(
            `Cannot replace non-existent property ${valueToString(
              property
            )}`
          );
        }
        if (typeof replacement !== "function") {
          throw new TypeError(
            "Expected replacement argument to be a function"
          );
        }
        verifyNotReplaced(object, property);
        if (typeof descriptor.get !== "function") {
          throw new Error("`object.property` is not a getter");
        }
        if (!descriptor.configurable) {
          throw new TypeError(
            `Descriptor for property ${valueToString(
              property
            )} is not configurable`
          );
        }
        push(fakeRestorers, getFakeRestorer(object, property));
        Object.defineProperty(object, property, {
          get: replacement,
          configurable: true,
          enumerable: descriptor.enumerable
        });
        return replacement;
      };
      sandbox.useFakeTimers = function useFakeTimers(args) {
        const clock = fakeTimers.useFakeTimers.call(null, args);
        sandbox.clock = clock;
        addToCollection(clock);
        return clock;
      };
      sandbox.fake = function fake$1() {
        const args = arrayProto.concat(
          [sandboxContext],
          arrayProto.slice(arguments)
        );
        const createdFake = fake.withContext.apply(fake, args);
        const result = commonPostInitSetup(arguments, createdFake, false);
        addToCollection(result);
        return result;
      };
      Object.defineProperty(sandbox.fake, "name", {
        value: "fake",
        configurable: true
      });
      Object.defineProperty(sandbox.fake, "length", {
        value: 1,
        configurable: true
      });
      extend(sandbox.fake, fake);
      Object.defineProperty(sandbox.fake, "name", {
        value: "fake",
        configurable: true
      });
      Object.defineProperty(sandbox.fake, "length", {
        value: 1,
        configurable: true
      });
      function addFakeBehaviorToCollection(method) {
        sandbox.fake[method] = function() {
          const args = arrayProto.slice(arguments);
          args.push(sandboxContext);
          const result = fake[method].apply(fake, args);
          addToCollection(result);
          return result;
        };
      }
      addFakeBehaviorToCollection("returns");
      addFakeBehaviorToCollection("throws");
      addFakeBehaviorToCollection("resolves");
      addFakeBehaviorToCollection("rejects");
      addFakeBehaviorToCollection("yields");
      addFakeBehaviorToCollection("yieldsAsync");
    }
    Sandbox.prototype.match = match;
    module2.exports = Sandbox;
  }
});

// lib/sinon/create-sandbox.js
var require_create_sandbox = __commonJS({
  "lib/sinon/create-sandbox.js"(exports2, module2) {
    "use strict";
    var commons = require_lib();
    var sandbox = require_sandbox();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var commons__default = /* @__PURE__ */ _interopDefault(commons);
    var { forEach, push } = commons__default.default.prototypes.array;
    function prepareSandboxFromConfig(config) {
      const sandbox$1 = new sandbox({ assertOptions: config.assertOptions });
      if (config.useFakeTimers) {
        if (typeof config.useFakeTimers === "object") {
          sandbox$1.useFakeTimers(config.useFakeTimers);
        } else {
          sandbox$1.useFakeTimers();
        }
      }
      return sandbox$1;
    }
    function exposeValue(sandbox2, config, key, value) {
      if (!value) {
        return;
      }
      if (config.injectInto && !(key in config.injectInto)) {
        config.injectInto[key] = value;
        push(sandbox2.injectedKeys, key);
      } else {
        push(sandbox2.args, value);
      }
    }
    function createSandbox(config) {
      if (!config) {
        return new sandbox();
      }
      const configuredSandbox = prepareSandboxFromConfig(config);
      configuredSandbox.args = configuredSandbox.args || [];
      configuredSandbox.injectedKeys = [];
      configuredSandbox.injectInto = config.injectInto;
      const exposed = configuredSandbox.inject({});
      if (config.properties) {
        forEach(config.properties, function(prop) {
          const value = exposed[prop] || prop === "sandbox" && configuredSandbox;
          exposeValue(configuredSandbox, config, prop, value);
        });
      } else {
        exposeValue(configuredSandbox, config, "sandbox");
      }
      return configuredSandbox;
    }
    module2.exports = createSandbox;
  }
});

// lib/sinon/util/core/is-restorable.js
var require_is_restorable = __commonJS({
  "lib/sinon/util/core/is-restorable.js"(exports2, module2) {
    "use strict";
    function isRestorable(obj) {
      return typeof obj === "function" && typeof obj.restore === "function" && obj.restore.sinon;
    }
    module2.exports = isRestorable;
  }
});

// lib/sinon/promise.js
var require_promise = __commonJS({
  "lib/sinon/promise.js"(exports2, module2) {
    "use strict";
    var fake = require_fake();
    var isRestorable = require_is_restorable();
    var STATUS_PENDING = "pending";
    var STATUS_RESOLVED = "resolved";
    var STATUS_REJECTED = "rejected";
    function getFakeExecutor(executor) {
      if (isRestorable(executor)) {
        return executor;
      }
      if (executor) {
        return fake(executor);
      }
      return fake();
    }
    function promise(executor) {
      const fakeExecutor = getFakeExecutor(executor);
      const sinonPromise = new Promise(fakeExecutor);
      sinonPromise.status = STATUS_PENDING;
      sinonPromise.then(function(value) {
        sinonPromise.status = STATUS_RESOLVED;
        sinonPromise.resolvedValue = value;
      }).catch(function(reason) {
        sinonPromise.status = STATUS_REJECTED;
        sinonPromise.rejectedValue = reason;
      });
      function finalize(status, value, callback) {
        if (sinonPromise.status !== STATUS_PENDING) {
          throw new Error(`Promise already ${sinonPromise.status}`);
        }
        sinonPromise.status = status;
        callback(value);
      }
      sinonPromise.resolve = function(value) {
        finalize(STATUS_RESOLVED, value, fakeExecutor.firstCall.args[0]);
        return sinonPromise;
      };
      sinonPromise.reject = function(reason) {
        finalize(STATUS_REJECTED, reason, fakeExecutor.firstCall.args[1]);
        return new Promise(function(resolve) {
          sinonPromise.catch(() => resolve());
        });
      };
      return sinonPromise;
    }
    module2.exports = promise;
  }
});

// lib/sinon/restore-object.js
var require_restore_object = __commonJS({
  "lib/sinon/restore-object.js"(exports2, module2) {
    "use strict";
    var walkObject = require_walk_object();
    function filter(object, property) {
      return object[property].restore && object[property].restore.sinon;
    }
    function restore(object, property) {
      object[property].restore();
    }
    function restoreObject(object) {
      if (!object) {
        throw new Error(
          `Trying to restore object but received ${String(object)}`
        );
      }
      return walkObject.walkObject(restore, object, filter);
    }
    module2.exports = restoreObject;
  }
});

// lib/create-sinon-api.js
var require_create_sinon_api = __commonJS({
  "lib/create-sinon-api.js"(exports2, module2) {
    "use strict";
    var behavior = require_behavior();
    var createSandbox = require_create_sandbox();
    var createStubInstance = require_create_stub_instance();
    var collectOwnMethods = require_collect_own_methods();
    var extend = require_extend();
    var fakeTimers = require_fake_timers();
    var sandbox = require_sandbox();
    var stub = require_stub();
    var promise = require_promise();
    var samsam = require_samsam();
    var restoreObject = require_restore_object();
    var mockExpectation = require_mock_expectation();
    function _interopDefault(e) {
      return e && e.__esModule ? e : { default: e };
    }
    var samsam__default = /* @__PURE__ */ _interopDefault(samsam);
    function createApi() {
      const sandbox$1 = new sandbox();
      const apiMethods = {
        // `createSandbox` returns an isolated sandbox: its fakes are tracked
        // on its own collection so consumers can rely on `subSandbox.restore()`
        // (and only that) for cleanup. Don't push it into the global sandbox's
        // collection — doing so caused `sinon.restore()` to cascade-restore
        // sub-sandboxes (regression in 21.1.0, see #2701).
        createSandbox,
        match: samsam__default.default.createMatcher,
        restoreObject,
        expectation: mockExpectation,
        timers: fakeTimers.timers,
        createStubInstance: function createStubInstance$1() {
          const stubbed = createStubInstance.apply(null, arguments);
          for (const method of collectOwnMethods(stubbed)) {
            sandbox$1.getFakes().push(method);
          }
          return stubbed;
        },
        addBehavior: function(name, fn) {
          behavior.addBehavior(stub, name, fn);
        },
        promise
      };
      Object.defineProperty(apiMethods.createSandbox, "name", {
        value: "createSandbox",
        configurable: true
      });
      Object.defineProperty(apiMethods.createSandbox, "length", {
        value: 1,
        configurable: true
      });
      Object.defineProperty(apiMethods.createStubInstance, "name", {
        value: "createStubInstance",
        configurable: true
      });
      Object.defineProperty(apiMethods.createStubInstance, "length", {
        value: 1,
        configurable: true
      });
      return extend(sandbox$1, apiMethods);
    }
    module2.exports = createApi;
  }
});

// lib/sinon.js
var createSinonApi = require_create_sinon_api();
var sinon = createSinonApi();
module.exports = sinon;

if(__exports != exports)module.exports = exports;return module.exports}));
